package com.yucehanclan.giriseklentisi;

import io.netty.channel.Channel;
import io.netty.channel.ChannelDuplexHandler;
import io.netty.channel.ChannelHandlerContext;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.lang.reflect.Field;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Paket flood koruma sistemi.
 *
 * DÜZELTME: addBefore("packet_handler") crash düzeltildi.
 * Paper 1.21'de pipeline handler adı değişebiliyor.
 * Artık addLast() kullanılıyor — her versiyonda çalışır.
 */
public class PacketFloodDetector {

    private static final String HANDLER_NAME    = "giris_flood_guard";
    private static final int    FLOOD_THRESHOLD = 700;
    private static final int    MAX_KICK_PER_SESSION = 3;
    private static final long   WINDOW_NS       = 1_000_000_000L;

    private final GirisEklentisi pl;
    private volatile boolean injectionWorking = false;

    private final Map<UUID, long[]>  counters  = new ConcurrentHashMap<>();
    private final Map<UUID, Integer> kickSayac = new ConcurrentHashMap<>();
    private final Map<UUID, Channel> channels  = new ConcurrentHashMap<>();

    public PacketFloodDetector(GirisEklentisi pl) {
        this.pl = pl;
    }

    public void inject(Player player) {
        Channel channel = resolveChannel(player);
        if (channel == null) {
            if (!injectionWorking) {
                pl.getLogger().warning("[FloodGuard] Netty kanalı bulunamadı — flood koruması pasif.");
            }
            return;
        }

        injectionWorking = true;
        UUID uuid = player.getUniqueId();
        channels.put(uuid, channel);
        counters.put(uuid, new long[]{ 0L, System.nanoTime() });

        ChannelDuplexHandler handler = new ChannelDuplexHandler() {
            @Override
            public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
                onPacket(uuid);
                super.channelRead(ctx, msg);
            }
        };

        // DÜZELTME: addBefore yerine addLast — "packet_handler" adı Paper versiyonuna göre değişiyor
        channel.eventLoop().execute(() -> {
            if (!channel.isActive()) return;
            if (channel.pipeline().get(HANDLER_NAME) != null) return;
            try {
                channel.pipeline().addLast(HANDLER_NAME, handler);
            } catch (Exception e) {
                pl.getLogger().fine("[FloodGuard] Handler eklenemedi (" + player.getName() + "): " + e.getMessage());
            }
        });
    }

    public void eject(Player player) {
        UUID    uuid    = player.getUniqueId();
        Channel channel = channels.remove(uuid);
        counters.remove(uuid);
        kickSayac.remove(uuid);

        if (channel != null && channel.isActive()) {
            channel.eventLoop().execute(() -> {
                try {
                    if (channel.pipeline().get(HANDLER_NAME) != null)
                        channel.pipeline().remove(HANDLER_NAME);
                } catch (Exception ignored) {}
            });
        }
    }

    private void onPacket(UUID uuid) {
        long[] state = counters.get(uuid);
        if (state == null) return;

        long now     = System.nanoTime();
        long elapsed = now - state[1];

        if (elapsed >= WINDOW_NS) {
            state[0] = 1L;
            state[1] = now;
            return;
        }

        state[0]++;

        if (state[0] > FLOOD_THRESHOLD) {
            state[0] = 0L;
            state[1] = now;

            Bukkit.getScheduler().runTask(pl, () -> {
                Player player = Bukkit.getPlayer(uuid);
                if (player == null || !player.isOnline()) return;

                int kicks = kickSayac.merge(uuid, 1, Integer::sum);
                if (kicks <= MAX_KICK_PER_SESSION) {
                    pl.getLogger().warning("[FloodGuard] Flood kick: " + player.getName()
                        + " (" + kicks + ". olay)");
                    player.kickPlayer(
                        "§c§lPaket Aşımı!\n\n" +
                        "§7Otomatik sistem. Yanlışlıksa\n" +
                        "tekrar bağlanabilirsin.\n\n" +
                        "§aİyi oyunlar."
                    );
                }
            });
        }
    }

    private Channel resolveChannel(Player player) {
        try {
            Object nmsPlayer  = player.getClass().getMethod("getHandle").invoke(player);
            Object playerConn = getFieldValue(nmsPlayer, "connection", "playerConnection");
            if (playerConn == null) return null;
            Object netManager = getFieldValue(playerConn, "connection", "networkManager", "c", "f");
            if (netManager == null) return null;
            return (Channel) findFieldByType(netManager, Channel.class);
        } catch (Exception e) {
            pl.getLogger().fine("[FloodGuard] resolveChannel hatası: " + e);
            return null;
        }
    }

    private static Object getFieldValue(Object obj, String... fieldNames) {
        for (String name : fieldNames) {
            for (Class<?> c = obj.getClass(); c != null; c = c.getSuperclass()) {
                try {
                    Field f = c.getDeclaredField(name);
                    f.setAccessible(true);
                    Object val = f.get(obj);
                    if (val != null) return val;
                } catch (NoSuchFieldException ignored) {
                } catch (Exception e) { break; }
            }
        }
        return null;
    }

    private static Object findFieldByType(Object obj, Class<?> targetType) {
        for (Class<?> c = obj.getClass(); c != null; c = c.getSuperclass()) {
            for (Field f : c.getDeclaredFields()) {
                if (targetType.isAssignableFrom(f.getType())) {
                    f.setAccessible(true);
                    try {
                        Object val = f.get(obj);
                        if (val != null) return val;
                    } catch (Exception ignored) {}
                }
            }
        }
        return null;
    }
}
