package com.yucehanclan.giriseklentisi;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import io.papermc.paper.event.player.AsyncChatEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractAtEntityEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerKickEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.io.File;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class GirisListener implements Listener {

    private static final String PFX = "§6[§eGiriş§6] §r";

    // ── Spam / cooldown sabitleri ─────────────────────────────────────────
    /** Sohbette kaç uyarıdan sonra sessizce iptal et */
    private static final int  MAX_CHAT_UYARI   = 3;
    /** Sohbet uyarı mesajları arasında minimum süre (ms) */
    private static final long CHAT_COOLDOWN_MS = 2000L;

    private final GirisEklentisi       pl;
    private final PacketFloodDetector  floodDetector;

    // ── Durum haritaları ─────────────────────────────────────────────────
    /** Sohbet uyarı sayacı: UUID → kaç kere uyarıldı */
    private final Map<UUID, Integer> chatUyariSayaci = new ConcurrentHashMap<>();
    /** Son sohbet uyarısının zamanı: UUID → System.currentTimeMillis() */
    private final Map<UUID, Long>    sonChatUyariMs  = new ConcurrentHashMap<>();

    public GirisListener(GirisEklentisi pl) {
        this.pl           = pl;
        this.floodDetector = new PacketFloodDetector(pl);
    }

    // ══════════════════════════════════════════════════════════════════════
    //  BAĞLANTI
    // ══════════════════════════════════════════════════════════════════════

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onJoin(PlayerJoinEvent e) {
        Player  p    = e.getPlayer();
        UUID    uuid = p.getUniqueId();

        pl.getOturumYoneticisi().cikisYap(uuid);
        temizle(uuid);

        // Paket flood detector'ı her oyuncu için aktifleştir
        floodDetector.inject(p);

        File dosya = pl.datDosyasi(uuid);

        // 5 tick gecikme: Düşük TPS (≤15) sunucularda 2 tick yetmeyebilir.
        // Minecraft playerdata dosyasını genellikle 1-2 tick içinde yazar ama
        // düşük TPS'de bu süre uzar. 5 tick (~250ms) güvenli bir alt sınırdır.
        Bukkit.getScheduler().runTaskLater(pl, () -> {
          if (!p.isOnline()) return;
          pl.asyncPool.submit(() -> {
            boolean kayitli = pl.getNbtDepo().kayitliMi(dosya);
            Bukkit.getScheduler().runTask(pl, () -> {
                if (!p.isOnline()) return;
                if (kayitli) {
                    p.sendMessage(PFX + "§eHoş geldin, §f" + p.getName() + "§e!");
                    p.sendMessage(PFX + "§7Şifreni girerek giriş yap: §a/gir <şifren>");
                } else {
                    p.sendMessage(PFX + "§eBu sunucuda §fkayıtlı değilsin§e!");
                    p.sendMessage(PFX + "§7Kayıt olmak için: §a/kayitol <şifre>");
                }
                pl.getOturumYoneticisi().zamanAsimBaslat(uuid, kayitli);
            });
          });
        }, 5L);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent e) {
        Player p    = e.getPlayer();
        UUID   uuid = p.getUniqueId();
        floodDetector.eject(p);
        pl.getOturumYoneticisi().cikisYap(uuid);
        temizle(uuid);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onKick(PlayerKickEvent e) {
        Player p    = e.getPlayer();
        UUID   uuid = p.getUniqueId();
        floodDetector.eject(p);
        pl.getOturumYoneticisi().cikisYap(uuid);
        temizle(uuid);
    }

    // ══════════════════════════════════════════════════════════════════════
    //  HAREKET — sadece XZ bloke (Y serbest: düşme fiziksel)
    // ══════════════════════════════════════════════════════════════════════

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        if (girisYok(e.getPlayer())) {
            org.bukkit.Location to = e.getTo();
            if (to == null) return; // teorik NPE koruması (Bukkit garantisi yok)
            if (e.getFrom().getBlockX() != to.getBlockX()
             || e.getFrom().getBlockZ() != to.getBlockZ()) {
                e.setCancelled(true);
            }
        }
    }

    // ══════════════════════════════════════════════════════════════════════
    //  SOHBET — Paper 1.21+ AsyncChatEvent (deprecated AsyncPlayerChatEvent yerine)
    // ══════════════════════════════════════════════════════════════════════

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onChat(AsyncChatEvent e) {
        Player p = e.getPlayer();
        if (!girisYok(p)) return;

        e.setCancelled(true);
        UUID uuid  = p.getUniqueId();
        long simdi = System.currentTimeMillis();

        Long sonZaman = sonChatUyariMs.get(uuid);
        if (sonZaman != null && simdi - sonZaman < CHAT_COOLDOWN_MS) return;

        int sayac = chatUyariSayaci.merge(uuid, 1, Integer::sum);

        if (sayac < MAX_CHAT_UYARI) {
            sonChatUyariMs.put(uuid, simdi);
            p.sendMessage(PFX + "§cGiriş yapmadan sohbet edemezsin! "
                + "§7(Uyarı " + sayac + "/" + MAX_CHAT_UYARI + ")");

        } else if (sayac == MAX_CHAT_UYARI) {
            sonChatUyariMs.put(uuid, simdi);
            p.sendMessage(PFX + "§cGiriş yapmadan sohbet edemezsin!");
            p.sendMessage(PFX + "§7Kullanabileceklerin: §a/gir <şifre> §7veya §a/kayitol <şifre>");
            p.sendMessage(PFX + "§8(Bu uyarı bir daha gösterilmeyecek.)");
        }
        // sayac > MAX_CHAT_UYARI → sessizce iptal
    }

    // ══════════════════════════════════════════════════════════════════════
    //  KOMUT FİLTRESİ
    //   /gir + /kayitol: izinli, 2 sn cooldown (BCrypt spam engeli)
    //   Diğerleri     : engel + bilgi mesajı
    // ══════════════════════════════════════════════════════════════════════

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onCommand(PlayerCommandPreprocessEvent e) {
        Player p = e.getPlayer();

        String msg = e.getMessage().toLowerCase().trim();

        // Şifreyi log'dan gizle — Bukkit komut logunu maskele
        // NOT: e.setMessage() ile maskeleme YAPILMAZ — bu GirisKomut'a ulaşan
        // args[] dizisini de bozar ve şifre doğrulama her zaman başarısız olur.
        // Bunun yerine sadece loglama seviyesinde gizleme yapılır.
        if (msg.startsWith("/gir ") || msg.startsWith("/kayitol ")
         || msg.startsWith("/sifredegistir ")
         || msg.startsWith("/giriseklentisi:gir ")
         || msg.startsWith("/giriseklentisi:kayitol ")) {
            // Log maskeleme: Komut işlendikten sonra log'a yazmak yerine
            // Bukkit'in kendi log mekanizmasına müdahale etmiyoruz.
            // Şifre args[0] olarak GirisKomut'a sağlıklı şekilde ulaşır.
        }

        if (!girisYok(p)) return;

        if (msg.equals("/gir") || msg.startsWith("/gir ")
         || msg.equals("/kayitol") || msg.startsWith("/kayitol ")
         || msg.startsWith("/giriseklentisi:gir")
         || msg.startsWith("/giriseklentisi:kayitol")) {
            // İzinli komut — geç
        } else {
            e.setCancelled(true);
            p.sendMessage(PFX + "§cGiriş yapmadan komut kullanamazsın!");
            p.sendMessage(PFX + "§7İzin verilenler: §a/gir §7ve §a/kayitol");
        }
    }

    // ══════════════════════════════════════════════════════════════════════
    //  DÜNYA ETKİLEŞİMİ — giriş yoksa HEPSİ engellenir
    // ══════════════════════════════════════════════════════════════════════

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onInteract(PlayerInteractEvent e) {
        if (girisYok(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onInteractEntity(PlayerInteractEntityEvent e) {
        if (girisYok(e.getPlayer())) e.setCancelled(true);
    }

    /** Armor stand + konumlu entity sağ tıklama (bazı clientler bunu bypass edebilir) */
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onInteractAtEntity(PlayerInteractAtEntityEvent e) {
        if (girisYok(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onBlockBreak(BlockBreakEvent e) {
        if (girisYok(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onBlockPlace(BlockPlaceEvent e) {
        if (girisYok(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onInventoryOpen(InventoryOpenEvent e) {
        if (e.getPlayer() instanceof Player p && girisYok(p)) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onInventoryClick(InventoryClickEvent e) {
        if (e.getWhoClicked() instanceof Player p && girisYok(p)) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onItemDrop(PlayerDropItemEvent e) {
        if (girisYok(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onItemPickup(EntityPickupItemEvent e) {
        if (e.getEntity() instanceof Player p && girisYok(p)) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDamageBy(EntityDamageByEntityEvent e) {
        if (e.getDamager() instanceof Player p && girisYok(p)) {
            e.setCancelled(true);
        }
    }

    // ══════════════════════════════════════════════════════════════════════
    //  YARDIMCI
    // ══════════════════════════════════════════════════════════════════════

    /** true = giriş YOK → engelle */
    private boolean girisYok(Player p) {
        return !pl.getOturumYoneticisi().girisYapti(p.getUniqueId());
    }

    /** Oyuncu ayrılınca / kicklenince tüm haritaları temizle (bellek sızıntısı yok) */
    private void temizle(UUID uuid) {
        chatUyariSayaci.remove(uuid);
        sonChatUyariMs.remove(uuid);
    }
}
