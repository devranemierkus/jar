package com.yucehanclan.giriseklentisi;

import java.io.File;
import java.sql.*;
import java.util.UUID;

/**
 * LoginSecurity veritabanından şifreleri yükler.
 *
 * ls_players tablosu sütunları (kullanılanlar):
 *   unique_user_id  — UUID string (kesik çizgili format)
 *   password        — BCrypt hash ($2a$10$...)
 *   hashing_algorithm — 7 = BCrypt (sadece bunları alırız)
 *   registration_date — kayıt tarihi (opsiyonel)
 *
 * İşlem sırası:
 *   1. SQLite bağlantısı aç
 *   2. Her satır için UUID.dat dosyasını bul
 *   3. Hash'i sıkıştır ve NBT'ye yaz
 *   4. Sonuç sayılarını döndür (başarılı/atlanan/hatalı)
 *   5. Çağıran taraf DB dosyasını siler
 */
public class DBMigrasyonu {

    private final GirisEklentisi pl;

    public DBMigrasyonu(GirisEklentisi pl) {
        this.pl = pl;
    }

    /**
     * @return int[3] → [0]=başarılı, [1]=atlanan, [2]=hatalı
     */
    public int[] yukle(File dbDosya) throws Exception {
        // SQLite JDBC sürücüsünü yükle
        Class.forName("org.sqlite.JDBC");

        int basarili = 0, atlanan = 0, hata = 0;

        String url = "jdbc:sqlite:" + dbDosya.getAbsolutePath();

        try (Connection conn = DriverManager.getConnection(url)) {

            // Sadece BCrypt (algorithm=7) kayıtlarını çek
            String sql =
                "SELECT unique_user_id, password, registration_date " +
                "FROM ls_players " +
                "WHERE hashing_algorithm = 7 " +
                "  AND unique_user_id IS NOT NULL " +
                "  AND password IS NOT NULL";

            try (PreparedStatement ps = conn.prepareStatement(sql);
                 ResultSet rs = ps.executeQuery()) {

                while (rs.next()) {
                    String uuidStr = rs.getString("unique_user_id");
                    String hash    = rs.getString("password");

                    // Temel doğrulama
                    if (uuidStr == null || uuidStr.isBlank()
                     || hash == null   || !hash.startsWith("$2")) {
                        atlanan++;
                        continue;
                    }

                    // Kayıt tarihi (opsiyonel)
                    long kayitZamani = 0;
                    try {
                        Date d = rs.getDate("registration_date");
                        if (d != null) kayitZamani = d.getTime();
                    } catch (Exception ignored) {}

                    try {
                        UUID uuid  = UUID.fromString(uuidStr.trim());
                        File dosya = pl.datDosyasi(uuid);

                        boolean yazildi = pl.getNbtDepo().hashDirekMigre(dosya, hash, kayitZamani);

                        if (yazildi) {
                            basarili++;
                            pl.getLogger().info("[DBMigrasyon] ✔ " + uuidStr);
                        } else {
                            atlanan++;
                            pl.getLogger().info("[DBMigrasyon] ⚡ Dosya yok: " + uuidStr);
                        }

                    } catch (IllegalArgumentException uuidHata) {
                        pl.getLogger().warning("[DBMigrasyon] Geçersiz UUID: " + uuidStr);
                        atlanan++;
                    } catch (Exception yazmaHata) {
                        pl.getLogger().warning("[DBMigrasyon] ✖ Hata (" + uuidStr + "): "
                            + yazmaHata.getMessage());
                        hata++;
                    }
                }
            }
        }

        return new int[]{basarili, atlanan, hata};
    }
}
