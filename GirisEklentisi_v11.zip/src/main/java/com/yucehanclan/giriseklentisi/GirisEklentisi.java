package com.yucehanclan.giriseklentisi;

import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public final class GirisEklentisi extends JavaPlugin {

    // UUID.dat içine yazılacak NBT anahtarları
    static final String NBT_HASH      = "GirisHash";      // byte[] — sıkıştırılmış BCrypt hash
    static final String NBT_KAYIT     = "GirisKayit";     // long  — kayıt timestamp
    static final String NBT_SON_GIRIS = "GirisSonGiris";  // long  — son giriş timestamp

    private File pdDir;
    private OturumYoneticisi oturumYoneticisi;
    private SikistirmaMotoru sikistirmaMotoru;
    private NbtDepo          nbtDepo;

    final ExecutorService asyncPool = Executors.newFixedThreadPool(4, r -> {
        Thread t = new Thread(r, "Giris-Async");
        t.setDaemon(true);
        return t;
    });

    @Override
    public void onEnable() {
        getDataFolder().mkdirs();
        saveDefaultConfig();

        // world/playerdata — Minecraft'ın standart UUID.dat klasörü
        pdDir = new File(
            Bukkit.getWorldContainer(),
            Bukkit.getWorlds().get(0).getName() + "/playerdata"
        );

        sikistirmaMotoru = new SikistirmaMotoru(getLogger());
        nbtDepo          = new NbtDepo(this);
        oturumYoneticisi = new OturumYoneticisi(this);

        GirisKomut komutHandler = new GirisKomut(this);
        Objects.requireNonNull(getCommand("kayitol")).setExecutor(komutHandler);
        Objects.requireNonNull(getCommand("gir")).setExecutor(komutHandler);
        Objects.requireNonNull(getCommand("yetkilisifresil")).setExecutor(komutHandler);
        Objects.requireNonNull(getCommand("sifredegistir")).setExecutor(komutHandler);
        Objects.requireNonNull(getCommand("sifregeriyukle")).setExecutor(komutHandler);

        GirisListener girisListener = new GirisListener(this);
        getServer().getPluginManager().registerEvents(girisListener, this);

        getLogger().info("═══════════════════════════════════════");
        getLogger().info("  GirisEklentisi v2.0 aktif!");
        getLogger().info("  Sıkıştırma: " + sikistirmaMotoru.aktifMotorlarStr());
        getLogger().info("  Playerdata: " + pdDir.getAbsolutePath());
        getLogger().info("  FloodGuard: Injection ilk oyuncu girişinde test edilecek.");
        getLogger().info("═══════════════════════════════════════");
    }

    @Override
    public void onDisable() {
        asyncPool.shutdown();
        try { asyncPool.awaitTermination(8, TimeUnit.SECONDS); }
        catch (InterruptedException ignored) {}
        getLogger().info("GirisEklentisi kapatıldı.");
    }

    public File datDosyasi(UUID uuid) {
        return new File(pdDir, uuid + ".dat");
    }

    public OturumYoneticisi getOturumYoneticisi() { return oturumYoneticisi; }
    public SikistirmaMotoru getSikistirmaMotoru()  { return sikistirmaMotoru; }
    public NbtDepo          getNbtDepo()           { return nbtDepo; }

    public int maxDeneme()    { return getConfig().getInt("max_deneme", 5); }
    public int girisSuresi()  { return getConfig().getInt("giris_suresi", 60); }
    public int minSifreBoy()  { return getConfig().getInt("min_sifre_uzunluk", 5); }
    public int maxSifreBoy()  { return getConfig().getInt("max_sifre_uzunluk", 32); }
    public int bcryptCost()   { return getConfig().getInt("bcrypt_cost", 12); }
}
