package com.yucehanclan.giriseklentisi;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Oyuncu oturum yöneticisi.
 *
 * DÜZELTME: Memory leak giderildi.
 * List<BukkitTask> yerine tek bir BukkitTask tutuldu.
 * iptalEt() her zaman güvenli şekilde çalışıyor.
 */
public class OturumYoneticisi {

    private static final String PFX = "§6[§eGiriş§6] §r";

    private final GirisEklentisi pl;

    private final Set<UUID>              girisYapildi       = ConcurrentHashMap.newKeySet();
    private final Map<UUID, Integer>     denemeleri         = new ConcurrentHashMap<>();
    private final Map<UUID, BukkitTask>  kickGorev          = new ConcurrentHashMap<>();
    private final Map<UUID, BukkitTask>  spam1Gorev         = new ConcurrentHashMap<>();
    private final Map<UUID, BukkitTask>  spam2Gorev         = new ConcurrentHashMap<>();
    private final Map<UUID, BukkitTask>  spam3Gorev         = new ConcurrentHashMap<>();

    public OturumYoneticisi(GirisEklentisi pl) { this.pl = pl; }

    public boolean girisYapti(UUID uuid) {
        return girisYapildi.contains(uuid);
    }

    public int mevcutDeneme(UUID uuid) {
        return denemeleri.getOrDefault(uuid, 0);
    }

    public void girisYap(UUID uuid) {
        girisYapildi.add(uuid);
        denemeleri.remove(uuid);
        iptalEt(uuid);
    }

    public void cikisYap(UUID uuid) {
        girisYapildi.remove(uuid);
        denemeleri.remove(uuid);
        iptalEt(uuid);
    }

    public int denemeArttir(UUID uuid) {
        return denemeleri.merge(uuid, 1, Integer::sum);
    }

    public void zamanAsimBaslat(UUID uuid, boolean kayitliMi) {
        // Önce varsa eski görevleri iptal et
        iptalEt(uuid);

        int    sure   = pl.girisSuresi();
        String komut  = kayitliMi ? "/gir <şifre>" : "/kayitol <şifre>";
        String renk   = kayitliMi ? "§a" : "§e";

        // Spam zamanlamaları sure'ye göre dinamik:
        // %25, %50 ve %80'inde uyar — sure ne olursa olsun mantıklı aralıklar
        long spam1Tick = Math.max(40L,  (long)(sure * 0.25 * 20));
        long spam2Tick = Math.max(80L,  (long)(sure * 0.50 * 20));
        long spam3Tick = Math.max(120L, (long)(sure * 0.80 * 20));
        long kickTick  = sure * 20L;

        // Spam 1: %25
        spam1Gorev.put(uuid, Bukkit.getScheduler().runTaskLater(pl, () -> {
            if (girisYapti(uuid)) return;
            Player p = Bukkit.getPlayer(uuid);
            if (p != null && p.isOnline())
                p.sendMessage(PFX + "§c⚠ §eGiriş için: " + renk + komut + " §eyaz!");
        }, spam1Tick));

        // Spam 2: %50
        spam2Gorev.put(uuid, Bukkit.getScheduler().runTaskLater(pl, () -> {
            if (girisYapti(uuid)) return;
            Player p = Bukkit.getPlayer(uuid);
            if (p != null && p.isOnline())
                p.sendMessage(PFX + "§c⚠ §eHâlâ giriş yapmadın! " + renk + komut + " §eyaz!");
        }, spam2Tick));

        // Spam 3: %80
        spam3Gorev.put(uuid, Bukkit.getScheduler().runTaskLater(pl, () -> {
            if (girisYapti(uuid)) return;
            Player p = Bukkit.getPlayer(uuid);
            if (p != null && p.isOnline()) {
                long kalanSaniye = (kickTick - spam3Tick) / 20;
                p.sendMessage(PFX + "§4§l⚠ §cSON UYARI! §e" + kalanSaniye + "s içinde giriş yapmazsan §c§lATILIRSIN§e! → " + renk + komut);
            }
        }, spam3Tick));

        // Kick: sure sonra
        kickGorev.put(uuid, Bukkit.getScheduler().runTaskLater(pl, () -> {
            kickGorev.remove(uuid);
            if (!girisYapti(uuid)) {
                Player p = Bukkit.getPlayer(uuid);
                if (p != null && p.isOnline()) {
                    p.kickPlayer(
                        "§c§lGiriş süresi doldu!\n" +
                        "§eLütfen tekrar bağlan ve §a" + komut + " §eyaz."
                    );
                }
            }
        }, kickTick));
    }

    private void iptalEt(UUID uuid) {
        iptalGorev(kickGorev.remove(uuid));
        iptalGorev(spam1Gorev.remove(uuid));
        iptalGorev(spam2Gorev.remove(uuid));
        iptalGorev(spam3Gorev.remove(uuid));
    }

    private void iptalGorev(BukkitTask task) {
        if (task != null) {
            try { task.cancel(); } catch (Exception ignored) {}
        }
    }
}
