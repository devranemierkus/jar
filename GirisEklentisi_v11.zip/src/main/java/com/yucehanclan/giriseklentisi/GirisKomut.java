package com.yucehanclan.giriseklentisi;

import at.favre.lib.crypto.bcrypt.BCrypt;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

import java.io.File;
import java.util.UUID;

public class GirisKomut implements CommandExecutor {

    private static final String PFX  = "§6[§eGiriş§6] §r";
    private static final String SPFX = "§c[§4Giriş§c] §r";

    private final GirisEklentisi pl;

    public GirisKomut(GirisEklentisi pl) {
        this.pl = pl;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        switch (cmd.getName().toLowerCase()) {
            case "kayitol"         -> handleKayitol(sender, args);
            case "gir"             -> handleGir(sender, args);
            case "yetkilisifresil" -> handleYetkiliSifreSil(sender, args);
            case "sifredegistir"   -> handleSifreDegistir(sender, args);
            case "sifregeriyukle"  -> handleSifreGeriYukle(sender);
        }
        return true;
    }

    // ═══════════════════════════════════════════════════════════════════
    //  /kayitol <sifre>
    // ═══════════════════════════════════════════════════════════════════

    private void handleKayitol(CommandSender sender, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage(SPFX + "Bu komutu sadece oyuncular kullanabilir.");
            return;
        }
        UUID uuid  = p.getUniqueId();
        File dosya = pl.datDosyasi(uuid);

        // Zaten giriş yaptıysa bir şey yapma
        if (pl.getOturumYoneticisi().girisYapti(uuid)) {
            p.sendMessage(SPFX + "Zaten giriş yaptın.");
            return;
        }

        if (args.length < 1) {
            p.sendMessage(PFX + "Kullanım: §a/kayitol <şifre>");
            return;
        }

        String sifre = args[0];

        if (sifre.length() < pl.minSifreBoy()) {
            p.sendMessage(SPFX + "Şifre en az §e" + pl.minSifreBoy() + " §ckarakter olmalı.");
            return;
        }
        if (sifre.length() > pl.maxSifreBoy()) {
            p.sendMessage(SPFX + "Şifre en fazla §e" + pl.maxSifreBoy() + " §ckarakter olabilir.");
            return;
        }

        // Adım 1 (Main Thread): saveData() ile UUID.dat'ı diske garantiyle flush et.
        // Adım 2 (Async):       BCrypt hash üret → hashYaz() (dosyayı retry ile bekler).
        // Adım 3 (Main Thread): Oturumu aç, oyuncuya mesaj gönder.
        // Eski üç katmanlı scheduler zinciri kaldırıldı — race condition düzeltildi.
        Bukkit.getScheduler().runTask(pl, () -> {
            if (!p.isOnline()) return;
            p.saveData(); // UUID.dat'ı diske yaz — ardından async'e geçiyoruz

            pl.asyncPool.submit(() -> {
                try {
                    // Zaten kayıtlıysa /gir ile devam etsin
                    if (pl.getNbtDepo().kayitliMi(dosya)) {
                        Bukkit.getScheduler().runTask(pl, () -> {
                            if (!p.isOnline()) return;
                            p.sendMessage(PFX + "§eZaten kayıtlısın! Şifreni girerek giriş yap:");
                            p.sendMessage(PFX + "§a/gir <şifren>");
                        });
                        return;
                    }

                    // BCrypt hash üret (ağır işlem — async'te olmalı)
                    String hash = BCrypt.withDefaults().hashToString(pl.bcryptCost(), sifre.toCharArray());

                    // hashYaz içinde dosya yoksa 500ms retry bekler (race condition koruması)
                    pl.getNbtDepo().hashYaz(dosya, hash);

                    Bukkit.getScheduler().runTask(pl, () -> {
                        if (!p.isOnline()) return;
                        pl.getOturumYoneticisi().girisYap(uuid);
                        p.sendMessage(PFX + "§aKayıt başarılı! Hoş geldin, §e" + p.getName() + "§a.");
                        p.sendMessage(PFX + "§cŞifreni unutursan §eyetkililerle iletişime geç§c!");
                    });

                } catch (Exception e) {
                    pl.getLogger().severe("[Kayıt] " + uuid + " — " + e.getMessage());
                    Bukkit.getScheduler().runTask(pl, () -> {
                        if (!p.isOnline()) return;
                        p.sendMessage(SPFX + "Kayıt sırasında hata oluştu. Yetkiliyle iletişime geç.");
                    });
                }
            });
        });
    }

    // ═══════════════════════════════════════════════════════════════════
    //  /gir <sifre>
    // ═══════════════════════════════════════════════════════════════════

    private void handleGir(CommandSender sender, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage(SPFX + "Bu komutu sadece oyuncular kullanabilir.");
            return;
        }
        UUID uuid  = p.getUniqueId();
        File dosya = pl.datDosyasi(uuid);

        if (pl.getOturumYoneticisi().girisYapti(uuid)) {
            p.sendMessage(SPFX + "Zaten giriş yaptın.");
            return;
        }
        if (args.length < 1) {
            p.sendMessage(PFX + "Kullanım: §a/gir <şifre>");
            return;
        }

        String sifre = args[0];

        pl.asyncPool.submit(() -> {
            try {
                // Kayıtlı değilse /kayitol'a yönlendir
                if (!pl.getNbtDepo().kayitliMi(dosya)) {
                    Bukkit.getScheduler().runTask(pl, () -> {
                        p.sendMessage(SPFX + "Kayıtlı değilsin!");
                        p.sendMessage(PFX + "Kayıt olmak için: §a/kayitol <şifre>");
                    });
                    return;
                }

                String kayitliHash = pl.getNbtDepo().hashOku(dosya);
                if (kayitliHash == null) {
                    Bukkit.getScheduler().runTask(pl, () ->
                        p.sendMessage(SPFX + "Şifre verisi okunamadı. Yetkiliyle iletişime geç."));
                    return;
                }

                BCrypt.Result sonuc = BCrypt.verifyer().verify(sifre.toCharArray(), kayitliHash);

                if (sonuc.verified) {
                    try { pl.getNbtDepo().sonGirisiGuncelle(dosya); }
                    catch (Exception ignored) {}

                    Bukkit.getScheduler().runTask(pl, () -> {
                        pl.getOturumYoneticisi().girisYap(uuid);
                        p.sendMessage(PFX + "§aGiriş başarılı! Hoş geldin, §e" + p.getName() + "§a.");
                    });

                } else {
                    int deneme = pl.getOturumYoneticisi().denemeArttir(uuid);
                    int kalan  = pl.maxDeneme() - deneme;

                    Bukkit.getScheduler().runTask(pl, () -> {
                        if (kalan <= 0) {
                            p.kickPlayer(
                                "§c§lÇok fazla yanlış şifre!\n" +
                                "§eLütfen tekrar bağlan."
                            );
                        } else {
                            p.sendMessage(SPFX + "Yanlış şifre! §eKalan deneme: §c" + kalan);
                            if (kalan <= 2) {
                                p.sendMessage(SPFX + "§cŞifreni unutursan yetkiliyle iletişime geç!");
                            }
                        }
                    });
                }

            } catch (Exception e) {
                pl.getLogger().severe("[Giriş] " + uuid + " — " + e.getMessage());
                Bukkit.getScheduler().runTask(pl, () ->
                    p.sendMessage(SPFX + "Giriş sırasında hata oluştu. Yetkiliyle iletişime geç."));
            }
        });
    }

    // ═══════════════════════════════════════════════════════════════════
    //  /yetkilisifresil <oyuncu>
    // ═══════════════════════════════════════════════════════════════════

    private void handleYetkiliSifreSil(CommandSender sender, String[] args) {
        if (!sender.hasPermission("giriseklentisi.yetkili")) {
            sender.sendMessage(SPFX + "Bu komutu kullanmak için yetkin yok.");
            return;
        }
        if (args.length < 1) {
            sender.sendMessage(PFX + "Kullanım: §a/yetkilisifresil <oyuncu>");
            return;
        }

        String hedefAd = args[0];

        pl.asyncPool.submit(() -> {
            @SuppressWarnings("deprecation")
            OfflinePlayer op = Bukkit.getOfflinePlayer(hedefAd);

            if (!op.hasPlayedBefore()) {
                Bukkit.getScheduler().runTask(pl, () ->
                    sender.sendMessage(SPFX + "Oyuncu bulunamadı: §e" + hedefAd));
                return;
            }

            UUID hedefUUID = op.getUniqueId();
            File dosya     = pl.datDosyasi(hedefUUID);

            try {
                pl.getNbtDepo().hashSil(dosya);

                Bukkit.getScheduler().runTask(pl, () -> {
                    sender.sendMessage(PFX + "§a" + hedefAd + " §7adlı oyuncunun şifresi sıfırlandı.");

                    Player hedef = Bukkit.getPlayer(hedefUUID);
                    if (hedef != null && hedef.isOnline()) {
                        pl.getOturumYoneticisi().cikisYap(hedefUUID);
                        hedef.kickPlayer(
                            "§6§lŞifren sıfırlandı!\n" +
                            "§eTekrar gir ve §a/kayitol §eyazarak yeni şifre belirle."
                        );
                        sender.sendMessage(PFX + "§7Oyuncu kick edildi.");
                    }
                });

            } catch (Exception e) {
                pl.getLogger().severe("[SifreSıfırla] " + hedefAd + " — " + e.getMessage());
                Bukkit.getScheduler().runTask(pl, () ->
                    sender.sendMessage(SPFX + "Şifre sıfırlama sırasında hata oluştu: " + e.getMessage()));
            }
        });
    }

    // ═══════════════════════════════════════════════════════════════════
    //  /sifredegistir <mevcutsifre> <yenisifre>
    // ═══════════════════════════════════════════════════════════════════

    private void handleSifreDegistir(CommandSender sender, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage(SPFX + "Bu komutu sadece oyuncular kullanabilir.");
            return;
        }
        UUID uuid = p.getUniqueId();

        if (!pl.getOturumYoneticisi().girisYapti(uuid)) {
            p.sendMessage(SPFX + "Önce giriş yapman lazım: §a/gir <şifre>");
            return;
        }
        if (args.length < 2) {
            p.sendMessage(PFX + "Kullanım: §a/sifredegistir <mevcutsifre> <yenisifre>");
            return;
        }

        String mevcutSifre = args[0];
        String yeniSifre   = args[1];

        if (yeniSifre.length() < pl.minSifreBoy()) {
            p.sendMessage(SPFX + "Yeni şifre en az §e" + pl.minSifreBoy() + " §ckarakter olmalı.");
            return;
        }
        if (yeniSifre.length() > pl.maxSifreBoy()) {
            p.sendMessage(SPFX + "Yeni şifre en fazla §e" + pl.maxSifreBoy() + " §ckarakter olabilir.");
            return;
        }
        if (mevcutSifre.equals(yeniSifre)) {
            p.sendMessage(SPFX + "Yeni şifren mevcut şifrenle aynı olamaz.");
            return;
        }

        File dosya = pl.datDosyasi(uuid);

        pl.asyncPool.submit(() -> {
            try {
                String mevcutHash = pl.getNbtDepo().hashOku(dosya);
                if (mevcutHash == null) {
                    Bukkit.getScheduler().runTask(pl, () ->
                        p.sendMessage(SPFX + "Şifre verisi okunamadı."));
                    return;
                }

                BCrypt.Result dogrulama = BCrypt.verifyer().verify(mevcutSifre.toCharArray(), mevcutHash);

                if (!dogrulama.verified) {
                    Bukkit.getScheduler().runTask(pl, () ->
                        p.sendMessage(SPFX + "Mevcut şifren yanlış!"));
                    return;
                }

                String yeniHash = BCrypt.withDefaults().hashToString(pl.bcryptCost(), yeniSifre.toCharArray());
                pl.getNbtDepo().hashYaz(dosya, yeniHash);

                Bukkit.getScheduler().runTask(pl, () ->
                    p.sendMessage(PFX + "§aŞifren başarıyla değiştirildi!"));

            } catch (Exception e) {
                pl.getLogger().severe("[SifreDegistir] " + uuid + " — " + e.getMessage());
                Bukkit.getScheduler().runTask(pl, () ->
                    p.sendMessage(SPFX + "Şifre değiştirme sırasında hata oluştu."));
            }
        });
    }

    // ═══════════════════════════════════════════════════════════════════
    //  /sifregeriyukle
    // ═══════════════════════════════════════════════════════════════════

    private void handleSifreGeriYukle(CommandSender sender) {
        if (!sender.hasPermission("giriseklentisi.op")) {
            sender.sendMessage(SPFX + "Bu komutu kullanmak için yetkin yok.");
            return;
        }

        File dbDosya = new File(pl.getDataFolder(), "LoginSecurity.db");

        if (!dbDosya.exists()) {
            sender.sendMessage(SPFX + "DB dosyası bulunamadı!");
            sender.sendMessage(PFX + "§7Dosyayı buraya koy: §e" + dbDosya.getAbsolutePath());
            return;
        }

        sender.sendMessage(PFX + "§eDB yükleniyor... (Bu işlem biraz sürebilir)");

        pl.asyncPool.submit(() -> {
            try {
                DBMigrasyonu migrasyon = new DBMigrasyonu(pl);
                int[] r = migrasyon.yukle(dbDosya);

                Bukkit.getScheduler().runTask(pl, () -> {
                    sender.sendMessage(PFX + "§a══════ Migrasyon Tamamlandı ══════");
                    sender.sendMessage(PFX + "§a✔ Başarıyla aktarılan : §f" + r[0] + " oyuncu");
                    sender.sendMessage(PFX + "§e⚡ Atlanan (dosya yok): §f" + r[1] + " oyuncu");
                    sender.sendMessage(PFX + "§c✖ Hata                : §f" + r[2] + " oyuncu");
                    sender.sendMessage(PFX + "§7══════════════════════════════════");

                    if (dbDosya.delete()) {
                        sender.sendMessage(PFX + "§aDB dosyası kalıcı olarak silindi. ✓");
                    } else {
                        sender.sendMessage(SPFX + "DB dosyası silinemedi! Elle sil: " + dbDosya.getAbsolutePath());
                    }
                });

            } catch (Exception e) {
                pl.getLogger().severe("[DBMigrasyon] " + e.getMessage());
                Bukkit.getScheduler().runTask(pl, () ->
                    sender.sendMessage(SPFX + "Migrasyon hatası: " + e.getMessage()));
            }
        });
    }
}
