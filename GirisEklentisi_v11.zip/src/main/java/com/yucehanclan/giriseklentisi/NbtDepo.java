package com.yucehanclan.giriseklentisi;

import net.querz.nbt.io.NBTUtil;
import net.querz.nbt.io.NamedTag;
import net.querz.nbt.tag.CompoundTag;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.time.Instant;

public class NbtDepo {

    private final GirisEklentisi pl;

    public NbtDepo(GirisEklentisi pl) {
        this.pl = pl;
    }

    public boolean kayitliMi(File dosya) {
        if (!dosya.exists()) return false;
        try {
            CompoundTag root = okuRoot(dosya);
            return root.containsKey(GirisEklentisi.NBT_HASH);
        } catch (Exception e) {
            return false;
        }
    }

    public String hashOku(File dosya) throws Exception {
        CompoundTag root = okuRoot(dosya);
        if (!root.containsKey(GirisEklentisi.NBT_HASH)) return null;
        byte[] sikistirilmis = root.getByteArray(GirisEklentisi.NBT_HASH);
        byte[] raw = pl.getSikistirmaMotoru().ac(sikistirilmis);
        return new String(raw, StandardCharsets.UTF_8);
    }

    public void hashYaz(File dosya, String bcryptHash) throws Exception {
        // p.saveData() çağrısından sonra dosya diske yazılmamış olabilir.
        // Dosya oluşana kadar en fazla 10 kez (toplam ~500ms) bekle.
        if (!dosya.exists()) {
            for (int i = 0; i < 10; i++) {
                Thread.sleep(50);
                if (dosya.exists()) break;
            }
        }
        if (!dosya.exists()) {
            throw new java.io.FileNotFoundException(
                "playerdata dosyasi bulunamadi (500ms beklendi): " + dosya.getName());
        }
        byte[] raw           = bcryptHash.getBytes(StandardCharsets.UTF_8);
        byte[] sikistirilmis = pl.getSikistirmaMotoru().sikistir(raw);

        NamedTag    nt   = NBTUtil.read(dosya);
        CompoundTag root = (CompoundTag) nt.getTag();

        root.putByteArray(GirisEklentisi.NBT_HASH, sikistirilmis);

        if (!root.containsKey(GirisEklentisi.NBT_KAYIT)) {
            root.putLong(GirisEklentisi.NBT_KAYIT, Instant.now().toEpochMilli());
        }
        root.putLong(GirisEklentisi.NBT_SON_GIRIS, Instant.now().toEpochMilli());

        atomikYaz(nt, dosya);
    }

    public void sonGirisiGuncelle(File dosya) throws Exception {
        if (!dosya.exists()) return;
        NamedTag    nt   = NBTUtil.read(dosya);
        CompoundTag root = (CompoundTag) nt.getTag();
        root.putLong(GirisEklentisi.NBT_SON_GIRIS, Instant.now().toEpochMilli());
        atomikYaz(nt, dosya);
    }

    public void hashSil(File dosya) throws Exception {
        NamedTag    nt   = NBTUtil.read(dosya);
        CompoundTag root = (CompoundTag) nt.getTag();
        root.remove(GirisEklentisi.NBT_HASH);
        atomikYaz(nt, dosya);
    }

    public boolean hashDirekMigre(File dosya, String bcryptHash, long kayitZamani) throws Exception {
        if (!dosya.exists()) return false;

        byte[] raw           = bcryptHash.getBytes(StandardCharsets.UTF_8);
        byte[] sikistirilmis = pl.getSikistirmaMotoru().sikistir(raw);

        NamedTag    nt   = NBTUtil.read(dosya);
        CompoundTag root = (CompoundTag) nt.getTag();

        root.putByteArray(GirisEklentisi.NBT_HASH, sikistirilmis);
        if (kayitZamani > 0) {
            root.putLong(GirisEklentisi.NBT_KAYIT, kayitZamani);
        }

        atomikYaz(nt, dosya);
        return true;
    }

    private CompoundTag okuRoot(File dosya) throws Exception {
        return (CompoundTag) NBTUtil.read(dosya).getTag();
    }

    private void atomikYaz(NamedTag nt, File hedef) throws Exception {
        File tmp = new File(hedef.getParent(), hedef.getName() + ".giris.tmp");
        try {
            NBTUtil.write(nt, tmp);
            Files.move(tmp.toPath(), hedef.toPath(),
                StandardCopyOption.REPLACE_EXISTING,
                StandardCopyOption.ATOMIC_MOVE);
        } catch (Exception e) {
            tmp.delete();
            throw e;
        }
    }
}
