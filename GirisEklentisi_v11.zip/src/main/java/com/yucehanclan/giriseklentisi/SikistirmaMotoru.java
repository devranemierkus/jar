package com.yucehanclan.giriseklentisi;

import java.io.*;
import java.util.logging.Logger;
import java.util.zip.*;

/**
 * Hafif sıkıştırma motoru — sadece DEFLATE kullanır.
 *
 * Neden eski sürüm crash yapıyordu:
 *  - 7 kombinasyon (DEFLATE+Brotli+XZ) async thread'de eş zamanlı çalışıyordu
 *  - XZ preset=9 çok RAM yiyor, birden fazla oyuncu kayıt olunca JVM crash
 *  - Brotli native kütüphanesi bazı sunucu ortamlarında JVM'i öldürüyor
 *
 * Yeni tasarım:
 *  - Sadece Java standart DEFLATE (dış kütüphane yok, native yok)
 *  - BCrypt hash zaten ~60 byte → kazanç zaten minimumdur
 *  - İlk byte bayrak korundu (eski verilerle geri uyumluluk)
 */
public class SikistirmaMotoru {

    private static final byte BAYRAK_HAM     = 0x00;
    private static final byte BAYRAK_DEFLATE = 0x01;

    private final Logger log;

    public SikistirmaMotoru(Logger log) {
        this.log = log;
        log.info("[Sıkıştırma] DEFLATE modu aktif (güvenli, hafif).");
    }

    public String aktifMotorlarStr() {
        return "DEFLATE(6)";
    }

    public byte[] sikistir(byte[] veri) throws IOException {
        if (veri.length == 0) {
            return new byte[]{ BAYRAK_HAM };
        }
        byte[] deflated = deflate(veri);
        if (deflated.length >= veri.length) {
            byte[] sonuc = new byte[1 + veri.length];
            sonuc[0] = BAYRAK_HAM;
            System.arraycopy(veri, 0, sonuc, 1, veri.length);
            return sonuc;
        }
        byte[] sonuc = new byte[1 + deflated.length];
        sonuc[0] = BAYRAK_DEFLATE;
        System.arraycopy(deflated, 0, sonuc, 1, deflated.length);
        return sonuc;
    }

    public byte[] ac(byte[] veri) throws IOException {
        if (veri.length < 1) throw new IOException("Geçersiz sıkıştırılmış veri (boş).");
        byte bayrak = (byte)(veri[0] & 0x0F);
        byte[] yuk  = new byte[veri.length - 1];
        System.arraycopy(veri, 1, yuk, 0, yuk.length);

        // Eski multi-layer bayrakları için geri uyumluluk
        return switch (bayrak) {
            case 0x00 -> yuk;
            case 0x01 -> deflateAc(yuk);
            case 0x02 -> yuk;
            case 0x03 -> deflateAc(yuk);
            case 0x04 -> yuk;
            case 0x05 -> deflateAc(yuk);
            case 0x06 -> yuk;
            case 0x07 -> deflateAc(yuk);
            default   -> yuk;
        };
    }

    private byte[] deflate(byte[] input) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream(input.length);
        Deflater def = new Deflater(6, true);
        try (DeflaterOutputStream out = new DeflaterOutputStream(bos, def)) {
            out.write(input);
        }
        def.end();
        return bos.toByteArray();
    }

    private byte[] deflateAc(byte[] input) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream(input.length * 3);
        try (InflaterInputStream in = new InflaterInputStream(
                new ByteArrayInputStream(input), new Inflater(true))) {
            in.transferTo(bos);
        }
        return bos.toByteArray();
    }
}
