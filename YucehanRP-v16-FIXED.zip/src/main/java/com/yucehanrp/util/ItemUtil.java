package com.yucehanrp.util;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.LeatherArmorMeta;
import java.awt.Color;
import java.util.List;

public class ItemUtil {

    public static ItemStack make(Material mat, String name, String loreRaw) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(C.c(name));
            if (loreRaw != null && !loreRaw.isEmpty()) {
                meta.setLore(C.lore(loreRaw));
            }
            item.setItemMeta(meta);
        }
        return item;
    }

    public static ItemStack make(Material mat, String name) {
        return make(mat, name, null);
    }

    public static ItemStack makeGlass(org.bukkit.DyeColor color, String name) {
        Material mat = switch (color) {
            case GRAY       -> Material.GRAY_STAINED_GLASS_PANE;
            case LIGHT_GRAY -> Material.LIGHT_GRAY_STAINED_GLASS_PANE;
            case ORANGE     -> Material.ORANGE_STAINED_GLASS_PANE;
            case LIME       -> Material.LIME_STAINED_GLASS_PANE;
            case RED        -> Material.RED_STAINED_GLASS_PANE;
            case WHITE      -> Material.WHITE_STAINED_GLASS_PANE;
            case BLUE       -> Material.BLUE_STAINED_GLASS_PANE;
            case LIGHT_BLUE -> Material.LIGHT_BLUE_STAINED_GLASS_PANE;
            case YELLOW     -> Material.YELLOW_STAINED_GLASS_PANE;
            case GREEN      -> Material.GREEN_STAINED_GLASS_PANE;
            case BLACK      -> Material.BLACK_STAINED_GLASS_PANE;
            case CYAN       -> Material.CYAN_STAINED_GLASS_PANE;
            case MAGENTA    -> Material.MAGENTA_STAINED_GLASS_PANE;
            case PINK       -> Material.PINK_STAINED_GLASS_PANE;
            case PURPLE     -> Material.PURPLE_STAINED_GLASS_PANE;
            case BROWN      -> Material.BROWN_STAINED_GLASS_PANE;
            default         -> Material.GRAY_STAINED_GLASS_PANE;
        };
        return make(mat, name);
    }

    public static ItemStack makeLeatherArmor(Material mat, Color color, String name) {
        ItemStack item = new ItemStack(mat);
        LeatherArmorMeta meta = (LeatherArmorMeta) item.getItemMeta();
        if (meta != null) {
            meta.setColor(org.bukkit.Color.fromRGB(color.getRed(), color.getGreen(), color.getBlue()));
            meta.setDisplayName(C.c(name));
            item.setItemMeta(meta);
        }
        return item;
    }

    // FIX: displayName artık stripColor kullanıyor — Paper 1.21.4'te
    // getDisplayName() bazen farklı renk kodu formatı döndürüyor,
    // stripColor ile normalize edince tüm karşılaştırmalar güvenli çalışır.
    public static String displayName(ItemStack item) {
        if (item == null) return "null";
        ItemMeta meta = item.getItemMeta();
        if (meta != null && meta.hasDisplayName()) {
            return meta.getDisplayName();
        }
        return item.getType().name();
    }

    // FIX: Karşılaştırmalar için strip edilmiş isim döndür
    public static String displayNameStripped(ItemStack item) {
        return C.strip(displayName(item));
    }

    public static String uncoloredName(ItemStack item) {
        return C.strip(displayName(item));
    }

    public static boolean nameContains(ItemStack item, String text) {
        return uncoloredName(item).contains(text);
    }

    public static boolean hasLoreContaining(ItemStack item, String text) {
        if (item == null) return false;
        ItemMeta meta = item.getItemMeta();
        if (meta == null || !meta.hasLore()) return false;
        List<String> lore = meta.getLore();
        if (lore == null) return false;
        for (String line : lore) {
            if (C.strip(line).contains(text)) return true;
        }
        return false;
    }

    public static ItemStack fillSlot() {
        return make(Material.GRAY_STAINED_GLASS_PANE, "&8.");
    }
}
