package com.yucehanrp.listeners;

import com.yucehanrp.SessionData;
import com.yucehanrp.managers.*;
import com.yucehanrp.util.C;
import com.yucehanrp.util.ItemUtil;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import java.util.UUID;

public class InventoryClickListener implements Listener {
    private final SessionData data;
    private final GamesMenuManager gamesMenu;
    private final PvpSumoManager pvpSumo;
    private final MiniGamesManager miniGames;
    private final KatilKimManager katilKim;
    private final BedWarsManager bedWars;
    private final GameHeadManager headManager;
    private final MarketManager market;
    private final MarketGUIManager marketGui;
    private final TntTagManager tntTag;

    public InventoryClickListener(SessionData data, GamesMenuManager gamesMenu,
            PvpSumoManager pvpSumo, MiniGamesManager miniGames, KatilKimManager katilKim,
            BedWarsManager bedWars, GameHeadManager headManager, MarketManager market,
            MarketGUIManager marketGui, TntTagManager tntTag) {
        this.data = data; this.gamesMenu = gamesMenu; this.pvpSumo = pvpSumo;
        this.miniGames = miniGames; this.katilKim = katilKim; this.bedWars = bedWars;
        this.headManager = headManager; this.market = market; this.marketGui = marketGui;
        this.tntTag = tntTag;
    }

    // FIX: Menü başlığı ve item ismi karşılaştırmalarında strip() kullan
    private String strip(String s) { return ChatColor.stripColor(s); }
    private String titleOf(InventoryClickEvent e) { return strip(e.getView().getTitle()); }
    private String nameOf(ItemStack item) { return strip(ItemUtil.displayName(item)); }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        UUID uuid = player.getUniqueId();

        // FIX: AFK sayacını tıklamada güncelle (inventory oyunlarında kick olmasın)
        data.afkLastActivity.put(uuid, System.currentTimeMillis());

        String title = titleOf(event);
        ItemStack clicked = event.getCurrentItem();
        String name = clicked != null ? nameOf(clicked) : "";

        // Oyunlar kafası numara tuşuyla değişmesin
        if (event.getClick() == ClickType.NUMBER_KEY) {
            if (headManager.isGameHead(player.getInventory().getItem(0))) {
                event.setCancelled(true); return;
            }
        }

        if (event.getClick() == ClickType.SWAP_OFFHAND) {
            if (headManager.isGameHead(clicked) || headManager.isGameHead(player.getInventory().getItem(0))) {
                event.setCancelled(true);
                player.sendActionBar(C.c("&c[OYUNLAR]Kafa tasinamaz!"));
                return;
            }
        }

        if (headManager.isGameHead(clicked)) {
            event.setCancelled(true);
            ItemStack cursor = event.getCursor();
            if (cursor != null && cursor.getType() != Material.AIR) {
                player.sendActionBar(C.c("&c[OYUNLAR]Oyunlarin yerine item koyamazsin!"));
                event.getView().setCursor(null);
                player.getInventory().addItem(cursor);
            }
            return;
        }

        if (headManager.isGameHead(event.getCursor())) {
            event.setCancelled(true);
            event.getView().setCursor(null);
            player.getInventory().setItem(0, headManager.makeGameHead());
            player.sendActionBar(C.c("&c[OYUNLAR]Kafa tasinamaz!Hep slot 1'de."));
            return;
        }

        // BedWars zırh koruma
        if (data.bwTeam.containsKey(uuid)) {
            // BUG-C FIX: si==36-39 check KALDIRILDI.
            // Bu rawSlot'lar shop GUI'ındaki Altın Elma/Ender İnci/Ekmek/Biftek slotlarıdır.
            // Gerçek armor rawSlot'ları player CRAFTING view'da 5-8'dir.
            // Shift-click ve number_key korumaları zaten item type ile doğru çalışıyor.
            if (event.getClick() == ClickType.NUMBER_KEY) {
                int hotbar = event.getHotbarButton();
                ItemStack hotbarItem = player.getInventory().getItem(hotbar);
                if (hotbarItem != null) {
                    String t = hotbarItem.getType().name();
                    if (t.endsWith("_HELMET") || t.endsWith("_CHESTPLATE") || t.endsWith("_LEGGINGS") || t.endsWith("_BOOTS")) {
                        event.setCancelled(true); return;
                    }
                }
            }
            if (event.getClick().isShiftClick() && clicked != null) {
                String t = clicked.getType().name();
                if (t.endsWith("_HELMET") || t.endsWith("_CHESTPLATE") || t.endsWith("_LEGGINGS") || t.endsWith("_BOOTS")) {
                    event.setCancelled(true); return;
                }
            }
        }

        // ===== OYUNLAR MENUSU =====
        // FIX: strip() ile karşılaştır — Paper 1.21.4 renk kodu farkını eliyor
        if (title.equals("Oyunlar Menusu")) {
            event.setCancelled(true);
            if      (name.equals("PVP"))           { player.closeInventory(); gamesMenu.openPvpMenu(player); }
            else if (name.equals("SUMO"))          { player.closeInventory(); gamesMenu.openSumoMenu(player); }
            else if (name.equals("FLAPPY BIRD"))   { player.closeInventory(); miniGames.startFlappy(player); }
            else if (name.equals("YILAN"))         { player.closeInventory(); miniGames.startSnake(player); }
            else if (name.equals("RENK ESLESTIR")) { player.closeInventory(); miniGames.startTarget(player); }
            else if (name.equals("SIMON SAYS"))    { player.closeInventory(); miniGames.startSimon(player); }
            else if (name.equals("HIZLI TIKLAMA")) { player.closeInventory(); miniGames.startReflex(player); }
            else if (name.equals("KATIL KIM"))     { player.closeInventory(); katilKim.lobiGir(player); }
            else if (name.equals("BED WARS"))      { player.closeInventory(); bedWars.bwLobiGir(player); }
            else if (name.equals("TNT EBELEMECE")) { player.closeInventory(); tntTag.katil(player); }
            return;
        }

        // TNT slot 0 koruması
        if (data.tntPlayers.contains(uuid)) {
            int si = event.getRawSlot();
            if (si == 0) { event.setCancelled(true); return; }
            if (event.getClick() == ClickType.NUMBER_KEY && event.getHotbarButton() == 0) {
                event.setCancelled(true); return;
            }
            if (event.getClick().isShiftClick() && si == 0) { event.setCancelled(true); return; }
        }

        // PVP Menü
        if (title.equals("PVP Alani")) {
            event.setCancelled(true);
            if      (name.equals("GIR!"))     { player.closeInventory(); pvpSumo.startPvp(player); }
            else if (name.equals("GERI DON")) { player.closeInventory(); gamesMenu.openGamesMenu(player); }
            return;
        }

        // Sumo Menü
        if (title.equals("Sumo Alani")) {
            event.setCancelled(true);
            if      (name.equals("GIR!"))     { player.closeInventory(); pvpSumo.startSumo(player); }
            else if (name.equals("GERI DON")) { player.closeInventory(); gamesMenu.openGamesMenu(player); }
            return;
        }

        // Flappy Bird
        if (title.equals("Flappy Bird")) {
            event.setCancelled(true);
            if (!data.flappyActive.containsKey(uuid)) return;
            int slot = event.getRawSlot();
            if (slot == 31) miniGames.flappyJump(player);
            else if (slot == 35) miniGames.stopFlappy(player);
            return;
        }

        // Yilan
        if (title.equals("Yilan Oyunu")) {
            event.setCancelled(true);
            if (!data.snakeActive.containsKey(uuid)) return;
            String dir = data.snakeDir.getOrDefault(uuid, "r");
            if      (name.equals("<SOL")  && !dir.equals("r")) data.snakeDir.put(uuid, "l");
            else if (name.equals("v ASAGI") && !dir.equals("u")) data.snakeDir.put(uuid, "d");
            else if (name.equals("^YUKARI") && !dir.equals("d")) data.snakeDir.put(uuid, "u");
            else if (name.equals(">SAG")  && !dir.equals("l")) data.snakeDir.put(uuid, "r");
            else if (name.equals("CIKIS")) miniGames.stopSnake(player);
            return;
        }

        // Renk Eslestirme
        if (title.equals("Renk Eslestirme")) {
            event.setCancelled(true);
            if (!data.targetActive.containsKey(uuid)) return;
            int rawSlot = event.getRawSlot();
            if (rawSlot == 53) { miniGames.stopTarget(player); return; }
            if (rawSlot >= 45) return;
            int dogruSlot = data.targetTick.getOrDefault(uuid, -1);
            String clickedName = clicked != null ? nameOf(clicked) : "";
            if (clickedName.equals("TIKLA!")) miniGames.hitTarget(player);
            else if (rawSlot != dogruSlot)    miniGames.hitTargetWrong(player);
            return;
        }

        // Reflex
        if (title.equals("Reflex Oyunu")) {
            event.setCancelled(true);
            if (!data.reflexActive.containsKey(uuid)) return;
            if (event.getRawSlot() == 53) miniGames.stopReflex(player);
            else if (name.equals("TIKLA!")) miniGames.reflexClick(player);
            return;
        }

        // Market
        if (title.equals("OYUNCU MARKETI")) {
            event.setCancelled(true);
            int slot = event.getRawSlot();
            int n = market.guiSlotToN(slot);
            if (n > 0 && data.marketItem.containsKey(n)) {
                String owner = data.marketOwner.getOrDefault(n, "");
                if (owner.equals(player.getName())) {
                    player.closeInventory();
                    ItemStack mi = data.marketItem.get(n);
                    String mname = mi != null ? nameOf(mi) : "?";
                    data.marketBuyConfirm.remove(uuid);
                    player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                    player.sendMessage(C.c("&c&l TEZGAH KALDIRMA ONAYI"));
                    player.sendMessage(C.c("&7Urun:&f" + mname));
                    player.sendMessage(C.c("&cTezgahini kaldirmak istiyor musun?"));
                    player.sendMessage(C.c("&a&levet&8veya&c&lhayir&7yaz!"));
                    player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                    data.marketBuyConfirm.put(uuid, -n);
                } else {
                    player.closeInventory();
                    int price = data.marketPrice.getOrDefault(n, 0);
                    String currency = data.marketCurrency.getOrDefault(n, "zumrut");
                    ItemStack mi = data.marketItem.get(n);
                    player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                    player.sendMessage(C.c("&6&l SATIN ALMA ONAYI"));
                    player.sendMessage(C.c("&7Urun:&f" + (mi != null ? nameOf(mi) : "?")));
                    player.sendMessage(C.c("&7Fiyat:&f" + price + " " + ("elmas".equals(currency) ? "&bElmas" : "&eZumrut")));
                    player.sendMessage(C.c("&7Satici:&f" + owner));
                    player.sendMessage(C.c("&aSatin almak istiyor musun?"));
                    player.sendMessage(C.c("&a&levet&8veya&c&lhayir&7yaz!&8(Iptal:/marketiptal)"));
                    player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                    data.marketBuyConfirm.put(uuid, n);
                }
            } else if (name.equals("TEZGAH KUR")) {
                player.closeInventory();
                Long cdStart = data.marketCooldown.get(uuid);
                if (cdStart != null && System.currentTimeMillis() - cdStart < 3 * 60 * 1000L) {
                    long kalan = (3 * 60 * 1000L - (System.currentTimeMillis() - cdStart)) / 1000;
                    player.sendMessage(C.c("&c&l[MARKET]&7Tezgah kurma cooldownu!&eKalan:" + (kalan / 60) + "dk " + (kalan % 60) + "sn"));
                    return;
                }
                Bukkit.getScheduler().runTask((org.bukkit.plugin.Plugin) Bukkit.getPluginManager().getPlugin("YucehanRP"), () -> marketGui.openTezgahKur(player));
            } else if (name.equals("TEZGAHIMI KALDIR")) {
                player.closeInventory();
                int ownerSlot = market.findOwnerSlot(player.getName());
                if (ownerSlot > 0) {
                    ItemStack mi = data.marketItem.get(ownerSlot);
                    if (mi != null) player.getInventory().addItem(mi.clone());
                    market.clearSlot(ownerSlot);
                    player.sendMessage(C.c("&a[MARKET]&7Tezgahin kaldirildi,item iade edildi."));
                    player.sendMessage(C.c("&c&l[MARKET]&73 dakika tezgah kurma cooldownu basladi!"));
                    data.marketCooldown.put(uuid, System.currentTimeMillis());
                } else {
                    player.sendMessage(C.c("&c[MARKET]&7Aktif tezgahin yok."));
                }
            } else if (name.equals("KAPAT")) {
                player.closeInventory();
            }
            return;
        }

        // Tezgah Kur
        if (title.equals("TEZGAH KUR")) {
            event.setCancelled(true);
            int rawSlot = event.getRawSlot();
            if (rawSlot >= 27) return;
            if (name.equals("SAT")) {
                String cur = data.marketPendingCurrency.getOrDefault(uuid, "zumrut");
                int freeSlot = market.findFreeSlot();
                if (freeSlot == 0) { player.sendActionBar(C.c("&c[MARKET]&7Tum tezgahlar dolu!")); return; }
                ItemStack satilikItem = null;
                ItemStack slotIki = player.getInventory().getItem(1);
                if (slotIki != null && slotIki.getType() != Material.AIR
                        && !ItemUtil.hasLoreContaining(slotIki, "KOPYALANAMAZ")
                        && !ItemUtil.hasLoreContaining(slotIki, "YUCECELL A.S.")
                        && !headManager.isGameHead(slotIki)) {
                    satilikItem = slotIki;
                }
                if (satilikItem == null) {
                    player.sendActionBar(C.c("&c[MARKET]&7Satilacak esyayi envanterinin 2.slotuna koy!")); return;
                }
                market.reserveSlot(freeSlot);
                data.marketPendingSlot.put(uuid, freeSlot);
                data.marketPendingItem.put(uuid, satilikItem.clone());
                data.marketWaitingAmount.put(uuid, true);
                player.closeInventory();
                player.sendMessage(C.c("&6&l KAC ADET SATIYORSUN?"));
                player.sendMessage(C.c("&7Adet chat'e yaz (1-" + satilikItem.getAmount() + ")"));
                player.sendMessage(C.c("&cIptal:/marketiptal"));
            } else if (name.equals("PARA:ELMAS")) {
                data.marketPendingCurrency.put(uuid, "zumrut");
                marketGui.refreshTezgahKurGui(player);
            } else if (name.equals("PARA:ZUMRUT")) {
                data.marketPendingCurrency.put(uuid, "elmas");
                marketGui.refreshTezgahKurGui(player);
            } else if (name.equals("IPTAL")) {
                Integer ps = data.marketPendingSlot.remove(uuid);
                if (ps != null) data.marketReserved.remove(ps);
                data.marketPendingItem.remove(uuid);
                data.marketPendingCurrency.remove(uuid);
                player.closeInventory();
                Bukkit.getScheduler().runTask((org.bukkit.plugin.Plugin) Bukkit.getPluginManager().getPlugin("YucehanRP"), () -> marketGui.openMarket(player));
            }
            return;
        }

        // BW Mağaza
        if (title.contains("BED WARS MAGAZA")) {
            event.setCancelled(true);
            if (!data.bwActive || !data.bwTeam.containsKey(uuid)) return;
            int demir = countItem(player, Material.IRON_INGOT);
            int altin = countItem(player, Material.GOLD_INGOT);
            int elmas = countItem(player, Material.DIAMOND);
            switch (name) {
                case "Tas Kilic"    -> bwSatin(player, Material.STONE_SWORD,    1,  8, "demir", demir, altin, elmas);
                case "Demir Kilic"  -> bwSatin(player, Material.IRON_SWORD,     1, 15, "demir", demir, altin, elmas);
                case "Elmas Kilic"  -> bwSatin(player, Material.DIAMOND_SWORD,  1, 10, "altin", demir, altin, elmas);
                case "Balta"        -> bwSatin(player, Material.WOODEN_AXE,     1,  6, "demir", demir, altin, elmas);
                case "Odun Kazma"   -> bwSatin(player, Material.WOODEN_PICKAXE, 1,  5, "demir", demir, altin, elmas);
                case "Tas Kazma"    -> bwSatin(player, Material.STONE_PICKAXE,  1, 10, "demir", demir, altin, elmas);
                case "Demir Kazma"  -> bwSatin(player, Material.IRON_PICKAXE,   1,  6, "altin", demir, altin, elmas);
                case "Elmas Kazma"  -> bwSatin(player, Material.DIAMOND_PICKAXE,1, 12, "altin", demir, altin, elmas);
                case "Deri Zirh Seti" -> bwSatinZirh(player, 12, demir);
                case "Demir Gogusluk" -> bwSatin(player, Material.IRON_CHESTPLATE,1,8,"altin",demir,altin,elmas);
                case "Demir Kask"   -> bwSatin(player, Material.IRON_HELMET,    1,  5, "altin", demir, altin, elmas);
                case "Yun Blok x16" -> bwSatin(player, Material.WHITE_WOOL,    16,  6, "demir", demir, altin, elmas);
                case "Tas x16"      -> bwSatin(player, Material.SANDSTONE,      16, 9, "demir", demir, altin, elmas);
                case "Tahta x16"    -> bwSatin(player, Material.OAK_PLANKS,     16, 5, "demir", demir, altin, elmas);
                case "Cam x8"       -> bwSatin(player, Material.GLASS,           8, 4, "demir", demir, altin, elmas);
                case "Obsidyen x2"  -> bwSatin(player, Material.OBSIDIAN,        2,10, "altin", demir, altin, elmas);
                case "Bow"          -> bwSatin(player, Material.BOW,             1,  9, "demir", demir, altin, elmas);
                case "Ok x16"       -> bwSatin(player, Material.ARROW,          16,  4, "demir", demir, altin, elmas);
                case "Ip"           -> bwSatin(player, Material.FISHING_ROD,     1,  8, "demir", demir, altin, elmas);
                case "Altin Elma"   -> bwSatin(player, Material.GOLDEN_APPLE,    1,  5, "altin", demir, altin, elmas);
                case "Ender Inci"   -> bwSatin(player, Material.ENDER_PEARL,     1,  4, "altin", demir, altin, elmas);
                case "Ekmek x5"     -> bwSatin(player, Material.BREAD,           5,  4, "demir", demir, altin, elmas);
                case "Biftek x3"    -> bwSatin(player, Material.COOKED_BEEF,     3,  6, "demir", demir, altin, elmas);
                case "KAPAT"        -> player.closeInventory();
            }
            return;
        }
    }

    private void bwSatin(Player player, Material give, int amount, int cost, String currency,
                         int demir, int altin, int elmas) {
        int sahip = "demir".equals(currency) ? demir : "altin".equals(currency) ? altin : elmas;
        Material mat = "demir".equals(currency) ? Material.IRON_INGOT : "altin".equals(currency) ? Material.GOLD_INGOT : Material.DIAMOND;
        if (sahip >= cost) {
            removeExact(player, mat, cost);
            player.getInventory().addItem(new ItemStack(give, amount));
            player.sendActionBar(C.c("&a alindi!"));
        } else {
            String paraIsim = "demir".equals(currency) ? "Demir" : "altin".equals(currency) ? "Altin" : "Elmas";
            player.sendActionBar(C.c("&c Yetersiz " + paraIsim + "!&7Lazim:&e" + cost + "&7/Sahip:&c" + sahip));
        }
    }

    private void bwSatinZirh(Player player, int cost, int demir) {
        if (demir >= cost) {
            removeExact(player, Material.IRON_INGOT, cost);
            player.getInventory().addItem(new ItemStack(Material.LEATHER_HELMET));
            player.getInventory().addItem(new ItemStack(Material.LEATHER_CHESTPLATE));
            player.getInventory().addItem(new ItemStack(Material.LEATHER_LEGGINGS));
            player.getInventory().addItem(new ItemStack(Material.LEATHER_BOOTS));
            player.sendActionBar(C.c("&a Deri Zirh Seti alindi!"));
        } else {
            player.sendActionBar(C.c("&c Yetersiz Demir!&7Lazim:&e" + cost + "&7/Sahip:&c" + demir));
        }
    }

    private int countItem(Player player, Material mat) {
        int count = 0;
        for (ItemStack item : player.getInventory().getContents()) {
            if (item != null && item.getType() == mat) count += item.getAmount();
        }
        return count;
    }

    private void removeExact(Player player, Material mat, int amount) {
        int remaining = amount;
        ItemStack[] contents = player.getInventory().getContents();
        for (int i = 0; i < contents.length && remaining > 0; i++) {
            ItemStack it = contents[i];
            if (it != null && it.getType() == mat) {
                int take = Math.min(remaining, it.getAmount());
                it.setAmount(it.getAmount() - take);
                remaining -= take;
                if (it.getAmount() <= 0) contents[i] = null;
            }
        }
        player.getInventory().setContents(contents);
    }

    @EventHandler
    public void onClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player player)) return;
        UUID uuid = player.getUniqueId();
        String title = strip(event.getView().getTitle());

        if (title.equals("Oyunlar Menusu")) headManager.giveGameHead(player);
        if (title.equals("PVP Alani"))      headManager.giveGameHead(player);
        if (title.equals("Sumo Alani"))     headManager.giveGameHead(player);

        // FIX: Flappy ve Yilan close handler eklendi — Escape'e basınca oyun
        // durumu temizleniyor, isInAnyGame() artık false dönüyor
        if (title.equals("Flappy Bird") && data.flappyActive.containsKey(uuid)) {
            miniGames.stopFlappy(player);
        }
        if (title.equals("Yilan Oyunu") && data.snakeActive.containsKey(uuid)) {
            miniGames.stopSnake(player);
        }

        if (title.equals("Renk Eslestirme") && data.targetActive.containsKey(uuid)) {
            miniGames.stopTarget(player);
        }
        if (title.equals("Reflex Oyunu") && data.reflexActive.containsKey(uuid)) {
            if (!data.reflexTransition.containsKey(uuid)) miniGames.stopReflex(player);
        }
        if (title.equals("TEZGAH KUR")) {
            if (!data.marketWaitingPrice.containsKey(uuid) && !data.marketWaitingAmount.containsKey(uuid)) {
                Integer ps = data.marketPendingSlot.remove(uuid);
                if (ps != null) data.marketReserved.remove(ps);
                data.marketPendingItem.remove(uuid);
                data.marketPendingCurrency.remove(uuid);
            }
        }
    }

    @EventHandler
    public void onSwapHand(PlayerSwapHandItemsEvent event) {
        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();
        if (headManager.isGameHead(event.getMainHandItem()) || headManager.isGameHead(event.getOffHandItem())) {
            event.setCancelled(true);
            player.sendActionBar(C.c("&c[OYUNLAR]Kafa tasinamaz!"));
            return;
        }
        if (data.bwTeam.containsKey(uuid)) {
            ItemStack main = event.getMainHandItem();
            ItemStack off  = event.getOffHandItem();
            String mt = main != null ? main.getType().name() : "";
            String ot = off  != null ? off.getType().name()  : "";
            if (mt.endsWith("_HELMET") || mt.endsWith("_CHESTPLATE") || mt.endsWith("_LEGGINGS") || mt.endsWith("_BOOTS")
             || ot.endsWith("_HELMET") || ot.endsWith("_CHESTPLATE") || ot.endsWith("_LEGGINGS") || ot.endsWith("_BOOTS")) {
                event.setCancelled(true);
            }
        }
    }
}
