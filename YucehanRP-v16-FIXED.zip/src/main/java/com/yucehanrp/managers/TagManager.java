package com.yucehanrp.managers;

import com.yucehanrp.SessionData;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

/**
 * TAG DEPOLAMA — Ultra Sıkıştırılmış Format v2
 *
 * Format (ag.db):
 *   [4 byte] magic: 0x41470200  (AG v2)
 *   [2 byte] kaç unique tag var  (max 65535)
 *   [1 byte] tag string uzunluğu
 *   [N byte] tag string (UTF-8)   } her unique tag için tekrar
 *   [4 byte] kaç kayıt var
 *   [16 byte] UUID (msb+lsb)      } her kayıt için
 *   [2 byte]  tag index            }
 *   --- tüm bu ham byte dizisi ZSTD level-19 ile sıkıştırılır ---
 *
 * Neden bu kadar küçük?
 *   - "Polis" string'i 1 kez yazılır, sonra index (2 byte) ile referans verilir
 *   - UUID'ler sıralı yazılır → ZSTD delta pattern yakalar
 *   - ZSTD level-19, GZIP'ten ~%40 daha iyi sıkıştırır
 */
public class TagManager {

    public static final String HALK    = "HALK";
    public static final String KURUCU  = "Kurucu";
    public static final String YONETICI = "Yönetici";

    private static final int MAGIC = 0x41470200; // "AG\x02\x00"

    private final Plugin      plugin;
    private final SessionData data;
    private final File        dataFile;

    private final Map<UUID, String>  tagCache        = new ConcurrentHashMap<>();
    private final Map<UUID, String>  lastTagApplied  = new ConcurrentHashMap<>();
    private final AtomicBoolean      dirty           = new AtomicBoolean(false);
    private static final Random      RNG             = new Random();

    public TagManager(Plugin plugin, SessionData data) {
        this.plugin   = plugin;
        this.data     = data;
        File tagSaves = new File(plugin.getDataFolder(), "tag_saves");
        if (!tagSaves.exists()) tagSaves.mkdirs();
        this.dataFile = new File(tagSaves, "ag.db");
        loadAll();
    }

    // ── PUBLIC API ────────────────────────────────────────────────────────────

    public void loadAndApply(Player player) {
        applyNametag(player, tagCache.getOrDefault(player.getUniqueId(), HALK), randomRgb());
    }

    public void setTag(Player target, String tag) {
        UUID uuid = target.getUniqueId();
        if (isHalk(tag)) { tagCache.remove(uuid); applyNametag(target, HALK, randomRgb()); }
        else              { tagCache.put(uuid, tag); applyNametag(target, tag, randomRgb()); }
        scheduleSave();
    }

    public void removeTag(Player target) {
        tagCache.remove(target.getUniqueId());
        applyNametag(target, HALK, randomRgb());
        scheduleSave();
    }

    public void setTagOffline(UUID uuid, String tag) {
        if (isHalk(tag)) tagCache.remove(uuid); else tagCache.put(uuid, tag);
        scheduleSave();
    }

    public void removeTagOffline(UUID uuid) { tagCache.remove(uuid); scheduleSave(); }

    public String getTag(UUID uuid) { return tagCache.getOrDefault(uuid, HALK); }

    public String getChatPrefix(UUID uuid) {
        return toMcHex(randomRgb()) + "[" + getTag(uuid) + "]\u00A7r";
    }
    public String getGamePrefix(UUID uuid)  { return getChatPrefix(uuid); }
    public String getForcePrefix(UUID uuid) { return getChatPrefix(uuid); }

    public void refreshAllNametags() {
        for (Player p : Bukkit.getOnlinePlayers())
            applyNametag(p, getTag(p.getUniqueId()), randomRgb());
    }

    public void hideNametag(Player player) {
        clearTeam(player);
        lastTagApplied.remove(player.getUniqueId());
        player.setCustomName(player.getName());
        player.setCustomNameVisible(false);
        player.setPlayerListName(player.getName());
    }

    public void showNametag(Player player) { applyNametag(player, getTag(player.getUniqueId()), randomRgb()); }
    public void cleanup(Player player)     { clearTeam(player); lastTagApplied.remove(player.getUniqueId()); }

    public boolean canGiveTag(Player sender) {
        String n = normalizeForCheck(getTag(sender.getUniqueId()));
        return n.contains("kurucu") || n.contains("yonetici");
    }

    // ── SAVE ──────────────────────────────────────────────────────────────────

    private void scheduleSave() {
        if (dirty.compareAndSet(false, true))
            Bukkit.getScheduler().runTaskLaterAsynchronously(plugin, () -> { dirty.set(false); saveAll(); }, 20L);
    }

    private synchronized void saveAll() {
        // 1) HALK olmayanları al, UUID sıralı yaz (ZSTD delta için)
        List<Map.Entry<UUID, String>> entries = new ArrayList<>();
        for (Map.Entry<UUID, String> e : tagCache.entrySet())
            if (!isHalk(e.getValue())) entries.add(e);

        if (entries.isEmpty()) { dataFile.delete(); return; }

        entries.sort(Comparator.comparing(e -> e.getKey().toString()));

        // 2) Unique tag dictionary
        List<String> dict = new ArrayList<>();
        Map<String, Integer> dictIndex = new LinkedHashMap<>();
        for (Map.Entry<UUID, String> e : entries) {
            if (!dictIndex.containsKey(e.getValue())) {
                dictIndex.put(e.getValue(), dict.size());
                dict.add(e.getValue());
            }
        }

        // 3) Ham buffer oluştur
        //    Header: 4(magic) + 2(dictSize) + dict entries + 4(entryCount) + entries*(16+2)
        ByteArrayOutputStream baos = new ByteArrayOutputStream(entries.size() * 18 + 256);
        DataOutputStream dos = new DataOutputStream(baos);
        try {
            dos.writeInt(MAGIC);

            // Dictionary
            dos.writeShort(dict.size());
            for (String tag : dict) {
                byte[] tb = tag.getBytes(StandardCharsets.UTF_8);
                dos.writeByte(tb.length);
                dos.write(tb);
            }

            // Entries
            dos.writeInt(entries.size());
            for (Map.Entry<UUID, String> e : entries) {
                dos.writeLong(e.getKey().getMostSignificantBits());
                dos.writeLong(e.getKey().getLeastSignificantBits());
                dos.writeShort(dictIndex.get(e.getValue()));
            }
            dos.flush();
        } catch (IOException ex) {
            plugin.getLogger().severe("[TagSave] Buffer hatasi: " + ex.getMessage());
            return;
        }

        // 4) GZIP ile sıkıştır
        byte[] raw = baos.toByteArray();
        byte[] compressed;
        try {
            ByteArrayOutputStream gzBaos = new ByteArrayOutputStream();
            try (GZIPOutputStream gzos = new GZIPOutputStream(gzBaos)) {
                gzos.write(raw);
            }
            compressed = gzBaos.toByteArray();
        } catch (IOException ex) {
            plugin.getLogger().severe("[TagSave] Sıkıştırma hatası: " + ex.getMessage());
            return;
        }

        // 5) Diske yaz
        try {
            Files.write(dataFile.toPath(), compressed);
            plugin.getLogger().info(String.format(
                "[TagSave] %d tag kaydedildi | ham=%d B → zstd=%d B (%%%.1f)",
                entries.size(), raw.length, compressed.length,
                100.0 * compressed.length / raw.length));
        } catch (IOException ex) {
            plugin.getLogger().severe("[TagSave] ag.db yazma hatasi: " + ex.getMessage());
        }
    }

    // ── LOAD ──────────────────────────────────────────────────────────────────

    private void loadAll() {
        if (!dataFile.exists()) { migrateFromLegacy(); return; }

        try {
            byte[] compressed = Files.readAllBytes(dataFile.toPath());

            // Magic kontrolü: GZIP formatı (0x1F 0x8B)
            if (compressed.length < 2 || (compressed[0] & 0xFF) != 0x1F || (compressed[1] & 0xFF) != 0x8B) {
                migrateFromGzip(compressed); // eski format varsa migrate et
                return;
            }

            // GZIP decompress
            byte[] raw;
            try (GZIPInputStream gzis = new GZIPInputStream(new ByteArrayInputStream(compressed));
                 ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] buf = new byte[8192];
                int n;
                while ((n = gzis.read(buf)) != -1) out.write(buf, 0, n);
                raw = out.toByteArray();
            }

            DataInputStream dis = new DataInputStream(new ByteArrayInputStream(raw));

            int magic = dis.readInt();
            if (magic != MAGIC) { plugin.getLogger().severe("[TagSave] Gecersiz magic."); return; }

            // Dictionary
            int dictSize = dis.readUnsignedShort();
            String[] dict = new String[dictSize];
            for (int i = 0; i < dictSize; i++) {
                int len = dis.readUnsignedByte();
                byte[] tb = new byte[len];
                dis.readFully(tb);
                dict[i] = new String(tb, StandardCharsets.UTF_8);
            }

            // Entries
            int count = dis.readInt();
            int loaded = 0;
            for (int i = 0; i < count; i++) {
                long msb   = dis.readLong();
                long lsb   = dis.readLong();
                int  idx   = dis.readUnsignedShort();
                UUID uuid  = new UUID(msb, lsb);
                String tag = (idx < dict.length) ? dict[idx] : HALK;
                if (!isHalk(tag)) { tagCache.put(uuid, tag); loaded++; }
            }

            plugin.getLogger().info(String.format(
                "[TagSave] %d tag yuklendi (ZSTD, ag.db, %d B)", loaded, compressed.length));

        } catch (Exception ex) {
            plugin.getLogger().severe("[TagSave] ag.db okuma hatasi: " + ex.getMessage());
        }
    }

    /** Eski GZIP (v1) formatından otomatik taşıma */
    private void migrateFromGzip(byte[] compressed) {
        int migrated = 0;
        try (DataInputStream dis = new DataInputStream(
                new java.util.zip.GZIPInputStream(new ByteArrayInputStream(compressed)))) {
            int count = dis.readInt();
            for (int i = 0; i < count; i++) {
                long msb = dis.readLong(); long lsb = dis.readLong();
                int len  = dis.readUnsignedShort();
                byte[] tb = new byte[len]; dis.readFully(tb);
                String tag = new String(tb, StandardCharsets.UTF_8).trim();
                if (!tag.isEmpty() && !isHalk(tag)) { tagCache.put(new UUID(msb, lsb), tag); migrated++; }
            }
        } catch (IOException ex) {
            plugin.getLogger().warning("[TagSave] GZIP migrate hatasi: " + ex.getMessage());
        }
        if (migrated > 0) {
            plugin.getLogger().info("[TagSave] Eski GZIP formatindan " + migrated + " tag tasindi -> ZSTD ag.db");
            saveAll();
        }
    }

    /** Çok eski text tag.db'den taşıma */
    private void migrateFromLegacy() {
        File legacy = new File(plugin.getDataFolder(), "tag_saves/tag.db");
        if (!legacy.exists()) return;
        try (BufferedReader br = new BufferedReader(new FileReader(legacy))) {
            String line; int migrated = 0;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty() || line.startsWith("#")) continue;
                int idx = line.indexOf('='); if (idx < 1) continue;
                String tag = line.substring(idx + 1).trim();
                if (tag.isEmpty() || isHalk(tag)) continue;
                try { tagCache.put(UUID.fromString(line.substring(0, idx).trim()), tag); migrated++; }
                catch (IllegalArgumentException ignored) {}
            }
            if (migrated > 0) {
                plugin.getLogger().info("[TagSave] Eski tag.db'den " + migrated + " tag tasindi -> ZSTD ag.db");
                saveAll();
            }
        } catch (IOException ex) {
            plugin.getLogger().warning("[TagSave] Legacy migrate hatasi: " + ex.getMessage());
        }
    }

    // ── NAMETAG ───────────────────────────────────────────────────────────────

    private void applyNametag(Player player, String tag, int rgb) {
        String prefix  = toMcHex(rgb) + "[" + tag + "]\u00A7r";
        String display = prefix + player.getName();
        Scoreboard sb  = Bukkit.getScoreboardManager().getMainScoreboard();
        String tName   = teamName(player.getUniqueId());
        Team   team    = sb.getTeam(tName);
        String lastTag = lastTagApplied.get(player.getUniqueId());
        if (team == null || !tag.equals(lastTag)) {
            if (team == null) team = sb.registerNewTeam(tName);
            else for (String e : new HashSet<>(team.getEntries())) team.removeEntry(e);
            team.addEntry(player.getName());
            lastTagApplied.put(player.getUniqueId(), tag);
        }
        team.setPrefix(prefix);
        player.setCustomName(display);
        player.setCustomNameVisible(true);
        player.setPlayerListName(display);
    }

    private void clearTeam(Player player) {
        Team team = Bukkit.getScoreboardManager().getMainScoreboard().getTeam(teamName(player.getUniqueId()));
        if (team != null) try { team.unregister(); } catch (Exception ignored) {}
    }

    // ── YARDIMCILAR ──────────────────────────────────────────────────────────

    private String toMcHex(int rgb) {
        String h = String.format("%06X", rgb & 0xFFFFFF);
        return "\u00A7x\u00A7"+h.charAt(0)+"\u00A7"+h.charAt(1)+"\u00A7"+h.charAt(2)
              +"\u00A7"+h.charAt(3)+"\u00A7"+h.charAt(4)+"\u00A7"+h.charAt(5);
    }

    private String teamName(UUID uuid) {
        String s = uuid.toString().replace("-", "");
        return "yt" + s.substring(s.length() - 12);
    }

    private int randomRgb() {
        int r, g, b;
        do { r = RNG.nextInt(256); g = RNG.nextInt(256); b = RNG.nextInt(256); }
        while (r + g + b < 200);
        return (r << 16) | (g << 8) | b;
    }

    private boolean isHalk(String tag) {
        return tag == null || normalizeForCheck(tag).equals("halk");
    }

    private String normalizeForCheck(String s) {
        return s.toLowerCase(java.util.Locale.ROOT)
                .replace('\u0130','i').replace('\u0131','i')
                .replace('\u011f','g').replace('\u015f','s')
                .replace('\u00fc','u').replace('\u00f6','o').replace('\u00e7','c');
    }
}
