package com.yucehanrp.managers;

import com.yucehanrp.SessionData;
import com.yucehanrp.util.C;
import com.yucehanrp.util.ItemUtil;
import org.bukkit.Material;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import java.util.List;
import java.util.UUID;

public class GameHeadManager {
    private final SessionData data;

    public GameHeadManager(SessionData data) {
        this.data = data;
    }

    public void giveGameHead(Player player) {
        if (data.isInAnyGame(player.getUniqueId())) return;
        for (int i = 0; i < 36; i++) {
            ItemStack s = player.getInventory().getItem(i);
            if (s != null && isGameHead(s)) {
                player.getInventory().setItem(i, null);
            }
        }
        ItemStack head = makeGameHead();
        player.getInventory().setItem(0, head);
    }

    public ItemStack makeGameHead() {
        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        ItemMeta meta = head.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(C.c(SessionData.GAME_HEAD_NAME));
            meta.setLore(List.of(C.c("&7Sag Tik>Oyunlar!"), C.c("&8Sunucu Oyunlari")));
            head.setItemMeta(meta);
        }
        return head;
    }

    // FIX: Karşılaştırma stripColor ile yapılıyor — Paper 1.21.4 uyumlu
    public boolean isGameHead(ItemStack item) {
        if (item == null || item.getType() != Material.PLAYER_HEAD) return false;
        String itemName = ChatColor.stripColor(ItemUtil.displayName(item));
        String headName = ChatColor.stripColor(C.c(SessionData.GAME_HEAD_NAME));
        return itemName.equals(headName);
    }

    public boolean isGameHeadByName(String name) {
        if (name == null) return false;
        String stripped = ChatColor.stripColor(name);
        String headName = ChatColor.stripColor(C.c(SessionData.GAME_HEAD_NAME));
        return stripped.equals(headName);
    }
}
