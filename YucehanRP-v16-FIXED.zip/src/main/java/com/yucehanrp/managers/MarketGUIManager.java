package com.yucehanrp.managers;

import com.yucehanrp.SessionData;
import com.yucehanrp.util.C;
import com.yucehanrp.util.ItemUtil;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import java.util.ArrayList;
import java.util.List;

public class MarketGUIManager {
    // FIX: Title'larda emoji ve special char yok — strip() sonrası eşleşir
    public static final String MARKET_TITLE    = "OYUNCU MARKETI";
    public static final String TEZGAH_TITLE    = "TEZGAH KUR";

    private final SessionData data;
    private final MarketManager market;

    public MarketGUIManager(SessionData data, MarketManager market) {
        this.data = data;
        this.market = market;
    }

    public void openMarket(Player player) {
        Inventory gui = Bukkit.createInventory(null, 54, C.c("&6&l " + MARKET_TITLE));
        drawMarket(player, gui);
        player.openInventory(gui);
    }

    public void drawMarket(Player player, Inventory gui) {
        for (int i = 0; i < 54; i++) gui.setItem(i, ItemUtil.makeGlass(org.bukkit.DyeColor.GRAY, " "));
        gui.setItem(4, ItemUtil.make(Material.NETHER_STAR, "&6&l " + MARKET_TITLE,
            "&7Player-to-Player ticaret sistemi!||&e7 aktif tezgah&7desteklenir.||&7Her tezgah&c10 dakika&7satista kalir."));
        int aktif = market.getActiveCount();
        gui.setItem(35, ItemUtil.make(Material.PAPER, "&7Dolu:&e" + aktif + "&7/&a7"));
        for (int n = 1; n <= 7; n++) {
            int guiSlot = market.nToGuiSlot(n);
            if (guiSlot == 0) continue;
            if (data.marketItem.containsKey(n)) {
                ItemStack mItem = data.marketItem.get(n);
                int price = data.marketPrice.getOrDefault(n, 0);
                int amount = data.marketAmount.getOrDefault(n, 1);
                String owner = data.marketOwner.getOrDefault(n, "?");
                String currency = data.marketCurrency.getOrDefault(n, "zumrut");
                long kalan = market.getRemainingSeconds(n);
                String curName = currency.equals("elmas") ? "&bElmas" : "&eZumrut";
                ItemStack display = mItem.clone();
                ItemMeta meta = display.getItemMeta();
                if (meta != null) {
                    List<String> lore = new ArrayList<>();
                    lore.add(C.c("&7Satici:&f" + owner));
                    lore.add(C.c("&7Adet:&f" + amount));
                    lore.add(C.c("&7Fiyat:&f" + price + " " + curName));
                    lore.add(C.c("&7Kalan Sure:&f" + kalan + "sn"));
                    lore.add(C.c("&eSatin almak icin tikla!"));
                    meta.setLore(lore);
                    display.setItemMeta(meta);
                }
                gui.setItem(guiSlot, display);
            } else {
                gui.setItem(guiSlot, ItemUtil.make(Material.LIME_STAINED_GLASS_PANE, "&a[BOS TEZGAH]", "&7Bu tezgah bos!"));
            }
        }
        gui.setItem(45, ItemUtil.make(Material.LIME_STAINED_GLASS_PANE,  "&a&lTEZGAH KUR",     "&7Kendi urununu sat!"));
        gui.setItem(46, ItemUtil.make(Material.RED_STAINED_GLASS_PANE,   "&c&lTEZGAHIMI KALDIR","&7Aktif tezgahini kaldir."));
        gui.setItem(53, ItemUtil.make(Material.BARRIER, "&c&lKAPAT"));
    }

    public void openTezgahKur(Player player) {
        Inventory gui = Bukkit.createInventory(null, 54, C.c("&e&l " + TEZGAH_TITLE));
        data.marketPendingCurrency.putIfAbsent(player.getUniqueId(), "zumrut");
        String para = data.marketPendingCurrency.get(player.getUniqueId());
        gui.setItem(4,  ItemUtil.make(Material.NETHER_STAR, "&6&lTEZGAH KUR",
            "&7Satmak istedigin esyayi&eenvanterinin 2.slotuna koy!||&7Ardindan&eSAT&7butonuna bas."));
        if (para.equals("elmas")) {
            gui.setItem(22, ItemUtil.make(Material.DIAMOND, "&b&lPARA:ELMAS", "&7Alici&bElmas&7odeyecek.||&eDestirmek icin tikla!"));
        } else {
            gui.setItem(22, ItemUtil.make(Material.EMERALD, "&e&lPARA:ZUMRUT", "&7Alici&eZumrut&7odeyecek.||&eDestirmek icin tikla!"));
        }
        gui.setItem(13, ItemUtil.make(Material.GOLD_INGOT, "&6&lSAT", "&7Envanterin&e2.slotundaki&7itemi satis listesine ekle!"));
        gui.setItem(31, ItemUtil.make(Material.BARRIER, "&c&lIPTAL"));
        for (int i = 0; i < 27; i++) {
            ItemStack inv = player.getInventory().getItem(i);
            if (inv != null) gui.setItem(27 + i, inv.clone());
        }
        for (int i = 0; i < 27; i++) { if (gui.getItem(i) == null) gui.setItem(i, ItemUtil.fillSlot()); }
        player.openInventory(gui);
    }

    public void refreshTezgahKurGui(Player player) {
        String title = ChatColor.stripColor(player.getOpenInventory().getTitle());
        if (!title.equals(TEZGAH_TITLE)) return;
        Inventory gui = player.getOpenInventory().getTopInventory();
        String para = data.marketPendingCurrency.getOrDefault(player.getUniqueId(), "zumrut");
        if ("elmas".equals(para)) {
            gui.setItem(22, ItemUtil.make(Material.DIAMOND, "&b&lPARA:ELMAS", "&7Alici&bElmas&7odeyecek.||&eDestirmek icin tikla!"));
        } else {
            gui.setItem(22, ItemUtil.make(Material.EMERALD, "&e&lPARA:ZUMRUT", "&7Alici&eZumrut&7odeyecek.||&eDestirmek icin tikla!"));
        }
    }
}
