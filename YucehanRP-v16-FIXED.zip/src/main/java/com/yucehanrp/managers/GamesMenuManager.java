package com.yucehanrp.managers;

import com.yucehanrp.SessionData;
import com.yucehanrp.util.C;
import com.yucehanrp.util.ItemUtil;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.DyeColor;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

public class GamesMenuManager {
    private final SessionData data;
    private final GameHeadManager headManager;

    public GamesMenuManager(SessionData data, GameHeadManager headManager) {
        this.data = data;
        this.headManager = headManager;
    }

    // FIX: Cache kaldırıldı. Paper 1.21.4'te cached inventory'ler item
    // isimlerini farklı serialize ediyor => tıklama eşleşmeleri çalışmıyor.
    private Inventory buildGamesMenu() {
        Inventory gui = Bukkit.createInventory(null, 27, C.c("Oyunlar Menusu"));
        gui.setItem(0,  ItemUtil.make(Material.DIAMOND_SWORD, "&c&lPVP",           "&7Savas alanina gir!||&e>Tikla||&c Fiziksel Oyun&8-Hareket gerektirir"));
        gui.setItem(1,  ItemUtil.make(Material.STICK,         "&a&lSUMO",          "&7Platformdan dusurmege calis!||&e>Tikla||&c Fiziksel Oyun&8-Hareket gerektirir"));
        gui.setItem(2,  ItemUtil.make(Material.FEATHER,       "&b&lFLAPPY BIRD",   "&7Borulardan kac!||&e>Tikla||&b GUI Oyunu&8-Envanter ekrani"));
        gui.setItem(3,  ItemUtil.make(Material.WHEAT,         "&2&lYILAN",         "&7Yem ye,buyup kazan!||&e>Tikla||&b GUI Oyunu&8-Envanter ekrani"));
        gui.setItem(4,  ItemUtil.make(Material.COMPARATOR,    "&e&lRENK ESLESTIR", "&7Ortadaki rengi bul ve tikla!||&7Yanlis=-1 puan!||&e>Tikla||&b GUI Oyunu&8-Envanter ekrani"));
        gui.setItem(5,  ItemUtil.make(Material.EMERALD,       "&d&lSIMON SAYS",    "&7Simon'un dediklerini yap!||&e>Tikla||&b GUI Oyunu&8-Envanter ekrani"));
        gui.setItem(6,  ItemUtil.make(Material.CLOCK,         "&6&lHIZLI TIKLAMA", "&7Refleks testi!||&e>Tikla||&b GUI Oyunu&8-Envanter ekrani"));
        gui.setItem(7,  ItemUtil.make(Material.BONE,          "&4&lKATIL KIM",     "&7Kim katil?Hayatta kal!||&e>Tikla||&c Cok Oyunculu-Fiziksel Oyun"));
        gui.setItem(8,  ItemUtil.make(Material.RED_BED,       "&c&lBED WARS",      "&7Yatagini koru,son kalan kazan!||&e>Tikla||&c Cok Oyunculu-Fiziksel Oyun"));
        gui.setItem(9,  ItemUtil.make(Material.TNT,           "&c&lTNT EBELEMECE", "&7Ebeden kac,son kalan kazan!||&e>Tikla||&c Cok Oyunculu-Fiziksel Oyun"));
        for (int i = 0; i < 27; i++) if (gui.getItem(i) == null) gui.setItem(i, ItemUtil.fillSlot());
        return gui;
    }

    private Inventory buildPvpMenu() {
        Inventory gui = Bukkit.createInventory(null, 27, C.c("PVP Alani"));
        gui.setItem(4,  ItemUtil.make(Material.DIAMOND_SWORD, "&c&lPVP ALANI", "&7Savas alanina gireceksin!||&7Zirh ve ozel balta verilir.||&aEnvanteriniz korunur,geri alirsiniz.||&eCikmak icin:/oyundancik"));
        gui.setItem(11, ItemUtil.makeGlass(DyeColor.LIME, "&a&lGIR!"));
        gui.setItem(15, ItemUtil.makeGlass(DyeColor.RED,  "&c&lGERI DON"));
        for (int i = 0; i < 27; i++) if (gui.getItem(i) == null) gui.setItem(i, ItemUtil.fillSlot());
        return gui;
    }

    private Inventory buildSumoMenu() {
        Inventory gui = Bukkit.createInventory(null, 27, C.c("Sumo Alani"));
        gui.setItem(4,  ItemUtil.make(Material.STICK, "&a&lSUMO ALANI", "&7Platformdan dusturmeye calis!||&7Sadece YUMRUK ile vurabilirsin.||&aEnvanteriniz korunur,geri alirsiniz.||&eCikmak icin:/oyundancik"));
        gui.setItem(11, ItemUtil.makeGlass(DyeColor.LIME, "&a&lGIR!"));
        gui.setItem(15, ItemUtil.makeGlass(DyeColor.RED,  "&c&lGERI DON"));
        for (int i = 0; i < 27; i++) if (gui.getItem(i) == null) gui.setItem(i, ItemUtil.fillSlot());
        return gui;
    }

    public void openGamesMenu(Player player) {
        UUID uuid = player.getUniqueId();
        if (data.pvpMode.containsKey(uuid))     { player.sendActionBar(C.c("&cOnce PVP'den cik!(/oyundancik)"));               return; }
        if (data.sumoMode.containsKey(uuid))    { player.sendActionBar(C.c("&cOnce Sumo'dan cik!(/oyundancik)"));              return; }
        if (data.flappyActive.containsKey(uuid)){ player.sendActionBar(C.c("&cOnce mevcut oyundan cik!(/oyundancik)"));        return; }
        if (data.snakeActive.containsKey(uuid)) { player.sendActionBar(C.c("&cOnce mevcut oyundan cik!(/oyundancik)"));        return; }
        if (data.targetActive.containsKey(uuid)){ player.sendActionBar(C.c("&cOnce mevcut oyundan cik!(/oyundancik)"));        return; }
        if (data.simonActive.containsKey(uuid)) { player.sendActionBar(C.c("&cOnce mevcut oyundan cik!(/oyundancik)"));        return; }
        if (data.reflexActive.containsKey(uuid)){ player.sendActionBar(C.c("&cOnce mevcut oyundan cik!(/oyundancik)"));        return; }
        if (data.bwTeam.containsKey(uuid))      { player.sendActionBar(C.c("&cOnce Bed Wars'tan cik!(/oyundancik)"));          return; }
        if (data.bwInLobby.containsKey(uuid))   { player.sendActionBar(C.c("&cOnce Bed Wars lobisinden cik!(/oyundancik)"));   return; }
        if (data.tntPlayers.contains(uuid) || data.tntSpectators.contains(uuid) || data.tntQueue.contains(uuid)) {
            player.sendActionBar(C.c("&cOnce TNT'den cik!(/oyundancik)")); return;
        }
        // FIX: Her seferinde taze inventory yarat
        player.openInventory(buildGamesMenu());
    }

    public void openPvpMenu(Player player) {
        player.openInventory(buildPvpMenu());
    }

    public void openSumoMenu(Player player) {
        player.openInventory(buildSumoMenu());
    }
}
