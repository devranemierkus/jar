# 🏡 ArsaPlugin — YÜCEHAN Sunucusu

Minecraft 1.21.x için arsa yönetim eklentisi.

## ✅ Desteklenen Sürümler
1.21, 1.21.1, 1.21.2, 1.21.3, 1.21.4, 1.21.5, 1.21.6, 1.21.7, 1.21.8, 1.21.9, 1.21.10, 1.21.11

## 📥 JAR İndirme (GitHub Actions)
1. Bu repoyu GitHub'a yükle
2. **Actions** sekmesine git
3. **Build ArsaPlugin JAR** workflow'unu bul
4. En son başarılı build'e tıkla
5. **Artifacts** bölümünden `ArsaPlugin-JAR` dosyasını indir
6. `.zip` içindeki `.jar`'ı server'ın `plugins/` klasörüne at

## 🎮 Komutlar

| Komut | Yetki | Açıklama |
|-------|-------|----------|
| `/arsaseckonum1` | OP | Arsanın birinci köşesini seç |
| `/arsaseckonum2` | OP | Arsanın ikinci köşesini seç |
| `/arsaver <oyuncu>` | OP | Seçili arsayı oyuncuya ver |
| `/arsasil <oyuncu>` | OP | Oyuncunun arsasını sil |
| `/arsayagit` | Herkes | Kendi arsana ışınlan |
| `/arsainfo <oyuncu>` | OP | Oyuncunun arsa bilgisi |

## 📋 Özellikler
- **Blok koruma**: Oyuncu kendi arsasının dışına blok koyamaz/kıramaz
- **Otomatik Survival**: Arsaya girince Survival moda geçer, çıkınca eski moduna döner
- **UUID tabanlı kayıt**: Veriler `plugins/ArsaPlugin/arsalar.yml` içinde saklanır
- **Offline oyuncu desteği**: Sunucuda olmayan oyunculara da arsa verilebilir
- **Giriş bildirimi**: Oyuncu sunucuya girince arsası olduğu hatırlatılır
- **Güvenli ışınlanma**: `/arsayagit` komutu güvenli Y koordinatı bulur

## 📁 Veri Formatı (arsalar.yml)
```yaml
arsalar:
  xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx:
    ownerName: "Emir"
    world: "world"
    x1: 100
    y1: 64
    z1: 100
    x2: 150
    y2: 100
    z2: 150
```

## 🔧 Manuel Derleme
```bash
mvn clean package
# JAR: target/ArsaPlugin-1.0.0.jar
```
