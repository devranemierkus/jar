package com.yucehanclan.arsaplugin;

import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.player.PlayerRespawnEvent;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class ArsaListener implements Listener {

    static final String PREFIX = "\u00a76[\u00a7eArsa Yonetimi\u00a76 (\u00a7cYUCEHAN\u00a76)\u00a76] \u00a7r";

    private final ArsaPlugin  plugin;
    private final ArsaManager arsaManager;

    private final Map<UUID, Boolean> playerInPlot = new HashMap<>();

    public ArsaListener(ArsaPlugin plugin, ArsaManager arsaManager) {
        this.plugin      = plugin;
        this.arsaManager = arsaManager;
    }

    // ── BLOK KOYMA ────────────────────────────────────────────────────────────
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlockPlace(BlockPlaceEvent event) {
        Player player = event.getPlayer();
        if (player.isOp() || player.hasPermission("arsaplugin.bypass")) return;

        ArsaData arsa = arsaManager.getArsaByUUID(player.getUniqueId());
        if (arsa == null) return;

        var block = event.getBlockPlaced();
        if (!arsa.contains(block.getWorld().getName(), block.getX(), block.getY(), block.getZ())) {
            event.setCancelled(true);
            player.sendMessage(PREFIX + "\u00a7cKendi arsanin disina blok koyamazsin!");
        }
    }

    // ── BLOK KIRMA ────────────────────────────────────────────────────────────
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        if (player.isOp() || player.hasPermission("arsaplugin.bypass")) return;

        ArsaData arsa = arsaManager.getArsaByUUID(player.getUniqueId());
        if (arsa == null) return;

        var block = event.getBlock();
        if (!arsa.contains(block.getWorld().getName(), block.getX(), block.getY(), block.getZ())) {
            event.setCancelled(true);
            player.sendMessage(PREFIX + "\u00a7cKendi arsanin disinda blok kiramazsin!");
        }
    }

    // ── GAMEMODE (ortak yardimci) ─────────────────────────────────────────────
    /**
     * Oyuncunun bulundugu konuma gore gamemode'u aninda gunceller.
     * Durum degismediyse hicbir sey yapmaz -> sunucuyu gereksiz yormaz.
     */
    private void updateGamemode(Player player, Location loc) {
        if (loc == null) return;
        UUID uuid = player.getUniqueId();

        ArsaData arsa = arsaManager.getArsaByUUID(uuid);
        if (arsa == null) return;

        boolean nowInPlot = arsa.contains(loc.getWorld().getName(),
                                          loc.getBlockX(), loc.getBlockY(), loc.getBlockZ());
        // playerInPlot'ta kayit yoksa nowInPlot'un tersini varsay ki ilk giriste tetiklensin
        boolean wasInPlot = playerInPlot.getOrDefault(uuid, !nowInPlot);

        if (!wasInPlot && nowInPlot) {
            playerInPlot.put(uuid, true);
            player.setGameMode(GameMode.SURVIVAL);
            player.sendMessage(PREFIX + "\u00a7aArsana girdin \u2192 \u00a7eSurvival moda gecildi.");

        } else if (wasInPlot && !nowInPlot) {
            playerInPlot.put(uuid, false);
            player.setGameMode(GameMode.ADVENTURE);
            player.sendMessage(PREFIX + "\u00a77Arsandan ciktin. \u00a7cMacera moduna gecildi.");
        }
    }

    // ── NORMAL HAREKET ────────────────────────────────────────────────────────
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlayerMove(PlayerMoveEvent event) {
        // Teleport olaylari PlayerTeleportEvent'te ayrica handle edilir
        if (event instanceof PlayerTeleportEvent) return;

        Location from = event.getFrom();
        Location to   = event.getTo();
        if (to == null) return;
        // Sadece blok degisiminde kontrol et -> baslari dondurmesi gibi her harekette calismasin
        if (from.getBlockX() == to.getBlockX()
         && from.getBlockY() == to.getBlockY()
         && from.getBlockZ() == to.getBlockZ()) return;

        updateGamemode(event.getPlayer(), to);
    }

    // ── ISINLANMA (TP) ────────────────────────────────────────────────────────
    // PlayerMoveEvent teleport olayinda TETIKLENMIYOR; bu yuzden ayri listener zorunlu.
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlayerTeleport(PlayerTeleportEvent event) {
        Location to = event.getTo();
        if (to == null) return;
        // TP aninda anlik kontrol - sunucuya tek seferlik, hafif bir cagri
        updateGamemode(event.getPlayer(), to);
    }

    // ── YENIDEN DOGMA ─────────────────────────────────────────────────────────
    @EventHandler(priority = EventPriority.MONITOR)
    public void onPlayerRespawn(PlayerRespawnEvent event) {
        // Respawn sonrasi konum arsada mi diye 1 tick sonra kontrol et
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            Player p = event.getPlayer();
            if (p.isOnline()) updateGamemode(p, p.getLocation());
        });
    }

    // ── OYUNCU GİRİŞİ ────────────────────────────────────────────────────────
    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        UUID   uuid   = player.getUniqueId();

        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (!player.isOnline()) return;

            // 1) Bekleyen kitap iptal var mi? → envanterden sil
            if (arsaManager.hasPendingRevoke(uuid)) {
                TapuBook.removeTapuBooks(player, uuid);
                arsaManager.clearPendingRevoke(uuid);
                player.sendMessage(PREFIX + "\u00a7cTapu belgeniz iptal edildi ve envanterinizden silindi.");
            }

            // 2) Arsasi var mi? → bilgi ver + konum bazli gamemode ata
            ArsaData arsa = arsaManager.getArsaByUUID(uuid);
            if (arsa != null) {
                player.sendMessage(PREFIX + "\u00a7aMevcut bir arsan var! \u00a7e" + arsa.getCoordString());
                player.sendMessage(PREFIX + "\u00a77Arsana gitmek icin: \u00a7f/arsayagit");
                // Baglanti konumuna gore gamemode'u aninda belirle
                updateGamemode(player, player.getLocation());
            }

            // 3) Bekleyen tapu kitabi var mi? → ver
            if (arsaManager.hasPendingBook(uuid) && arsa != null) {
                var book = TapuBook.build(arsa, "YUCEHAN");
                player.getInventory().addItem(book);
                player.sendMessage(PREFIX + "\u00a7eTapu belgen envanterine eklendi!");
                arsaManager.clearPendingBook(uuid);
            }

        }, 40L);
    }

    // ── ÇIKIŞ TEMİZLİĞİ ──────────────────────────────────────────────────────
    public void onPlayerQuit(UUID uuid) {
        playerInPlot.remove(uuid);
    }
}
