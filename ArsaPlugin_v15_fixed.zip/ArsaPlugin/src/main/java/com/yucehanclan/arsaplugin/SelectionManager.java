package com.yucehanclan.arsaplugin;

import org.bukkit.Location;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Admin oyuncuların seçim durumunu tutar.
 * /arsaseckonum1 ve /arsaseckonum2 komutları arasındaki geçici veriyi saklar.
 */
public class SelectionManager {

    private final Map<UUID, Location> pos1Map = new HashMap<>();
    private final Map<UUID, Location> pos2Map = new HashMap<>();

    public void setPos1(UUID uuid, Location loc) {
        pos1Map.put(uuid, loc.clone());
    }

    public void setPos2(UUID uuid, Location loc) {
        pos2Map.put(uuid, loc.clone());
    }

    public Location getPos1(UUID uuid) {
        return pos1Map.get(uuid);
    }

    public Location getPos2(UUID uuid) {
        return pos2Map.get(uuid);
    }

    public boolean hasBothPositions(UUID uuid) {
        return pos1Map.containsKey(uuid) && pos2Map.containsKey(uuid);
    }

    public void clearSelection(UUID uuid) {
        pos1Map.remove(uuid);
        pos2Map.remove(uuid);
    }
}
