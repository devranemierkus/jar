package com.yucehanclan.arsaplugin;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.UUID;

public class ArsaCommands implements CommandExecutor {

    private static final String PREFIX = ArsaListener.PREFIX;

    private final ArsaManager      arsaManager;
    private final SelectionManager selectionManager;

    public ArsaCommands(ArsaManager arsaManager, SelectionManager selectionManager) {
        this.arsaManager      = arsaManager;
        this.selectionManager = selectionManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        switch (command.getName().toLowerCase()) {
            case "arsaseckonum1" -> cmdSecKonum1(sender);
            case "arsaseckonum2" -> cmdSecKonum2(sender);
            case "arsaver"       -> cmdArsaVer(sender, args);
            case "arsasil"       -> cmdArsaSil(sender, args);
            case "arsayagit"     -> cmdArsaYagit(sender);
            case "arsainfo"      -> cmdArsaInfo(sender, args);
            default              -> { return false; }
        }
        return true;
    }

    // ── /arsaseckonum1 ────────────────────────────────────────────────────────
    private void cmdSecKonum1(CommandSender sender) {
        if (!isAdmin(sender)) { noPermission(sender); return; }
        Player p = asPlayer(sender); if (p == null) return;
        selectionManager.setPos1(p.getUniqueId(), p.getLocation());
        p.sendMessage(PREFIX + "\u00a7aKose \u00a7e1\u00a7a secildi: \u00a7f" + locStr(p.getLocation()));
    }

    // ── /arsaseckonum2 ────────────────────────────────────────────────────────
    private void cmdSecKonum2(CommandSender sender) {
        if (!isAdmin(sender)) { noPermission(sender); return; }
        Player p = asPlayer(sender); if (p == null) return;
        selectionManager.setPos2(p.getUniqueId(), p.getLocation());
        p.sendMessage(PREFIX + "\u00a7aKose \u00a7e2\u00a7a secildi: \u00a7f" + locStr(p.getLocation()));
        if (selectionManager.hasBothPositions(p.getUniqueId()))
            p.sendMessage(PREFIX + "\u00a7eIki kose secildi. \u00a7f/arsaver <oyuncu> \u00a7eyapabilirsin.");
    }

    // ── /arsaver <oyuncu> ─────────────────────────────────────────────────────
    private void cmdArsaVer(CommandSender sender, String[] args) {
        if (!isAdmin(sender)) { noPermission(sender); return; }
        Player admin = asPlayer(sender); if (admin == null) return;

        if (args.length < 1) { sender.sendMessage(PREFIX + "\u00a7cKullenim: \u00a7f/arsaver <oyuncu>"); return; }

        UUID adminUUID = admin.getUniqueId();
        if (!selectionManager.hasBothPositions(adminUUID)) {
            sender.sendMessage(PREFIX + "\u00a7cOnce \u00a7f/arsaseckonum1 \u00a7cve \u00a7f/arsaseckonum2 \u00a7ckullan!"); return;
        }

        String targetName = args[0];
        UUID   targetUUID = resolveUUID(targetName);
        if (targetUUID == null) {
            sender.sendMessage(PREFIX + "\u00a7c'" + targetName + "' bulunamadi. Sunucuya hic giris yapmis olmali."); return;
        }

        Location pos1 = selectionManager.getPos1(adminUUID);
        Location pos2 = selectionManager.getPos2(adminUUID);
        if (!pos1.getWorld().getName().equals(pos2.getWorld().getName())) {
            sender.sendMessage(PREFIX + "\u00a7cIki kose ayni dunyada olmali!"); return;
        }
        if (arsaManager.hasArsa(targetUUID)) {
            sender.sendMessage(PREFIX + "\u00a7c" + targetName + " zaten arsali. Once \u00a7f/arsasil " + targetName); return;
        }

        ArsaData arsa = new ArsaData(
            targetUUID, targetName, pos1.getWorld().getName(),
            pos1.getBlockX(), pos1.getBlockY(), pos1.getBlockZ(),
            pos2.getBlockX(), pos2.getBlockY(), pos2.getBlockZ()
        );
        arsaManager.addArsa(arsa);
        selectionManager.clearSelection(adminUUID);

        sender.sendMessage(PREFIX + "\u00a7a\u2714 \u00a7f" + targetName + " \u00a7aisimli oyuncuya arsa verildi.");
        sender.sendMessage(PREFIX + "\u00a77" + arsa.getCoordString());

        // Tapu kitabi ver
        ItemStack book = TapuBook.build(arsa, admin.getName());
        Player targetOnline = Bukkit.getPlayer(targetUUID);
        if (targetOnline != null && targetOnline.isOnline()) {
            targetOnline.getInventory().addItem(book);
            targetOnline.sendMessage(PREFIX + "\u00a7aYeni bir arsa aldin! \u00a7e" + arsa.getCoordString());
            targetOnline.sendMessage(PREFIX + "\u00a7eTapu belgen envanterine eklendi!");
            targetOnline.sendMessage(PREFIX + "\u00a7c\u00a7lONEMLI: \u00a7eTapu belgenizi kaybetmeyin!");
            targetOnline.sendMessage(PREFIX + "\u00a77Yetkili bir gorevli sorabilir, cikarmali ve gostermelisiniz.");
        } else {
            arsaManager.setPendingBook(targetUUID);
            sender.sendMessage(PREFIX + "\u00a77" + targetName + " su an offline, tapu girisde verilecek.");
        }
    }

    // ── /arsasil <oyuncu> ─────────────────────────────────────────────────────
    private void cmdArsaSil(CommandSender sender, String[] args) {
        if (!isAdmin(sender)) { noPermission(sender); return; }
        if (args.length < 1) { sender.sendMessage(PREFIX + "\u00a7cKullenim: \u00a7f/arsasil <oyuncu>"); return; }

        ArsaData arsa = arsaManager.getArsaByName(args[0]);
        if (arsa == null) {
            sender.sendMessage(PREFIX + "\u00a7c'" + args[0] + "' adli oyuncunun arsasi yok."); return;
        }

        UUID   uuid       = arsa.getOwnerUUID();
        String ownerName  = arsa.getOwnerName();

        // Once arsayi sil
        arsaManager.removeArsa(uuid);
        sender.sendMessage(PREFIX + "\u00a7a\u2714 \u00a7f" + ownerName + " \u00a7aisimli oyuncunun arsasi silindi.");
        sender.sendMessage(PREFIX + "\u00a77UUID: \u00a7f" + uuid);

        // Tapu kitabini sil (online / offline)
        Player targetOnline = Bukkit.getPlayer(uuid);
        if (targetOnline != null && targetOnline.isOnline()) {
            // Online → envanterden direkt sil
            TapuBook.removeTapuBooks(targetOnline, uuid);
            targetOnline.sendMessage(PREFIX + "\u00a7cArsaniz ve tapu belgeniz yonetici tarafindan iptal edildi.");
            sender.sendMessage(PREFIX + "\u00a77Tapu kitabi online oyuncunun envanterinden silindi.");
        } else {
            // Offline → girisde sil
            arsaManager.setPendingRevoke(uuid);
            sender.sendMessage(PREFIX + "\u00a77" + ownerName + " offline. Tapu kitabi girisinde silinecek.");
        }
    }

    // ── /arsayagit ────────────────────────────────────────────────────────────
    private void cmdArsaYagit(CommandSender sender) {
        Player p = asPlayer(sender); if (p == null) return;

        ArsaData arsa = arsaManager.getArsaByUUID(p.getUniqueId());
        if (arsa == null) { p.sendMessage(PREFIX + "\u00a7cHenuz bir arsaniz yok."); return; }

        World world = Bukkit.getWorld(arsa.getWorldName());
        if (world == null) { p.sendMessage(PREFIX + "\u00a7cArsa dunyasi bulunamadi: \u00a7f" + arsa.getWorldName()); return; }

        int cx = arsa.getCenterX(), cz = arsa.getCenterZ();
        int safeY = findSafeY(world, cx, cz);

        p.teleport(new Location(world, cx + 0.5, safeY, cz + 0.5, p.getLocation().getYaw(), 0f));
        p.sendMessage(PREFIX + "\u00a7aArsaniza isinlandiniz!");
    }

    // ── /arsainfo <oyuncu> ────────────────────────────────────────────────────
    private void cmdArsaInfo(CommandSender sender, String[] args) {
        if (!isAdmin(sender)) { noPermission(sender); return; }
        if (args.length < 1) { sender.sendMessage(PREFIX + "\u00a7cKullenim: \u00a7f/arsainfo <oyuncu>"); return; }

        ArsaData arsa = arsaManager.getArsaByName(args[0]);
        if (arsa == null) { sender.sendMessage(PREFIX + "\u00a7c'" + args[0] + "' adli oyuncunun arsasi yok."); return; }

        sender.sendMessage(PREFIX + "\u00a7e--- Arsa Bilgisi ---");
        sender.sendMessage("\u00a77Sahip : \u00a7f" + arsa.getOwnerName());
        sender.sendMessage("\u00a77UUID  : \u00a7f" + arsa.getOwnerUUID());
        sender.sendMessage("\u00a77Koord : \u00a7f" + arsa.getCoordString());
        sender.sendMessage("\u00a77Dunya : \u00a7f" + arsa.getWorldName());
    }

    // ── YARDIMCILAR ───────────────────────────────────────────────────────────

    private int findSafeY(World world, int x, int z) {
        int minY    = world.getMinHeight();
        int maxY    = world.getMaxHeight() - 2;
        int surface = Math.max(minY + 1, Math.min(world.getHighestBlockYAt(x, z), maxY - 1));

        for (int y = surface + 1; y >= minY + 2; y--) {
            Block ground = world.getBlockAt(x, y - 1, z);
            Block feet   = world.getBlockAt(x, y,     z);
            Block head   = world.getBlockAt(x, y + 1, z);
            if (ground.getType().isSolid()
             && (feet.getType() == Material.AIR || !feet.getType().isSolid())
             && (head.getType() == Material.AIR || !head.getType().isSolid()))
                return y;
        }
        return Math.max(minY + 2, Math.min(surface + 1, maxY));
    }

    private UUID resolveUUID(String name) {
        Player online = Bukkit.getPlayerExact(name);
        if (online != null) return online.getUniqueId();
        @SuppressWarnings("deprecation")
        OfflinePlayer op = Bukkit.getOfflinePlayer(name);
        if (op != null && op.hasPlayedBefore()) return op.getUniqueId();
        ArsaData d = arsaManager.getArsaByName(name);
        return d != null ? d.getOwnerUUID() : null;
    }

    private boolean isAdmin(CommandSender s) { return s.isOp() || s.hasPermission("arsaplugin.admin"); }
    private void noPermission(CommandSender s) { s.sendMessage(PREFIX + "\u00a7cBu komutu kullanma yetkiniz yok!"); }
    private Player asPlayer(CommandSender s) {
        if (!(s instanceof Player)) { s.sendMessage(PREFIX + "\u00a7cSadece oyuncular kullanabilir!"); return null; }
        return (Player) s;
    }
    private String locStr(Location l) {
        return String.format("\u00a7b%d\u00a77,\u00a7b%d\u00a77,\u00a7b%d \u00a77[\u00a7f%s\u00a77]",
            l.getBlockX(), l.getBlockY(), l.getBlockZ(), l.getWorld().getName());
    }
}
