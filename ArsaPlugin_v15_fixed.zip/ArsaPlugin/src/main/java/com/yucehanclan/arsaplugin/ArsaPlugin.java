package com.yucehanclan.arsaplugin;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;

public class ArsaPlugin extends JavaPlugin implements Listener {

    private ArsaManager      arsaManager;
    private SelectionManager selectionManager;
    private ArsaListener     arsaListener;

    @Override
    public void onEnable() {
        TapuBook.init(this);

        arsaManager = new ArsaManager(this);
        arsaManager.loadAll();

        selectionManager = new SelectionManager();
        arsaListener     = new ArsaListener(this, arsaManager);

        getServer().getPluginManager().registerEvents(arsaListener, this);
        getServer().getPluginManager().registerEvents(this, this);

        ArsaCommands cmd = new ArsaCommands(arsaManager, selectionManager);
        for (String name : new String[]{
                "arsaseckonum1","arsaseckonum2","arsaver",
                "arsasil","arsayagit","arsainfo"}) {
            var c = getCommand(name);
            if (c != null) c.setExecutor(cmd);
            else getLogger().warning("Komut bulunamadi: " + name);
        }

        getLogger().info("ArsaPlugin aktif! YUCEHAN Sunucusu");
    }

    @Override
    public void onDisable() {
        getLogger().info("ArsaPlugin kapatildi.");
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent e) {
        arsaListener.onPlayerQuit(e.getPlayer().getUniqueId());
    }

    public ArsaManager      getArsaManager()      { return arsaManager; }
    public SelectionManager getSelectionManager() { return selectionManager; }
}
