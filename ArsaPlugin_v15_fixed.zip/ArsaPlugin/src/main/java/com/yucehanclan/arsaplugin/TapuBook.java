package com.yucehanclan.arsaplugin;

import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BookMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.UUID;

public class TapuBook {

    public static NamespacedKey KEY_OWNER;
    public static NamespacedKey KEY_BOOK_ID;

    private TapuBook() {}

    public static void init(JavaPlugin plugin) {
        KEY_OWNER   = new NamespacedKey(plugin, "arsa_owner");
        KEY_BOOK_ID = new NamespacedKey(plugin, "book_id");
    }

    public static ItemStack build(ArsaData arsa, String adminName) {
        ItemStack book = new ItemStack(Material.WRITTEN_BOOK);
        BookMeta  meta = (BookMeta) book.getItemMeta();
        if (meta == null) return book;

        meta.setTitle("TAPU BELGESI");
        meta.setAuthor("Arsa Yonetim Kurumu");

        String tarih = LocalDate.now()
                .format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

        // Sayfa 1 - Kapak
        meta.addPage(
            "\u00a7l\u00a7nARSA YONETIM KURUMU\n\n"
          + "\u00a7r\u00a76\u00a7lTAPU BELGESI\n\n"
          + "\u00a7rBu belge resmi\n"
          + "mulkiyet kanitidir.\n\n"
          + "\u00a77Tarih: \u00a7f" + tarih + "\n\n"
          + "\u00a7c\u00a7oKopyalanamaz"
        );

        // Sayfa 2 - Arsa Bilgisi
        meta.addPage(
            "\u00a7l\u00a7nARSA BILGILERI\n\n"
          + "\u00a7rSahip:\n\u00a7a" + arsa.getOwnerName() + "\n\n"
          + "\u00a7rDunya:\n\u00a7e" + arsa.getWorldName() + "\n\n"
          + "\u00a7rKoordinatlar:\n"
          + "\u00a7bKose 1:\n"
          + "\u00a7fX:" + arsa.getX1() + " Y:" + arsa.getY1() + " Z:" + arsa.getZ1() + "\n"
          + "\u00a7bKose 2:\n"
          + "\u00a7fX:" + arsa.getX2() + " Y:" + arsa.getY2() + " Z:" + arsa.getZ2()
        );

        // Sayfa 3 - Resmi Muhur
        meta.addPage(
            "\u00a7l\u00a7nRESMI ONAY\n\n"
          + "\u00a7rBu tapu belgesi\n"
          + "\u00a76Arsa Yonetim\n"
          + "Kurumu\u00a7r tarafindan\n"
          + "onaylanmistir.\n\n"
          + "\u00a77Yetkili:\n"
          + "\u00a7c" + adminName + "\n\n"
          + "\u00a78Sahip UUID:\n"
          + "\u00a77" + shortUUID(arsa.getOwnerUUID().toString()) + "\n\n"
          + "\u00a7c\u00a7l!! KOPYALANAMAZ !!"
        );

        // Sayfa 4 - Kayip Uyarisi
        meta.addPage(
            "\u00a7c\u00a7l!! ONEMLI UYARI !!\n\n"
          + "\u00a7rBu belgeyi\n"
          + "\u00a7e\u00a7lKAYBETMEYIN!\n\n"
          + "\u00a7rYetkili bir gorevli\n"
          + "size arsa sorarsa\n"
          + "bu belgeyi\n"
          + "\u00a7acikarmali ve\n"
          + "gostermelisiniz.\n\n"
          + "\u00a77Kayip durumunda\n"
          + "yetkiliyle iletisime\n"
          + "geciniz."
        );

        // Lore
        meta.setLore(List.of(
            "\u00a78\u00a7m----------------------",
            "\u00a7e\u00a7lBu belgeyi kaybetmeyin!",
            "\u00a77Yetkili sorabilir \u2192 gosterin.",
            "\u00a7c\u00a7lKopyalanamaz \u00a77| Yetkisiz kopya gecersiz",
            "\u00a78\u00a7m----------------------"
        ));

        meta.addItemFlags(ItemFlag.HIDE_ADDITIONAL_TOOLTIP);

        // PDC kimlik damgasi
        meta.getPersistentDataContainer()
            .set(KEY_OWNER,   PersistentDataType.STRING, arsa.getOwnerUUID().toString());
        meta.getPersistentDataContainer()
            .set(KEY_BOOK_ID, PersistentDataType.STRING, UUID.randomUUID().toString());

        book.setItemMeta(meta);
        return book;
    }

    public static boolean containsTapuBook(org.bukkit.entity.Player player, UUID ownerUUID) {
        if (KEY_OWNER == null) return false;
        for (ItemStack item : player.getInventory().getContents()) {
            if (isTapuOf(item, ownerUUID)) return true;
        }
        return false;
    }

    public static void removeTapuBooks(org.bukkit.entity.Player player, UUID ownerUUID) {
        if (KEY_OWNER == null) return;
        org.bukkit.inventory.Inventory inv = player.getInventory();
        ItemStack[] contents = inv.getContents();
        for (int i = 0; i < contents.length; i++) {
            if (isTapuOf(contents[i], ownerUUID)) inv.setItem(i, null);
        }
        player.updateInventory();
    }

    private static boolean isTapuOf(ItemStack item, UUID ownerUUID) {
        if (item == null || item.getType() != Material.WRITTEN_BOOK) return false;
        if (!(item.getItemMeta() instanceof BookMeta bm)) return false;
        var pdc = bm.getPersistentDataContainer();
        if (!pdc.has(KEY_OWNER, PersistentDataType.STRING)) return false;
        return ownerUUID.toString().equals(pdc.get(KEY_OWNER, PersistentDataType.STRING));
    }

    private static String shortUUID(String uuid) {
        return uuid.length() > 13 ? uuid.substring(0, 13) + "..." : uuid;
    }
}
