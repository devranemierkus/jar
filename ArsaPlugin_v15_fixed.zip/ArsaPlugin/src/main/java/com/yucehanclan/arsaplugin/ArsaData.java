package com.yucehanclan.arsaplugin;

import java.util.UUID;

/**
 * Bir arsanın tüm verisini tutan model sınıfı.
 * Koordinatlar World-independent saklanır (world ismi string olarak).
 */
public class ArsaData {

    private UUID ownerUUID;
    private String ownerName;    // Görüntüleme için (offline oyuncular dahil)
    private String worldName;
    private int x1, y1, z1;
    private int x2, y2, z2;

    public ArsaData(UUID ownerUUID, String ownerName,
                    String worldName,
                    int x1, int y1, int z1,
                    int x2, int y2, int z2) {
        this.ownerUUID = ownerUUID;
        this.ownerName = ownerName;
        this.worldName = worldName;
        // Min/Max normalize et
        this.x1 = Math.min(x1, x2);
        this.y1 = Math.min(y1, y2);
        this.z1 = Math.min(z1, z2);
        this.x2 = Math.max(x1, x2);
        this.y2 = Math.max(y1, y2);
        this.z2 = Math.max(z1, z2);
    }

    public UUID getOwnerUUID() { return ownerUUID; }
    public String getOwnerName() { return ownerName; }
    public String getWorldName() { return worldName; }
    public int getX1() { return x1; }
    public int getY1() { return y1; }
    public int getZ1() { return z1; }
    public int getX2() { return x2; }
    public int getY2() { return y2; }
    public int getZ2() { return z2; }

    /**
     * Verilen koordinat bu arsanın içinde mi?
     */
    public boolean contains(String worldName, int x, int y, int z) {
        if (!this.worldName.equals(worldName)) return false;
        return x >= x1 && x <= x2
            && y >= y1 && y <= y2
            && z >= z1 && z <= z2;
    }

    /**
     * Yalnızca XZ düzleminde (yükseklik göz ardı) arsada mı?
     * Oyuncu alanı kontrolü için (Y kısıtlaması olmadan blok koruma)
     */
    public boolean containsXZ(String worldName, int x, int z) {
        if (!this.worldName.equals(worldName)) return false;
        return x >= x1 && x <= x2 && z >= z1 && z <= z2;
    }

    /**
     * Arsanın tam merkezini döndürür (X, Z).
     */
    public int getCenterX() { return (x1 + x2) / 2; }
    public int getCenterZ() { return (z1 + z2) / 2; }

    /**
     * Koordinat bilgisini okunabilir formatta döndürür.
     */
    public String getCoordString() {
        return String.format("(%d,%d,%d) → (%d,%d,%d) [%s]", x1, y1, z1, x2, y2, z2, worldName);
    }
}
