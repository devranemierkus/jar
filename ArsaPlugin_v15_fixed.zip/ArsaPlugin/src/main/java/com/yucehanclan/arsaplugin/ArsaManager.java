package com.yucehanclan.arsaplugin;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.logging.Logger;

/**
 * data.yml — direkt UUID, sade format:
 *
 * 4f771729-11e1-3791-9fd3-60bc2c49266a:
 *   arsa: true
 *   koordinat: 100,60,100,150,90,150,world
 *
 * Başka hiçbir şey yok.
 */
public class ArsaManager {

    private final Logger  logger;
    private final File    dataFile;
    private YamlConfiguration cfg;

    // Online oyuncular için hızlı cache
    private final Map<UUID, ArsaData> cache         = new HashMap<>();
    private final Set<UUID>           pendingBooks   = new HashSet<>();
    private final Set<UUID>           pendingRevoke  = new HashSet<>();

    public ArsaManager(ArsaPlugin plugin) {
        this.logger   = plugin.getLogger();
        this.dataFile = new File(plugin.getDataFolder(), "data.yml");
    }

    // ── BAŞLANGIÇ ────────────────────────────────────────────────────────────

    public void loadAll() {
        if (!dataFile.getParentFile().exists()) dataFile.getParentFile().mkdirs();
        if (!dataFile.exists()) {
            try { dataFile.createNewFile(); } catch (IOException e) { logger.severe(e.getMessage()); }
        }
        cfg = YamlConfiguration.loadConfiguration(dataFile);

        // Tüm UUID kayıtlarını cache'e al
        for (String key : cfg.getKeys(false)) {
            try {
                UUID uuid = UUID.fromString(key);
                if (!cfg.getBoolean(key + ".arsa", false)) continue;
                ArsaData d = parse(uuid, cfg.getString(key + ".koordinat", ""));
                if (d != null) {
                    cache.put(uuid, d);
                    if (cfg.getBoolean(key + ".pb", false)) pendingBooks.add(uuid);
                    if (cfg.getBoolean(key + ".pr", false)) pendingRevoke.add(uuid);
                }
            } catch (Exception ignored) {}
        }
        logger.info(cache.size() + " arsa yuklendi.");
    }

    // ── YAZMA / SİLME ────────────────────────────────────────────────────────

    private void save(ArsaData d) {
        String k = d.getOwnerUUID().toString();
        cfg.set(k + ".arsa",      true);
        cfg.set(k + ".koordinat", d.getX1()+","+d.getY1()+","+d.getZ1()+","
                                 +d.getX2()+","+d.getY2()+","+d.getZ2()+","+d.getWorldName());
        cfg.set(k + ".pb", pendingBooks.contains(d.getOwnerUUID()));
        cfg.set(k + ".pr", pendingRevoke.contains(d.getOwnerUUID()));
        flush();
    }

    private void delete(UUID uuid) {
        cfg.set(uuid.toString(), null);
        flush();
    }

    private void flush() {
        try { cfg.save(dataFile); } catch (IOException e) { logger.severe(e.getMessage()); }
    }

    // ── CRUD ─────────────────────────────────────────────────────────────────

    public void addArsa(ArsaData d) {
        cache.put(d.getOwnerUUID(), d);
        save(d);
    }

    public void removeArsa(UUID uuid) {
        cache.remove(uuid);
        pendingBooks.remove(uuid);
        pendingRevoke.remove(uuid);
        delete(uuid);
    }

    public ArsaData getArsaByUUID(UUID uuid) { return cache.get(uuid); }
    public boolean  hasArsa(UUID uuid)        { return cache.containsKey(uuid); }

    public ArsaData getArsaByName(String name) {
        for (ArsaData d : cache.values())
            if (d.getOwnerName().equalsIgnoreCase(name)) return d;
        @SuppressWarnings("deprecation")
        OfflinePlayer op = Bukkit.getOfflinePlayer(name);
        if (op != null && op.hasPlayedBefore()) return cache.get(op.getUniqueId());
        return null;
    }

    public UUID getUUIDByName(String name) {
        for (ArsaData d : cache.values())
            if (d.getOwnerName().equalsIgnoreCase(name)) return d.getOwnerUUID();
        @SuppressWarnings("deprecation")
        OfflinePlayer op = Bukkit.getOfflinePlayer(name);
        return (op != null && op.hasPlayedBefore()) ? op.getUniqueId() : null;
    }

    public Map<UUID, ArsaData> getAllArsalar() { return Collections.unmodifiableMap(cache); }

    // ── PENDING ───────────────────────────────────────────────────────────────

    public void setPendingBook(UUID uuid) {
        pendingBooks.add(uuid);
        ArsaData d = cache.get(uuid); if (d != null) save(d);
    }
    public boolean hasPendingBook(UUID uuid)  { return pendingBooks.contains(uuid); }
    public void clearPendingBook(UUID uuid) {
        pendingBooks.remove(uuid);
        ArsaData d = cache.get(uuid); if (d != null) save(d);
    }

    public void setPendingRevoke(UUID uuid) {
        pendingRevoke.add(uuid); pendingBooks.remove(uuid);
        ArsaData d = cache.get(uuid);
        if (d != null) save(d);
        else { cfg.set(uuid + ".pr", true); flush(); }
    }
    public boolean hasPendingRevoke(UUID uuid) { return pendingRevoke.contains(uuid); }
    public void clearPendingRevoke(UUID uuid) {
        pendingRevoke.remove(uuid);
        ArsaData d = cache.get(uuid);
        if (d != null) save(d);
        else { cfg.set(uuid.toString(), null); flush(); }
    }

    // ── YARDIMCI ─────────────────────────────────────────────────────────────

    private ArsaData parse(UUID uuid, String koord) {
        try {
            String[] k = koord.split(",");
            if (k.length < 7) return null;
            OfflinePlayer op = Bukkit.getOfflinePlayer(uuid);
            String name = op.getName() != null ? op.getName() : uuid.toString().substring(0, 8);
            return new ArsaData(uuid, name, k[6].trim(),
                Integer.parseInt(k[0].trim()), Integer.parseInt(k[1].trim()), Integer.parseInt(k[2].trim()),
                Integer.parseInt(k[3].trim()), Integer.parseInt(k[4].trim()), Integer.parseInt(k[5].trim()));
        } catch (Exception e) { return null; }
    }
}
