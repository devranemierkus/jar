package com.yucehanrp.managers;

import com.yucehanrp.SessionData;
import com.yucehanrp.util.C;
import com.yucehanrp.util.ItemUtil;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;

public class PvpSumoManager {

    private final SessionData data;
    private final InventoryManager invManager;
    private final GameHeadManager headManager;

    public PvpSumoManager(SessionData data, InventoryManager invManager, GameHeadManager headManager) {
        this.data = data;
        this.invManager = invManager;
        this.headManager = headManager;
    }

    // ==================== PVP ====================
    public void startPvp(Player player) {
        invManager.invKaydet(player);
        data.pvpMode.put(player.getUniqueId(), true);

        player.getInventory().clear();
        player.setGameMode(GameMode.SURVIVAL);
        player.getInventory().setHelmet(new ItemStack(Material.LEATHER_HELMET));
        player.getInventory().setChestplate(new ItemStack(Material.LEATHER_CHESTPLATE));
        player.getInventory().setLeggings(new ItemStack(Material.LEATHER_LEGGINGS));
        player.getInventory().setBoots(new ItemStack(Material.LEATHER_BOOTS));
        player.getInventory().setItem(0, makePvpAxe());

        player.teleport(new Location(Bukkit.getWorld("world"), -13, -60, 9999975));
        player.setHealth(20);
        player.setFoodLevel(20);

        player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
        player.sendMessage(C.c("&c&lPVP &8> &fHosgeldin! Sadece Sistem baltasi kullanilabilir."));
        player.sendMessage(C.c("&7Cikmak icin: &e/oyundancik"));
        player.sendMessage(C.c("&e&l⚠ &cArsan varsa önce arsandan çık!"));
        player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
        player.sendMessage(C.c(" &6&l⚠ EŞYA GÜVENLİĞİ UYARISI"));
        player.sendMessage(C.c("&a✔ &7Oyundan normal çıkarsanız (/oyundancik) &aeşyalar anında iade edilir."));
        player.sendMessage(C.c("&a✔ &7Sunucu kapanır/restart atılırsa &aeşyalar korunur, tekrar girebilirsiniz."));
        player.sendMessage(C.c("&c✘ &7Oyun içinde bağlantı koparsa &8(internet/DC)&7 eşyalar 3 gün saklanır."));
        player.sendMessage(C.c("&c✘ &c&l3 gün içinde girmezseniz eşyalar silinir, iade yapılmaz!"));
        player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
    }

    public void stopPvp(Player player) {
        data.pvpMode.remove(player.getUniqueId());
        invManager.invGeriYukle(player);
        player.setGameMode(GameMode.ADVENTURE);
        player.teleport(new Location(Bukkit.getWorld("world"), -15, -60, -8));
        headManager.giveGameHead(player);
    }

    public ItemStack makePvpAxe() {
        ItemStack axe = new ItemStack(Material.IRON_AXE);
        ItemMeta meta = axe.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(C.c(SessionData.PVP_WEAPON_NAME));
            meta.setLore(C.lore(SessionData.PVP_WEAPON_LORE));
            axe.setItemMeta(meta);
        }
        return axe;
    }

    public boolean isPvpWeapon(ItemStack item) {
        return item != null && ItemUtil.displayName(item).equals(C.c(SessionData.PVP_WEAPON_NAME));
    }

    // ==================== SUMO ====================
    public void startSumo(Player player) {
        invManager.invKaydet(player);
        data.sumoMode.put(player.getUniqueId(), true);

        player.getInventory().clear();
        player.setGameMode(GameMode.SURVIVAL);
        player.teleport(new Location(Bukkit.getWorld("world"), -11, -59, 9999920));
        player.setHealth(20);
        player.setFoodLevel(20);

        player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
        player.sendMessage(C.c("&a&lSUMO &8> &fHosgeldin! Sadece yumruk ile vur."));
        player.sendMessage(C.c("&7Cikmak icin: &e/oyundancik"));
        player.sendMessage(C.c("&e&l⚠ &cArsan varsa önce arsandan çık!"));
        player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
        player.sendMessage(C.c(" &6&l⚠ EŞYA GÜVENLİĞİ UYARISI"));
        player.sendMessage(C.c("&a✔ &7Oyundan normal çıkarsanız (/oyundancik) &aeşyalar anında iade edilir."));
        player.sendMessage(C.c("&a✔ &7Sunucu kapanır/restart atılırsa &aeşyalar korunur, tekrar girebilirsiniz."));
        player.sendMessage(C.c("&c✘ &7Oyun içinde bağlantı koparsa &8(internet/DC)&7 eşyalar 3 gün saklanır."));
        player.sendMessage(C.c("&c✘ &c&l3 gün içinde girmezseniz eşyalar silinir, iade yapılmaz!"));
        player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
        player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
        player.sendTitle(C.c("&a&lSUMO!"), C.c("&7/oyundancik ile cikabilirsin"), 10, 70, 20);
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.5f, 1f);
    }

    public void stopSumo(Player player) {
        data.sumoMode.remove(player.getUniqueId());
        invManager.invGeriYukle(player);
        player.setGameMode(GameMode.ADVENTURE);
        player.teleport(new Location(Bukkit.getWorld("world"), -15, -60, -8));
        headManager.giveGameHead(player);
    }
}
