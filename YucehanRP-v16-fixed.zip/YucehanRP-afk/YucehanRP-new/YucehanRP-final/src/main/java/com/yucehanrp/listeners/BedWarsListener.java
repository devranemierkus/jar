package com.yucehanrp.listeners;

import com.yucehanrp.SessionData;
import com.yucehanrp.managers.*;
import com.yucehanrp.util.C;
import com.yucehanrp.util.ItemUtil;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;

import java.util.UUID;

/**
 * Bed Wars blok koruması (blok kır/koy) ve BW mağazası.
 */
public class BedWarsListener implements Listener, CommandExecutor {

    private final Plugin plugin;
    private final SessionData data;
    private final BedWarsManager bedWars;
    private final InventoryManager invManager;
    private final GameHeadManager headManager;

    public BedWarsListener(Plugin plugin, SessionData data, BedWarsManager bedWars,
                           InventoryManager invManager, GameHeadManager headManager) {
        this.plugin = plugin;
        this.data = data;
        this.bedWars = bedWars;
        this.invManager = invManager;
        this.headManager = headManager;
    }

    // ==================== BLOK KIRMA ====================
    @EventHandler
    public void onBlockBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();
        Block block = event.getBlock();
        double x = block.getX(), y = block.getY(), z = block.getZ();

        if (!data.bwActive && !data.bwInLobby.containsKey(uuid) && !data.bwTeam.containsKey(uuid)) return;

        // BW oyuncu değilse bu alandaki her bloğu engelle
        if (bedWars.isProtectedArea(x, y, z)) {
            if (!data.bwTeam.containsKey(uuid)) { event.setCancelled(true); return; }
        }

        // BW oyuncusu
        if (data.bwTeam.containsKey(uuid)) {
            // Alan dışında blok kıramaz
            if (bedWars.isOutOfBounds(x, z)) {
                event.setCancelled(true);
                player.sendActionBar(C.c("&c[BW] Haritanın dışında blok kıramazsın!"));
                return;
            }
            // Yatak koruması - sadece düşman yatak
            String bedTeam = bedWars.getBedTeam(x, y, z);
            if (bedTeam != null) {
                String myTeam = data.bwTeam.get(uuid);
                if (bedTeam.equals(myTeam)) {
                    event.setCancelled(true);
                    player.sendActionBar(C.c("&c[BW] Kendi yatağını kıramazsın!"));
                    return;
                }
                if (!Boolean.TRUE.equals(data.bwBedAlive.get(bedTeam))) {
                    event.setCancelled(true);
                    player.sendActionBar(C.c("&c[BW] Bu yatak zaten kırık!"));
                    return;
                }
                // Düşman yatak kırıldı — .sk bwYatakKirildi çağır
                event.setCancelled(true);
                event.getBlock().setType(Material.AIR);
                bedWars.yatakKirildi(bedTeam, player);
                return;
            }
            // Oyuncu tarafından yerleştirilen blok kırılabilir
            if (!data.bwPlacedBlocks.contains(block.getLocation())) {
                event.setCancelled(true);
                player.sendActionBar(C.c("&c[BW] Bu blok kırılamaz!"));
            } else {
                data.bwPlacedBlocks.remove(block.getLocation());
            }
        }
    }

    // ==================== BLOK KOYMA ====================
    @EventHandler
    public void onBlockPlace(BlockPlaceEvent event) {
        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();
        Block block = event.getBlock();
        double x = block.getX(), y = block.getY(), z = block.getZ();

        // BW alanı değilse dokunma
        if (bedWars.isOutOfBounds(x, z)) return;

        // BW alanı içinde herkes için: korunan bölge → CANCEL
        if (bedWars.isProtectedArea(x, y, z)) {
            event.setCancelled(true);
            player.sendActionBar(C.c("&c[BW] Bu alana blok koyamazsın!"));
            return;
        }

        // BW lobisi → CANCEL
        if (data.bwInLobby.containsKey(uuid)) {
            event.setCancelled(true);
            return;
        }

        // BW spectator → CANCEL
        if (data.bwSpec.containsKey(uuid)) {
            event.setCancelled(true);
            return;
        }

        // BW aktif oyuncusu
        if (data.bwTeam.containsKey(uuid)) {
            // Harita zeminine blok koyma yasak (Y < 40)
            if (y < 40) {
                event.setCancelled(true);
                player.sendActionBar(C.c("&c[BW] Bu alana blok koyamazsın!"));
                return;
            }
            data.bwPlacedBlocks.add(block.getLocation());
            return;
        }

        // BW alanında BW oyuncusu DEĞIL → CANCEL (non-BW kişiler bu alana koyamaz)
        event.setCancelled(true);
    }

    // ==================== BW MAĞAZA KOMUTU ====================
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) return true;
        UUID uuid = player.getUniqueId();
        if (!data.bwActive) {
            player.sendMessage(C.c("&c[BW] Aktif bir oyun yok!"));
            return true;
        }
        if (!data.bwTeam.containsKey(uuid)) {
            player.sendMessage(C.c("&c[BW] Bu komutu sadece BedWars oyuncuları kullanabilir!"));
            return true;
        }
        openBwShop(player);
        return true;
    }

    private void openBwShop(Player player) {
        // .sk bwMagazaAc — birebir slot, fiyat, isim
        Inventory gui = Bukkit.createInventory(null, 54, C.c("&c&l🛏 BED WARS MAĞAZA"));

        // Silahlar — slot 0-3
        gui.setItem(0,  shopItem(Material.STONE_SWORD,    "Taş Kılıç",      "8 Demir",   8,  "demir"));
        gui.setItem(1,  shopItem(Material.IRON_SWORD,     "Demir Kılıç",    "15 Demir",  15, "demir"));
        gui.setItem(2,  shopItem(Material.DIAMOND_SWORD,  "Elmas Kılıç",    "10 Altın",  10, "altin"));
        gui.setItem(3,  shopItem(Material.WOODEN_AXE,     "Balta",          "6 Demir",   6,  "demir"));

        // Zırh — slot 9-11
        gui.setItem(9,  shopItem(Material.LEATHER_CHESTPLATE, "Deri Zırh Seti", "12 Demir", 12, "demir"));
        gui.setItem(10, shopItem(Material.IRON_CHESTPLATE,    "Demir Göğüslük", "8 Altın",  8,  "altin"));
        gui.setItem(11, shopItem(Material.IRON_HELMET,        "Demir Kask",     "5 Altın",  5,  "altin"));

        // İnşaat — slot 18-22
        gui.setItem(18, shopItem(Material.WHITE_WOOL,   "Yün Blok x16", "6 Demir",  6,  "demir"));
        gui.setItem(19, shopItem(Material.SANDSTONE,    "Taş x16",      "9 Demir",  9,  "demir"));
        gui.setItem(20, shopItem(Material.OAK_PLANKS,   "Tahta x16",    "5 Demir",  5,  "demir"));
        gui.setItem(21, shopItem(Material.GLASS,        "Cam x8",       "4 Demir",  4,  "demir"));
        gui.setItem(22, shopItem(Material.OBSIDIAN,     "Obsidyen x2",  "10 Altın", 10, "altin"));

        // Menzil — slot 27-28
        gui.setItem(27, shopItem(Material.BOW,   "Bow",    "9 Demir", 9, "demir"));
        gui.setItem(28, shopItem(Material.ARROW, "Ok x16", "4 Demir", 4, "demir"));

        // Yardımcı — slot 29-33
        gui.setItem(29, shopItem(Material.FISHING_ROD,   "İp",         "8 Demir",  8, "demir"));
        gui.setItem(30, shopItem(Material.GOLDEN_APPLE,  "Altın Elma", "5 Altın",  5, "altin"));
        gui.setItem(31, shopItem(Material.ENDER_PEARL,   "Ender İnci", "4 Altın",  4, "altin"));
        gui.setItem(32, shopItem(Material.BREAD,         "Ekmek x5",   "4 Demir",  4, "demir"));
        gui.setItem(33, shopItem(Material.COOKED_BEEF,   "Biftek x3",  "6 Demir",  6, "demir"));

        // Kapat — slot 53
        gui.setItem(53, ItemUtil.make(Material.BARRIER, "&c&lKAPAT"));

        // Boş slotlar
        for (int i = 0; i < 54; i++) if (gui.getItem(i) == null) gui.setItem(i, ItemUtil.fillSlot());
        player.openInventory(gui);
    }

    private ItemStack shopItem(Material mat, String name, String loreStr, int price, String currency) {
        ItemStack item = new ItemStack(mat);
        org.bukkit.inventory.meta.ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            // Display name plain (switch matching için renksiz tutulur)
            meta.setDisplayName(name); // switch'te stripColor ile karşılaştırılır
            meta.setLore(C.lore("&7" + loreStr + "||&8Para: &e" + currency + " &7x&f" + price));
            item.setItemMeta(meta);
        }
        return item;
    }
}
