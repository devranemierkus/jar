package com.yucehanrp.managers;

import com.yucehanrp.SessionData;
import com.yucehanrp.util.C;
import com.yucehanrp.util.ItemUtil;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.*;

public class KatilKimManager {

    private final SessionData data;
    private final InventoryManager invManager;
    private final GameHeadManager headManager;
    private final Random rng = new Random();

    public KatilKimManager(SessionData data, InventoryManager invManager, GameHeadManager headManager) {
        this.data = data;
        this.invManager = invManager;
        this.headManager = headManager;
    }

    public Location spawnLoc(int index) {
        World w = Bukkit.getWorld("world");
        return switch (index) {
            case 1 -> new Location(w, -170.07, -59, 10000165.01);
            case 2 -> new Location(w, -183.57, -59, 10000108.92);
            case 3 -> new Location(w, -153.82, -59, 10000079.11);
            case 4 -> new Location(w, -230.74, -60, 10000070.69);
            case 5 -> new Location(w, -200.67, -60, 10000077.98);
            case 6 -> new Location(w, -199.20, -51, 10000138.43);
            case 7 -> new Location(w, -147.26, -60, 10000107.99);
            case 8 -> new Location(w, -174.65, -59, 10000101.02);
            case 9 -> new Location(w, -233.93, -60, 10000099.92);
            case 10 -> new Location(w, -197.97, -50, 10000113.22);
            case 11 -> new Location(w, -147.57, -59, 10000162.70);
            case 12 -> new Location(w, -159.15, -60, 10000154.26);
            case 13 -> new Location(w, -177.21, -60, 10000148.03);
            case 14 -> new Location(w, -204.40, -60, 10000116.93);
            case 15 -> new Location(w, -227.37, -60, 10000127.61);
            case 16 -> new Location(w, -185.96, -60, 10000070.56);
            default -> new Location(w, -230, -60, 10000158);
        };
    }

    public ItemStack makeKatilKilici() {
        ItemStack sword = new ItemStack(Material.IRON_SWORD);
        ItemMeta meta = sword.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(C.c("&c&lKATİL KILICI"));
            meta.setLore(List.of(C.c("&8[KK-KOPYALANAMAZ]")));
            sword.setItemMeta(meta);
        }
        return sword;
    }

    public ItemStack makeSerifYayi() {
        ItemStack bow = new ItemStack(Material.BOW);
        ItemMeta meta = bow.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(C.c("&e&lSERIF YAYI"));
            meta.setLore(List.of(C.c("&8[KK-KOPYALANAMAZ]")));
            bow.setItemMeta(meta);
        }
        return bow;
    }

    public ItemStack makeSerifOku() {
        ItemStack arrow = new ItemStack(Material.ARROW, 1);
        ItemMeta meta = arrow.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(C.c("&e&lSERIF OKU"));
            arrow.setItemMeta(meta);
        }
        return arrow;
    }

    // katilkim.kuyruk — oyun aktifken veya lobi doluyken bekleme listesi
    private final java.util.List<UUID> kkWaitQueue = new java.util.ArrayList<>();

    public void lobiGir(Player player) {
        UUID uuid = player.getUniqueId();

        // .sk: oyun aktifse sıraya al
        if (data.katilKimActive) {
            if (kkWaitQueue.contains(uuid)) {
                player.sendMessage(C.c("&4[KATİL KİM] &7Zaten sıradasınız!")); return;
            }
            kkWaitQueue.add(uuid);
            int sirano = kkWaitQueue.size();
            player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
            player.sendMessage(C.c("&4&l  ⏳ SIRAYA ALINDIN!"));
            player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
            player.sendMessage(C.c("&7Şu an bir oyun aktif. Sen &e" + sirano + ". sıradasın."));
            player.sendMessage(C.c("&7Oyun bittiği anda &aotomatik olarak lobiye alınacaksın."));
            player.sendTitle(C.c("&4&l⏳ SIRAYA ALINDIN"),
                C.c("&e" + sirano + ". sıradasın &8| Oyun bitince otomatik gireceksin"), 10, 60, 20);
            player.playSound(player.getLocation(), org.bukkit.Sound.BLOCK_NOTE_BLOCK_PLING, 0.5f, 1f);
            return;
        }

        // Zaten lobideyse
        if (data.katilKimRole.containsKey(uuid)) {
            player.sendMessage(C.c("&4[KATİL KİM] &7Zaten lobidesiniz!")); return;
        }

        // Başka oyundaysa engelle
        if (data.isInAnyGame(uuid)) {
            player.sendActionBar(C.c("&cÖnce mevcut oyundan çık! (/oyundancik)")); return;
        }

        // .sk: lobi max 12 kişi doluysa sıraya al
        if (data.katilKimQueue.size() >= 12) {
            if (kkWaitQueue.contains(uuid)) {
                player.sendMessage(C.c("&4[KATİL KİM] &7Zaten sıradasınız!")); return;
            }
            kkWaitQueue.add(uuid);
            int sirano = kkWaitQueue.size();
            player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
            player.sendMessage(C.c("&4&l  🔒 LOBİ DOLU! (12/12)"));
            player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
            player.sendMessage(C.c("&7Lobi şu an &c12/12 &7dolu."));
            player.sendMessage(C.c("&7Sıradaki oyun için &e" + sirano + ". sıradasın."));
            player.sendTitle(C.c("&4&l🔒 LOBİ DOLU"),
                C.c("&eSıradaki oyun için &e" + sirano + ". sıradasın"), 10, 60, 20);
            player.playSound(player.getLocation(), org.bukkit.Sound.BLOCK_NOTE_BLOCK_BASS, 0.5f, 0.8f);
            return;
        }

        // Lobiye al
        invManager.invKaydet(player);
        player.getInventory().clear();
        player.setGameMode(GameMode.ADVENTURE);
        player.teleport(new Location(Bukkit.getWorld("world"), -230, -60, 10000157));

        data.katilKimRole.put(uuid, "lobi");
        data.katilKimQueue.add(uuid);
        int lobiSayi = data.katilKimQueue.size();

        player.sendTitle(C.c("&4&lKATİL KİM"),
            C.c("&7Lobi: &e" + lobiSayi + "/12"), 10, 60, 20);
        player.sendMessage(C.c("&4&l[KATİL KİM] &7Lobiye katıldın! (" + lobiSayi + "/12)"));
        player.sendMessage(C.c("&e&l⚠ &cArsan varsa önce arsandan çık!"));
        player.sendMessage(C.c("&6&l⚠ DC: &7Sunucu çökerse eşyaların korunur, ama oyun anında DC çekmemeye dikkat et!"));
        if (lobiSayi == 1) {
            player.sendMessage(C.c("&7Oyun başlamak için &e1 &7oyuncu daha gerek!"));
        }
        player.playSound(player.getLocation(), org.bukkit.Sound.BLOCK_NOTE_BLOCK_PLING, 0.5f, 1.5f);

        // Diğer lobi oyuncularına bildir
        for (UUID uid : data.katilKimQueue) {
            if (!uid.equals(uuid)) {
                Player lp = Bukkit.getPlayer(uid);
                if (lp != null)
                    lp.sendMessage(C.c("&4[KATİL KİM] &e" + player.getName()
                        + " &7katıldı! &8(" + lobiSayi + "/12 oyuncu)"));
            }
        }

        if (!data.katilKimLobbyCountdown && lobiSayi >= 2) {
            data.katilKimLobbyCountdown = true;
            startLobbyCountdown();
        }
    }

    /** Oyun bitince bekleme sırasındakileri lobiye al */
    public void processWaitQueue() {
        for (UUID uid : new java.util.ArrayList<>(kkWaitQueue)) {
            Player p = Bukkit.getPlayer(uid);
            if (p != null && p.isOnline()) {
                kkWaitQueue.remove(uid);
                p.sendMessage(C.c("&4&l[KATİL KİM] &aSıra geldi! &7Yeni lobiye otomatik alındın."));
                lobiGir(p);
            } else {
                kkWaitQueue.remove(uid);
            }
        }
    }

    public void lobiCik(Player player) {
        UUID uuid = player.getUniqueId();
        data.katilKimRole.remove(uuid);
        data.katilKimQueue.remove(uuid);
        data.katilKimPlayers.remove(uuid);
        data.katilKimSpectators.remove(uuid);

        invManager.invGeriYukle(player);
        player.setGameMode(GameMode.ADVENTURE);
        player.teleport(new Location(Bukkit.getWorld("world"), -15, -60, -8));
        headManager.giveGameHead(player);
    }

    private void startLobbyCountdown() {
        org.bukkit.plugin.Plugin plugin = Bukkit.getPluginManager().getPlugin("YucehanRP");
        new org.bukkit.scheduler.BukkitRunnable() {
            @Override
            public void run() {
                if (!data.katilKimLobbyCountdown) { cancel(); return; }
                data.katilKimLobbyTime--;
                if (data.katilKimLobbyTime > 0) {
                    if (data.katilKimLobbyTime % 10 == 0 || data.katilKimLobbyTime <= 5) {
                        broadcastToLobi(C.c("&4[KATİL KİM] &e" + data.katilKimLobbyTime + " &7saniye sonra başlıyor!"));
                    }
                } else {
                    cancel();
                    if (data.katilKimQueue.size() < 2) {
                        data.katilKimLobbyCountdown = false;
                        data.katilKimLobbyTime = 120;
                        broadcastToLobi(C.c("&c[KK] Yeterli oyuncu yok, lobi iptal edildi."));
                        return;
                    }
                    startGame();
                }
            }
        }.runTaskTimer(plugin, 20L, 20L);
    }

    public void startGame() {
        data.katilKimLobbyCountdown = false;
        data.katilKimActive = true;
        data.katilKimTime = 600;

        // Max 12 oyuncu - fazlası sıraya alınır
        List<UUID> participants = new ArrayList<>(data.katilKimQueue);
        if (participants.size() > 12) {
            participants = participants.subList(0, 12);
        }

        // Katil ve Şerif seç
        Collections.shuffle(participants);
        UUID katilUUID = participants.get(0);
        UUID serifUUID = participants.get(1);
        data.katilKimKatil = katilUUID;
        data.katilKimSerif = serifUUID;

        // Spawn konumlarını random dağıt
        List<Integer> spawnIndices = new ArrayList<>();
        for (int i = 1; i <= 16; i++) spawnIndices.add(i);
        Collections.shuffle(spawnIndices);

        int spawnIdx = 0;
        for (UUID uuid : participants) {
            Player p = Bukkit.getPlayer(uuid);
            if (p == null) continue;

            data.katilKimQueue.remove(uuid);
            data.katilKimPlayers.add(uuid);

            String role;
            if (uuid.equals(katilUUID)) role = "katil";
            else if (uuid.equals(serifUUID)) role = "serif";
            else role = "masum";

            data.katilKimRole.put(uuid, role);

            p.getInventory().clear();
            p.setGameMode(GameMode.ADVENTURE);
            p.setHealth(20);
            p.teleport(spawnLoc(spawnIndices.get(spawnIdx++)));

            // Eşyaları ver — kılıç slot 9 (idx 8), yay slot 9 (idx 8), ok slot 8 (idx 7)
            if (role.equals("katil")) {
                p.getInventory().setItem(8, makeKatilKilici());
                p.sendTitle(C.c("&c&lSEN KATİLSİN!"), C.c("&7Tüm masumları öldür!"), 10, 80, 20);
                p.sendMessage(C.c("&4&l[KATİL KİM] &cRolün: &lKATİL! Kılıcın slot 9'da."));
            } else if (role.equals("serif")) {
                p.getInventory().setItem(8, makeSerifYayi());
                p.getInventory().setItem(7, makeSerifOku());
                p.sendTitle(C.c("&e&lSEN ŞERİFSİN!"), C.c("&7Katili bul ve vur!"), 10, 80, 20);
                p.sendMessage(C.c("&4&l[KATİL KİM] &eRolün: &lŞERİF! Yay slot 9, ok slot 8'de."));
            } else {
                p.sendTitle(C.c("&7&lSEN MASUMSUN!"), C.c("&7Hayatta kal!"), 10, 80, 20);
                p.sendMessage(C.c("&4&l[KATİL KİM] &7Rolün: &lMASUM! Hayatta kal."));
            }
            // Tüm oyuncular slot 1 ile başlasın
            p.getInventory().setHeldItemSlot(0);
            p.playSound(p.getLocation(), Sound.ENTITY_WITHER_SPAWN, 0.5f, 1f);
            // DC uyarısı
            p.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
            p.sendMessage(C.c(" &6&l⚠ ÖNEMLİ UYARI"));
            p.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
            p.sendMessage(C.c(" &6&l⚠ EŞYA GÜVENLİĞİ UYARISI"));
            p.sendMessage(C.c("&a✔ &7Oyundan normal çıkarsanız (/oyundancik) &aeşyalar anında iade edilir."));
            p.sendMessage(C.c("&a✔ &7Sunucu kapanır/restart atılırsa &aeşyalar korunur, tekrar girebilirsiniz."));
            p.sendMessage(C.c("&c✘ &7Oyun içinde bağlantı koparsa &8(internet/DC)&7 eşyalar 3 gün saklanır."));
            p.sendMessage(C.c("&c✘ &c&l3 gün içinde girmezseniz eşyalar silinir, iade yapılmaz!"));
            p.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
            p.sendMessage(C.c("&7Oyundan çıkmak için: &e/oyundancik"));
            p.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
        }

        // Oyun timer başlat
        startGameTimer();
    }

    private void startGameTimer() {
        org.bukkit.plugin.Plugin plugin = Bukkit.getPluginManager().getPlugin("YucehanRP");
        new org.bukkit.scheduler.BukkitRunnable() {
            @Override
            public void run() {
                if (!data.katilKimActive) { cancel(); return; }
                data.katilKimTime--;
                if (data.katilKimTime % 1 == 0) {
                    int dk = data.katilKimTime / 60;
                    int sn = data.katilKimTime % 60;
                    for (UUID uid : new ArrayList<>(data.katilKimPlayers)) {
                        Player p = Bukkit.getPlayer(uid);
                        if (p == null) continue;
                        String rol = data.katilKimRole.getOrDefault(uid, "masum");
                        String prefix = switch (rol) {
                            case "katil" -> "&c⚔ KATİL";
                            case "serif" -> "&e⚖ SERİF";
                            default -> "&7😇 MASUM";
                        };
                        String urgency = data.katilKimTime <= 30 ? " &c&l⚠ ACİL!" : data.katilKimTime <= 60 ? " &e⚡" : "";
                        p.sendActionBar(C.c(prefix + " &8| &7Süre: &c" + dk + "dk " + sn + "sn &8| &fHayatta: " + data.katilKimPlayers.size() + urgency));
                    }
                    // Son 30 saniyede her 10 saniyede ses çal
                    if (data.katilKimTime <= 30 && data.katilKimTime % 10 == 0) {
                        for (UUID uid : new ArrayList<>(data.katilKimPlayers)) {
                            Player p = Bukkit.getPlayer(uid);
                            if (p != null) p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 1f, 0.5f);
                        }
                    }
                }
                if (data.katilKimTime <= 0) {
                    cancel();
                    endGame("masum_sure");
                }
            }
        }.runTaskTimer(plugin, 20L, 20L);
    }

    public void playerEliminated(Player victim, String reason) {
        UUID uuid = victim.getUniqueId();
        String role = data.katilKimRole.getOrDefault(uuid, "masum");

        victim.setHealth(20);
        victim.teleport(new Location(Bukkit.getWorld("world"), -230, -60, 10000158));
        victim.setGameMode(GameMode.SPECTATOR);

        data.katilKimPlayers.remove(uuid);
        data.katilKimSpectators.add(uuid);
        data.katilKimRole.put(uuid, "spec");

        // Sadece KK içindeki oyunculara bildir, dışarı çıkmasın
        broadcastToAll(C.c("&4[KATİL KİM] &f" + victim.getName() + " &7elendi! (" + reason + ")"));

        checkWinner();
    }

    public void checkWinner() {
        if (!data.katilKimActive) return;

        boolean katilAlive = false;
        boolean serifAlive = false;
        int masumCount = 0;

        for (UUID uid : data.katilKimPlayers) {
            String role = data.katilKimRole.get(uid);
            if (role == null) continue;
            if (role.equals("katil")) katilAlive = true;
            else if (role.equals("serif")) serifAlive = true;
            else if (role.equals("masum")) masumCount++;
        }

        // Katil yoksa masumlar kazandı
        if (!katilAlive) {
            endGame("masum_kazandi");
        }
        // Masum ve Şerif yoksa katil kazandı
        else if (masumCount == 0 && !serifAlive) {
            endGame("katil_kazandi");
        }
    }

    public void endGame(String sebep) {
        if (!data.katilKimActive) return;
        data.katilKimActive = false;

        String msg = switch (sebep) {
            case "masum_kazandi" -> "&7&lMASUMLAR VE ŞERİF KAZANDI!";
            case "katil_kazandi" -> "&c&lKATİL KAZANDI!";
            case "serif_katili_vurdu" -> "&e&lŞERİF KAZANDI! Katili vurdu!";
            case "masum_sure" -> "&7Süre doldu! Masumlar kazandı!";
            case "katil_serif_cikti" -> "&7Katil/Şerif oyundan çıktı. Masumlar kazandı!";
            case "masum_katil_cikti" -> "&7Katil kaçtı! Masumlar kazandı!";
            default -> "&7Oyun bitti!";
        };

        // Sadece KK oyuncularına bildir
        broadcastToAll(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
        broadcastToAll(C.c("     &4&l★ KATİL KİM BİTTİ! ★"));
        broadcastToAll(C.c("     " + msg));
        broadcastToAll(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));

        // Arena temizle
        arenaTemizle();

        // .sk: 5 saniye sonra tüm oyuncuları çıkar + sıra kuyruğunu işle
        Bukkit.getScheduler().runTaskLater(Bukkit.getPluginManager().getPlugin("YucehanRP"), () -> {
            List<UUID> all = new ArrayList<>();
            all.addAll(data.katilKimPlayers);
            all.addAll(data.katilKimSpectators);
            for (UUID uid : all) {
                Player p = Bukkit.getPlayer(uid);
                if (p != null) lobiCik(p);
            }
            data.katilKimKatil = null;
            data.katilKimSerif = null;
            data.katilKimTime = 600;
            data.katilKimLobbyTime = 120;
            // .sk: sıradaki oyuncularla yeni lobi başlat
            if (!kkWaitQueue.isEmpty()) {
                broadcastToAll(C.c("&4&l[KATİL KİM] &eSıradaki oyuncularla yeni lobi başlatılıyor!"));
                processWaitQueue();
            }
        }, 100L);
    }

    public void arenaTemizle() {
        World world = Bukkit.getWorld("world");
        if (world == null) return;
        Location center = new Location(world, -192, -45, 10000112);
        center.getWorld().getNearbyEntities(center, 120, 120, 120).forEach(e -> {
            if (e instanceof org.bukkit.entity.Item item) {
                String name = ItemUtil.uncoloredName(item.getItemStack());
                if (name.contains("SERIF MIRASI") || name.contains("SERIF YAYI")
                        || name.contains("SERIF OKU") || name.contains("KATIL KILICI")) {
                    e.remove();
                }
            }
        });
    }

    public void broadcastToLobi(String msg) {
        for (UUID uid : data.katilKimQueue) {
            Player p = Bukkit.getPlayer(uid);
            if (p != null) p.sendMessage(msg);
        }
    }

    public void broadcastToAll(String msg) {
        for (UUID uid : data.katilKimPlayers) {
            Player p = Bukkit.getPlayer(uid);
            if (p != null) p.sendMessage(msg);
        }
        for (UUID uid : data.katilKimSpectators) {
            Player p = Bukkit.getPlayer(uid);
            if (p != null) p.sendMessage(msg);
        }
    }
}
