package com.yucehanrp.managers;

import com.yucehanrp.SessionData;
import com.yucehanrp.util.C;
import com.yucehanrp.util.ItemUtil;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.UUID;

public class PhoneManager {

    private final SessionData data;

    public PhoneManager(SessionData data) {
        this.data = data;
    }

    public boolean hasPhone(Player player) {
        ItemStack hand = player.getInventory().getItemInMainHand();
        return hand != null && hand.getType() == org.bukkit.Material.PAPER
                && ItemUtil.hasLoreContaining(hand, "YUCECELL A.S.");
    }

    public int getBattery(Player player) {
        return data.battery.getOrDefault(player.getUniqueId(), 100);
    }

    public void setBattery(Player player, int value) {
        data.battery.put(player.getUniqueId(), Math.min(100, Math.max(0, value)));
    }

    public void addBattery(Player player, int amount) {
        int current = getBattery(player);
        setBattery(player, current + amount);
    }

    public void removeBattery(Player player, int amount) {
        int current = getBattery(player);
        setBattery(player, current - amount);
    }

    public boolean isCharging(Player player) {
        return data.charging.containsKey(player.getUniqueId());
    }

    public void startCharging(Player player) {
        data.charging.put(player.getUniqueId(), true);
    }

    public void stopCharging(Player player) {
        data.charging.remove(player.getUniqueId());
    }

    /** Telefon modelini ayarla (emerald cost hesabı) */
    public void setPhoneModel(Player player, String model) {
        int cost = switch (model) {
            case "lite" -> 10;
            case "basic" -> 7;
            case "v1" -> 5;
            case "pro" -> 3;
            default -> 10;
        };
        data.phoneCost.put(player.getUniqueId(), cost);
    }

    public int getCallCost(Player player) {
        return data.phoneCost.getOrDefault(player.getUniqueId(), 10);
    }

    public boolean isInCall(Player player) {
        return data.inCall.containsKey(player.getUniqueId());
    }

    public Player getCallPartner(Player player) {
        UUID partnerUUID = data.busyWith.get(player.getUniqueId());
        if (partnerUUID == null) return null;
        return org.bukkit.Bukkit.getPlayer(partnerUUID);
    }

    public void startCall(Player caller, Player receiver) {
        data.inCall.put(caller.getUniqueId(), true);
        data.inCall.put(receiver.getUniqueId(), true);
        data.busyWith.put(caller.getUniqueId(), receiver.getUniqueId());
        data.busyWith.put(receiver.getUniqueId(), caller.getUniqueId());
    }

    public void endCall(Player player) {
        UUID partner = data.busyWith.remove(player.getUniqueId());
        data.inCall.remove(player.getUniqueId());
        if (partner != null) {
            data.busyWith.remove(partner);
            data.inCall.remove(partner);
        }
    }

    /** 30 saniyede bir pil tüketimi */
    public void tickCallBattery(Player player) {
        if (!isInCall(player)) return;
        int cost = getCallCost(player);
        removeBattery(player, cost);
        if (getBattery(player) <= 0) {
            Player partner = getCallPartner(player);
            endCall(player);
            player.sendMessage(C.c(SessionData.YUCECELL_PREFIX + " &cBatarya bitti, gorusme kesildi!"));
            if (partner != null && partner.isOnline()) {
                partner.sendMessage(C.c(SessionData.YUCECELL_PREFIX + " &cKarsi tarafin bataryasi bitti."));
            }
        }
    }
}
