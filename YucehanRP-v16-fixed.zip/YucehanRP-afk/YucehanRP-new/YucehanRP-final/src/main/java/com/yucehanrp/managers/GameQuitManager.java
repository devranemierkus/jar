package com.yucehanrp.managers;

import com.yucehanrp.SessionData;
import com.yucehanrp.util.C;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.Player;

import java.util.UUID;

/**
 * /oyundancik komutunu ve DC temizliğini yönetir.
 */
public class GameQuitManager {

    private final SessionData data;
    private final InventoryManager invManager;
    private final GameHeadManager headManager;
    private final PvpSumoManager pvpSumo;
    private final MiniGamesManager miniGames;
    private final KatilKimManager katilKim;
    private final BedWarsManager bedWars;

    public GameQuitManager(SessionData data, InventoryManager invManager, GameHeadManager headManager,
                           PvpSumoManager pvpSumo, MiniGamesManager miniGames,
                           KatilKimManager katilKim, BedWarsManager bedWars) {
        this.data = data;
        this.invManager = invManager;
        this.headManager = headManager;
        this.pvpSumo = pvpSumo;
        this.miniGames = miniGames;
        this.katilKim = katilKim;
        this.bedWars = bedWars;
    }

    public Location spawnLoc() {
        return new Location(Bukkit.getWorld("world"), -15, -60, -8);
    }

    /**
     * Oyuncuyu aktif olduğu her oyundan çıkarır.
     * DC, /oyundancik, yetkili komutu için ortak mantık.
     */
    public void quitAllGames(Player player) {
        UUID uuid = player.getUniqueId();

        // PVP
        if (data.pvpMode.containsKey(uuid)) {
            data.pvpMode.remove(uuid);
            invManager.invGeriYukle(player);
            player.setGameMode(GameMode.ADVENTURE);
            player.teleport(spawnLoc());
            headManager.giveGameHead(player);
            return;
        }

        // SUMO
        if (data.sumoMode.containsKey(uuid)) {
            data.sumoMode.remove(uuid);
            invManager.invGeriYukle(player);
            player.setGameMode(GameMode.ADVENTURE);
            player.teleport(spawnLoc());
            headManager.giveGameHead(player);
            return;
        }

        // BW aktif oyuncu
        if (data.bwTeam.containsKey(uuid)) {
            String team = data.bwTeam.get(uuid);
            data.clearBwPlayer(uuid);
            invManager.invGeriYukle(player);
            player.setGameMode(GameMode.ADVENTURE);
            player.teleport(spawnLoc());
            headManager.giveGameHead(player);
            // Takım arkadaşlarına bildir
            for (UUID uid : data.bwTeam.keySet()) {
                if (team.equals(data.bwTeam.get(uid))) {
                    Player tp = Bukkit.getPlayer(uid);
                    if (tp != null)
                        tp.sendMessage(C.c("&c&l[BED WARS] &eTakim arkadasin &f" + player.getName() + " &esunucudan ayrildi!"));
                }
            }
            if (data.bwActive) bedWars.checkWinner();
            return;
        }

        // BW spectator
        if (data.bwSpec.containsKey(uuid)) {
            data.bwSpec.remove(uuid);
            invManager.invGeriYukle(player);
            player.setGameMode(GameMode.ADVENTURE);
            player.teleport(spawnLoc());
            headManager.giveGameHead(player);
            return;
        }

        // BW lobi
        if (data.bwInLobby.containsKey(uuid)) {
            bedWars.lobiCik(player);
            return;
        }

        // KatilKim spectator
        if (data.katilKimSpectators.contains(uuid)) {
            data.katilKimSpectators.remove(uuid);
            data.katilKimRole.remove(uuid);
            invManager.invGeriYukle(player);
            player.setGameMode(GameMode.ADVENTURE);
            player.teleport(spawnLoc());
            headManager.giveGameHead(player);
            return;
        }

        // KatilKim aktif oyuncu
        String kkRole = data.katilKimRole.get(uuid);
        if (kkRole != null && !kkRole.equals("lobi")) {
            invManager.invGeriYukle(player);
            data.clearKKPlayer(uuid);
            player.setGameMode(GameMode.ADVENTURE);
            player.teleport(spawnLoc());
            headManager.giveGameHead(player);
            if (data.katilKimActive) {
                if ("katil".equals(kkRole)) {
                    // Katil çıktı → masumlar kazandı
                    katilKim.broadcastToAll(C.c("&4[KATİL KİM] &eKatil oyundan çıktı! Masumlar kazandı!"));
                    katilKim.endGame("masum_katil_cikti");
                } else if ("serif".equals(kkRole)) {
                    // Şerif çıktı → katil kazandı (artık engel kalmadı)
                    katilKim.broadcastToAll(C.c("&4[KATİL KİM] &eŞerif oyundan çıktı! Katil serbest kaldı."));
                    katilKim.endGame("katil_serif_cikti");
                } else {
                    // Masum çıktı → kazanan kontrolü yap
                    katilKim.checkWinner();
                }
            }
            return;
        }

        // KatilKim lobi
        if ("lobi".equals(kkRole)) {
            katilKim.lobiCik(player);
            return;
        }

        // Mini oyunlar
        if (data.flappyActive.containsKey(uuid)) { miniGames.stopFlappy(player); return; }
        if (data.snakeActive.containsKey(uuid)) { miniGames.stopSnake(player); return; }
        if (data.targetActive.containsKey(uuid)) { miniGames.stopTarget(player); return; }
        if (data.simonActive.containsKey(uuid)) { miniGames.stopSimon(player); return; }
        if (data.reflexActive.containsKey(uuid)) { miniGames.stopReflex(player); return; }

        player.sendMessage(C.c("&c[SİSTEM] Zaten hiçbir oyunda değilsin."));
    }

    /**
     * Tüm oyuncuları oyundan çıkarır (admin komutu / sunucu durdurma)
     */
    public void evictAll() {
        // KK aktifse kimse kazanmadan bitir
        if (data.katilKimActive) {
            data.katilKimActive = false;
            for (UUID uid : new java.util.ArrayList<>(data.katilKimPlayers)) {
                Player p = Bukkit.getPlayer(uid);
                if (p != null) {
                    p.sendMessage(C.c("&4[KATİL KİM] &7Yetkili oyunu sonlandırdı. Lobiye gönderildiniz."));
                    invManager.invGeriYukle(p);
                    p.setGameMode(org.bukkit.GameMode.ADVENTURE);
                    p.teleport(spawnLoc());
                    headManager.giveGameHead(p);
                }
            }
            for (UUID uid : new java.util.ArrayList<>(data.katilKimSpectators)) {
                Player p = Bukkit.getPlayer(uid);
                if (p != null) {
                    invManager.invGeriYukle(p);
                    p.setGameMode(org.bukkit.GameMode.ADVENTURE);
                    p.teleport(spawnLoc());
                    headManager.giveGameHead(p);
                }
            }
        }
        // BW aktifse kimse kazanmadan bitir
        if (data.bwActive) {
            data.bwActive = false;
            for (UUID uid : new java.util.ArrayList<>(data.bwTeam.keySet())) {
                Player p = Bukkit.getPlayer(uid);
                if (p != null) {
                    p.sendMessage(C.c("&c[BED WARS] &7Yetkili oyunu sonlandırdı. Lobiye gönderildiniz."));
                    invManager.invGeriYukle(p);
                    p.setGameMode(org.bukkit.GameMode.ADVENTURE);
                    p.teleport(spawnLoc());
                    headManager.giveGameHead(p);
                }
            }
            for (UUID uid : new java.util.ArrayList<>(data.bwSpec.keySet())) {
                Player p = Bukkit.getPlayer(uid);
                if (p != null) {
                    invManager.invGeriYukle(p);
                    p.setGameMode(org.bukkit.GameMode.ADVENTURE);
                    p.teleport(spawnLoc());
                    headManager.giveGameHead(p);
                }
            }
        }
        // Geri kalan tüm oyuncuları çıkar
        for (Player p : Bukkit.getOnlinePlayers()) {
            quitAllGames(p);
        }
        data.bwLobbyQueue.clear();
        data.bwActive = false;
        data.bwCountdownActive = false;
        data.katilKimActive = false;
        data.katilKimLobbyCountdown = false;
        data.katilKimQueue.clear();
        data.katilKimPlayers.clear();
        data.katilKimSpectators.clear();
        data.katilKimRole.clear();
        data.bwTeam.clear();
        data.bwSpec.clear();
        data.bwInLobby.clear();
    }
}
