package com.yucehanrp.listeners;

import com.yucehanrp.SessionData;
import com.yucehanrp.managers.*;
import com.yucehanrp.util.C;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerLoginEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;

import java.util.UUID;
import java.time.LocalDate;
import java.time.ZoneId;

public class ConnectionListener implements Listener {

    private final Plugin plugin;
    private final SessionData data;
    private final InventoryManager invManager;
    private final GameHeadManager headManager;
    private final GameQuitManager quitManager;
    private final DcSaveManager dcSave;
    private final MarketManager market;

    public ConnectionListener(Plugin plugin, SessionData data, InventoryManager invManager,
                              GameHeadManager headManager, GameQuitManager quitManager,
                              DcSaveManager dcSave, MarketManager market) {
        this.plugin = plugin;
        this.data = data;
        this.invManager = invManager;
        this.headManager = headManager;
        this.quitManager = quitManager;
        this.dcSave = dcSave;
        this.market = market;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onLogin(PlayerLoginEvent event) {
        String ip = event.getAddress().getHostAddress();
        int count = data.ipCount.getOrDefault(ip, 0);
        if (count >= 2) {
            event.disallow(PlayerLoginEvent.Result.KICK_OTHER,
                    C.c("&c&lERİŞİM REDDEDİLDİ!\n&7Aynı IP üzerinden en fazla &e2 &7hesap sunucuya girebilir."));
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();
        String ip = player.getAddress() != null
                ? player.getAddress().getAddress().getHostAddress() : "unknown";

        data.ipCount.merge(ip, 1, Integer::sum);
        data.charging.remove(uuid);
        data.inCall.remove(uuid);
        data.busyWith.remove(uuid);
        data.hackMode.remove(uuid);
        data.battery.putIfAbsent(uuid, 100);
        data.afkLastActivity.put(uuid, System.currentTimeMillis());
        player.setGameMode(GameMode.ADVENTURE);

        // Playtime takibi — giriş zamanını kaydet
        data.playtimeJoinMs.put(uuid, System.currentTimeMillis());
        // Yeni gün ise bugünkü süreyi sıfırla
        String today = LocalDate.now(ZoneId.of("Europe/Istanbul")).toString();
        String lastDay = data.playtimeLastDay.getOrDefault(uuid, "");
        if (!today.equals(lastDay)) {
            data.playtimeTodayMs.put(uuid, 0L);
            data.playtimeLastDay.put(uuid, today);
        }

        // Giriş duyurusu — 3 saniye sonra at
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!player.isOnline()) return;
            player.sendMessage(C.c(""));
            player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
            player.sendMessage(C.c("  &e&l⚠ SUNUCU KURALI &e&l⚠"));
            player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
            player.sendMessage(C.c("  &7&l15 gün &r&7aktif olmayan oyuncular &c&lsiliniyor&7!"));
            player.sendMessage(C.c("  &7Günü kurtarmak için en az &a&l12 dakika &7oynamalısın."));
            player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
            player.sendMessage(C.c(""));
        }, 60L);

        // === Çevrimdışıyken satılan market ödemelerini iade et ===
        String pName = player.getName();
        if (data.marketPendingZumrut.containsKey(pName) && data.marketPendingZumrut.get(pName) > 0) {
            int z = data.marketPendingZumrut.remove(pName);
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (!player.isOnline()) return;
                int rem = z;
                while (rem > 0) { int s = Math.min(64,rem); player.getInventory().addItem(new org.bukkit.inventory.ItemStack(org.bukkit.Material.EMERALD,s)); rem-=s; }
                player.sendMessage(C.c("&a&l[MARKET] &7Çevrimdışıyken satışlardan &e" + z + " Zümrüt &7kazandın!"));
            }, 80L);
        }
        if (data.marketPendingElmas.containsKey(pName) && data.marketPendingElmas.get(pName) > 0) {
            int e = data.marketPendingElmas.remove(pName);
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (!player.isOnline()) return;
                int rem = e;
                while (rem > 0) { int s = Math.min(64,rem); player.getInventory().addItem(new org.bukkit.inventory.ItemStack(org.bukkit.Material.DIAMOND,s)); rem-=s; }
                player.sendMessage(C.c("&a&l[MARKET] &7Çevrimdışıyken satışlardan &b" + e + " Elmas &7kazandın!"));
            }, 80L);
        }

        // .sk: market.bekleyen.item — süresi dolan tezgahın itemi iade et
        if (data.marketBekleyenItem.containsKey(pName)) {
            org.bukkit.inventory.ItemStack bekItem = data.marketBekleyenItem.remove(pName);
            if (bekItem != null) {
                Bukkit.getScheduler().runTaskLater(plugin, () -> {
                    if (!player.isOnline()) return;
                    player.getInventory().addItem(bekItem);
                    player.sendMessage(C.c("&e&l[MARKET] &7Süresi dolan tezgahının itemi iade edildi!"));
                }, 80L);
            }
        }

        // 1) GZIP+BLOB dc_save iade
        if (dcSave.hasSave(uuid)) {
            DcSaveManager.SavedData saved = dcSave.load(uuid);
            dcSave.delete(uuid);
            if (saved != null) {
                Bukkit.getScheduler().runTaskLater(plugin, () -> {
                    if (!player.isOnline()) return;
                    player.getInventory().clear();
                    player.getInventory().setContents(saved.inventory);
                    if (saved.armor.length >= 4) {
                        player.getInventory().setHelmet(saved.armor[3]);
                        player.getInventory().setChestplate(saved.armor[2]);
                        player.getInventory().setLeggings(saved.armor[1]);
                        player.getInventory().setBoots(saved.armor[0]);
                    }
                    player.setGameMode(GameMode.ADVENTURE);
                    player.teleport(new Location(Bukkit.getWorld("world"), -15, -60, -8));
                    headManager.giveGameHead(player);
                    player.sendMessage(C.c("&a[DC-KAYIT] &7Envanterin DC sonrasi iade edildi!"));
                }, 20L);
                return;
            }
        }

        // 2) Crash recovery (disk)
        invManager.checkCrashRecovery(player);
        if (invManager.isInvSaved(player)) {
            data.clearKKPlayer(uuid);
            data.clearBwPlayer(uuid);
            data.pvpMode.remove(uuid);
            data.sumoMode.remove(uuid);
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (!player.isOnline()) return;
                invManager.invGeriYukle(player);
                player.setGameMode(GameMode.ADVENTURE);
                player.teleport(new Location(Bukkit.getWorld("world"), -15, -60, -8));
                headManager.giveGameHead(player);
            }, 20L);
            return;
        }

        // 3) Karsılama
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!player.isOnline()) return;
            player.sendMessage(C.c("&d&lKALYX &8> &bSelam &e" + player.getName()
                    + "&b! Sehre hos geldin. /rehber yazarak baslayabilirsin."));
        }, 40L);

        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!player.isOnline()) return;
            player.sendMessage(C.c(""));
            player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
            player.sendMessage(C.c(" &6&l🌟 YUCEHAN RP'YE HOS GELDINIZ!"));
            player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
            player.sendMessage(C.c("&a✔ &7Sunucumuz &e7/24 &7aciktir!"));
            player.sendMessage(C.c("&c⚠ &7Her zaman yetkili olmayabilir."));
            player.sendMessage(C.c("&b➡ &7Yardim icin: &e/rehber &7yazin!"));
            player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
            player.sendMessage(C.c(""));
            headManager.giveGameHead(player);
        }, 100L);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();
        String ip = player.getAddress() != null
                ? player.getAddress().getAddress().getHostAddress() : "unknown";

        int count = data.ipCount.getOrDefault(ip, 0);
        if (count > 0) data.ipCount.put(ip, count - 1);
        else data.ipCount.remove(ip);

        // Playtime takibi — çıkışta süreyi hesapla
        Long joinMs = data.playtimeJoinMs.remove(uuid);
        if (joinMs != null) {
            long sessionMs = System.currentTimeMillis() - joinMs;
            String today = LocalDate.now(ZoneId.of("Europe/Istanbul")).toString();
            String lastDay = data.playtimeLastDay.getOrDefault(uuid, "");
            if (!today.equals(lastDay)) {
                data.playtimeTodayMs.put(uuid, 0L);
                data.playtimeLastDay.put(uuid, today);
            }
            long todayMs = data.playtimeTodayMs.getOrDefault(uuid, 0L) + sessionMs;
            data.playtimeTodayMs.put(uuid, todayMs);
            // 12 dakika = 720000 ms — geçtiyse lastLogin güncelle
            if (todayMs >= 720_000L) {
                data.lastLoginDate.put(uuid, System.currentTimeMillis());
            }
        }

        // Normal DC: sunucu açıkken oyuncu çıktı → quitAllGames çağır (envanter iade + spawn)
        // DC dosyası sadece onDisable'da (stop/restart) yazılır
        quitManager.quitAllGames(player);

        // .sk: on quit → aktif market tezgahı varsa kaldır, item sakla
        String pName = player.getName();
        int ownerSlot = market.findOwnerSlot(pName);
        if (ownerSlot > 0) {
            org.bukkit.inventory.ItemStack mItem = data.marketItem.get(ownerSlot);
            if (mItem != null) {
                org.bukkit.inventory.ItemStack toStore = mItem.clone();
                toStore.setAmount(data.marketAmount.getOrDefault(ownerSlot, 1));
                data.marketBekleyenItem.put(pName, toStore);
            }
            market.clearSlot(ownerSlot);
            data.marketCooldown.put(uuid, System.currentTimeMillis());
        }
        // .sk: market kurma aşamasındayken çıkış — item beklet
        if (data.marketPendingItem.containsKey(uuid)) {
            data.marketBekleyenItem.put(pName, data.marketPendingItem.remove(uuid));
            data.marketWaitingPrice.remove(uuid);
            data.marketWaitingAmount.remove(uuid);
            data.marketPendingSlot.remove(uuid);
            data.marketPendingCurrency.remove(uuid);
            data.marketPendingAmount.remove(uuid);
        }
        // .sk: satın alma onayındayken çıkış = hayır
        data.marketBuyConfirm.remove(uuid);
        data.marketRemoveConfirm.remove(uuid);
    }

    // Oyuncu her zaman world spawn'da doğsun — yatak/anchor yok sayılır
    @EventHandler(priority = org.bukkit.event.EventPriority.HIGHEST)
    public void onRespawn(PlayerRespawnEvent event) {
        org.bukkit.World world = org.bukkit.Bukkit.getWorld("world");
        if (world == null) return;
        event.setRespawnLocation(world.getSpawnLocation());
    }
}
