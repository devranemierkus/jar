package com.yucehanrp.listeners;

import com.yucehanrp.SessionData;
import com.yucehanrp.managers.*;
import com.yucehanrp.util.C;
import com.yucehanrp.util.ItemUtil;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.UUID;

public class InventoryClickListener implements Listener {

    private final SessionData data;
    private final GamesMenuManager gamesMenu;
    private final PvpSumoManager pvpSumo;
    private final MiniGamesManager miniGames;
    private final KatilKimManager katilKim;
    private final BedWarsManager bedWars;
    private final GameHeadManager headManager;
    private final MarketManager market;
    private final MarketGUIManager marketGui;

    public InventoryClickListener(SessionData data, GamesMenuManager gamesMenu,
                                   PvpSumoManager pvpSumo, MiniGamesManager miniGames,
                                   KatilKimManager katilKim, BedWarsManager bedWars,
                                   GameHeadManager headManager, MarketManager market,
                                   MarketGUIManager marketGui) {
        this.data = data;
        this.gamesMenu = gamesMenu;
        this.pvpSumo = pvpSumo;
        this.miniGames = miniGames;
        this.katilKim = katilKim;
        this.bedWars = bedWars;
        this.headManager = headManager;
        this.market = market;
        this.marketGui = marketGui;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        UUID uuid = player.getUniqueId();
        String title = event.getView().getTitle();
        ItemStack clicked = event.getCurrentItem();
        String name = clicked != null ? ItemUtil.displayName(clicked) : "";

        // ─── OYUN KAFASI KORUMA ───────────────────────────────────────────────
        // .sk: number_key engelle
        if (event.getClick() == ClickType.NUMBER_KEY) {
            if (headManager.isGameHead(player.getInventory().getItem(0))) {
                event.setCancelled(true); return;
            }
        }
        // F tuşu (offhand swap) ile kafayı yan ele geçirmeyi engelle
        if (event.getClick() == ClickType.SWAP_OFFHAND) {
            if (headManager.isGameHead(clicked) || headManager.isGameHead(player.getInventory().getItem(0))) {
                event.setCancelled(true);
                player.sendActionBar(C.c("&c[OYUNLAR] Kafa tasinamaz!"));
                return;
            }
        }
        // .sk: tıklanan slot baş ise
        if (headManager.isGameHead(clicked)) {
            event.setCancelled(true);
            ItemStack cursor = event.getCursor();
            if (cursor != null && cursor.getType() != Material.AIR) {
                player.sendActionBar(C.c("&c[OYUNLAR] Oyunlarin yerine item koyamazsin!"));
                event.getView().setCursor(null);
                player.getInventory().addItem(cursor);
            }
            return;
        }
        // .sk: cursor'da baş ise
        if (headManager.isGameHead(event.getCursor())) {
            event.setCancelled(true);
            event.getView().setCursor(null);
            player.getInventory().setItem(0, headManager.makeGameHead());
            player.sendActionBar(C.c("&c[OYUNLAR] Kafa tasinamaz! Hep slot 1'de."));
            return;
        }

        // ─── BW ZIRH KİLİDİ — deri zırh tamamen kilitli ──────────────
        if (data.bwTeam.containsKey(uuid)) {
            int si = event.getRawSlot();
            // Zırh slotları: 36=boots, 37=leggings, 38=chestplate, 39=helmet
            if (si == 36 || si == 37 || si == 38 || si == 39) {
                event.setCancelled(true); return;
            }
            // Number key ile zırh slotuna swap engelle
            if (event.getClick() == ClickType.NUMBER_KEY) {
                int hotbar = event.getHotbarButton();
                ItemStack hotbarItem = player.getInventory().getItem(hotbar);
                if (hotbarItem != null) {
                    String t = hotbarItem.getType().name();
                    if (t.endsWith("_HELMET") || t.endsWith("_CHESTPLATE") ||
                        t.endsWith("_LEGGINGS") || t.endsWith("_BOOTS")) {
                        event.setCancelled(true); return;
                    }
                }
            }
            // Shift+click ile zırh taşımayı engelle
            if (event.getClick().isShiftClick() && clicked != null) {
                String t = clicked.getType().name();
                if (t.endsWith("_HELMET") || t.endsWith("_CHESTPLATE") ||
                    t.endsWith("_LEGGINGS") || t.endsWith("_BOOTS")) {
                    event.setCancelled(true); return;
                }
            }
            // Offhand swap engelle (F tuşu)
            if (event.getClick() == ClickType.SWAP_OFFHAND && clicked != null) {
                String t = clicked.getType().name();
                if (t.endsWith("_HELMET") || t.endsWith("_CHESTPLATE") ||
                    t.endsWith("_LEGGINGS") || t.endsWith("_BOOTS")) {
                    event.setCancelled(true); return;
                }
            }
        }

        // ─── OYUNLAR MENÜSÜ ───────────────────────────────────────────────────
        if (title.equals(C.c("Oyunlar Menusu"))) {
            event.setCancelled(true);
            if      (name.equals(C.c("&c&lPVP")))          { player.closeInventory(); gamesMenu.openPvpMenu(player); }
            else if (name.equals(C.c("&a&lSUMO")))         { player.closeInventory(); gamesMenu.openSumoMenu(player); }
            else if (name.equals(C.c("&b&lFLAPPY BIRD")))  { player.closeInventory(); miniGames.startFlappy(player); }
            else if (name.equals(C.c("&2&lYILAN")))        { player.closeInventory(); miniGames.startSnake(player); }
            else if (name.equals(C.c("&c&lHEDEF VURMA")) || name.equals(C.c("&e&lRENK EŞLEŞTİR")))  { player.closeInventory(); miniGames.startTarget(player); }
            else if (name.equals(C.c("&d&lSİMON SAYS")))   { player.closeInventory(); miniGames.startSimon(player); }
            else if (name.equals(C.c("&6&lHIZLI TIKLAMA"))){ player.closeInventory(); miniGames.startReflex(player); }
            else if (name.equals(C.c("&4&lKATİL KİM")))    { player.closeInventory(); katilKim.lobiGir(player); }
            else if (name.equals(C.c("&c&l🛏 BED WARS")))  { player.closeInventory(); bedWars.bwLobiGir(player); }
            return;
        }

        // ─── PVP / SUMO MENÜ ──────────────────────────────────────────────────
        if (title.equals(C.c("PVP Alani"))) {
            event.setCancelled(true);
            if (name.equals(C.c("&a&lGIR!")))      { player.closeInventory(); pvpSumo.startPvp(player); }
            else if (name.equals(C.c("&c&lGERI DON"))) { player.closeInventory(); gamesMenu.openGamesMenu(player); }
            return;
        }
        if (title.equals(C.c("Sumo Alani"))) {
            event.setCancelled(true);
            if (name.equals(C.c("&a&lGIR!")))      { player.closeInventory(); pvpSumo.startSumo(player); }
            else if (name.equals(C.c("&c&lGERI DON"))) { player.closeInventory(); gamesMenu.openGamesMenu(player); }
            return;
        }

        // ─── FLAPPY BIRD (.sk: slot 31 = zipla, slot 35 = çıkış) ─────────────
        if (title.equals("Flappy Bird")) {
            event.setCancelled(true);
            if (!data.flappyActive.containsKey(uuid)) return;
            int slot = event.getRawSlot();
            if (slot == 31) miniGames.flappyJump(player);
            else if (slot == 35) miniGames.stopFlappy(player);
            return;
        }

        // ─── YILAN (.sk: yön butonları) ───────────────────────────────────────
        if (title.equals("Yilan Oyunu")) {
            event.setCancelled(true);
            if (!data.snakeActive.containsKey(uuid)) return;
            String dir = data.snakeDir.getOrDefault(uuid, "r");
            if      (name.equals(C.c("&e< SOL"))    && !dir.equals("r")) data.snakeDir.put(uuid, "l");
            else if (name.equals(C.c("&ev ASAGI"))  && !dir.equals("u")) data.snakeDir.put(uuid, "d");
            else if (name.equals(C.c("&e^ YUKARI")) && !dir.equals("d")) data.snakeDir.put(uuid, "u");
            else if (name.equals(C.c("&e> SAG"))    && !dir.equals("l")) data.snakeDir.put(uuid, "r");
            else if (name.equals(C.c("&c&lCIKIS"))) miniGames.stopSnake(player);
            return;
        }

        // ─── RENK EŞLEŞTİRME ─────────────────────────────────────────────────
        if (title.equals(C.c("Renk Eslestirme"))) {
            event.setCancelled(true);
            if (!data.targetActive.containsKey(uuid)) return;
            int rawSlot = event.getRawSlot();
            if (rawSlot == 53) { miniGames.stopTarget(player); return; }
            if (rawSlot >= 45) return;
            int dogruSlot = data.targetTick.getOrDefault(uuid, -1);
            // Doğru slot = "&a&lTIKLA!" isimli item
            ItemStack clickedItem = event.getCurrentItem();
            String clickedName = clickedItem != null ? ItemUtil.displayName(clickedItem) : "";
            if (clickedName.equals(C.c("&a&lTIKLA!"))) miniGames.hitTarget(player);
            else if (rawSlot != dogruSlot) miniGames.hitTargetWrong(player);
            return;
        }

        // ─── REFLEX ───────────────────────────────────────────────────────────
        if (title.equals(C.c("Reflex Oyunu"))) {
            event.setCancelled(true);
            if (!data.reflexActive.containsKey(uuid)) return;
            if (event.getRawSlot() == 53) miniGames.stopReflex(player);
            else if (name.equals(C.c("&a&lTIKLA!"))) miniGames.reflexClick(player);
            return;
        }

        // ─── MARKET ANA GUI ───────────────────────────────────────────────────
        if (title.equals(C.c("&6&l🏪 OYUNCU MARKETİ"))) {
            event.setCancelled(true);
            int slot = event.getRawSlot();
            int n = market.guiSlotToN(slot);
            if (n > 0 && data.marketItem.containsKey(n)) {
                String owner = data.marketOwner.getOrDefault(n, "");
                if (owner.equals(player.getName())) {
                    // Kendi tezgahı — kaldır
                    player.closeInventory();
                    ItemStack mi = data.marketItem.get(n);
                    String mname = mi != null ? ItemUtil.displayName(mi) : "?";
                    data.marketBuyConfirm.remove(uuid);
                    player.sendMessage(C.c(""));
                    player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                    player.sendMessage(C.c(" &c&l🗑 TEZGAH KALDIRMA ONAYI"));
                    player.sendMessage(C.c("  &7Ürün: &f" + mname));
                    player.sendMessage(C.c("  &cTezgahını kaldırmak istiyor musun?"));
                    player.sendMessage(C.c("  &a&levet &8veya &c&lhayır &7yaz!"));
                    player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                    data.marketBuyConfirm.put(uuid, -n); // negatif = kaldır
                } else {
                    // Satın al onayı
                    player.closeInventory();
                    int price = data.marketPrice.getOrDefault(n, 0);
                    String currency = data.marketCurrency.getOrDefault(n, "zumrut");
                    ItemStack mi = data.marketItem.get(n);
                    player.sendMessage(C.c(""));
                    player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                    player.sendMessage(C.c(" &6&l🛒 SATIN ALMA ONAYI"));
                    player.sendMessage(C.c("  &7Ürün: &f" + (mi != null ? ItemUtil.displayName(mi) : "?")));
                    player.sendMessage(C.c("  &7Fiyat: &f" + price + " " + ("elmas".equals(currency) ? "&bElmas" : "&eZümrüt")));
                    player.sendMessage(C.c("  &7Satıcı: &f" + owner));
                    player.sendMessage(C.c("  &aSatin almak istiyor musun?"));
                    player.sendMessage(C.c("  &a&levet &8veya &c&lhayır &7yaz! &8(İptal: /marketiptal)"));
                    player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                    data.marketBuyConfirm.put(uuid, n);
                }
            } else if (name.equals(C.c("&a&lTEZGAH KUR"))) {
                player.closeInventory();
                Long cdStart = data.marketCooldown.get(uuid);
                if (cdStart != null && System.currentTimeMillis() - cdStart < 3 * 60 * 1000L) {
                    long kalan = (3 * 60 * 1000L - (System.currentTimeMillis() - cdStart)) / 1000;
                    player.sendMessage(C.c("&c&l[MARKET] &7Tezgah kurma cooldownu! &eKalan: " + (kalan/60) + "dk " + (kalan%60) + "sn"));
                    return;
                }
                Bukkit.getScheduler().runTask((org.bukkit.plugin.Plugin)Bukkit.getPluginManager().getPlugin("YucehanRP"),
                        () -> marketGui.openTezgahKur(player));
            } else if (name.equals(C.c("&c&lTEZGAHIMI KALDIR"))) {
                player.closeInventory();
                int ownerSlot = market.findOwnerSlot(player.getName());
                if (ownerSlot > 0) {
                    ItemStack mi = data.marketItem.get(ownerSlot);
                    if (mi != null) player.getInventory().addItem(mi.clone());
                    market.clearSlot(ownerSlot);
                    player.sendMessage(C.c("&a[MARKET] &7Tezgahın kaldırıldı, item iade edildi."));
                    player.sendMessage(C.c("&c&l[MARKET] &73 dakika tezgah kurma cooldownu başladı!"));
                    data.marketCooldown.put(uuid, System.currentTimeMillis());
                } else {
                    player.sendMessage(C.c("&c[MARKET] &7Aktif tezgahın yok."));
                }
            } else if (name.equals(C.c("&c&lKAPAT"))) {
                player.closeInventory();
            }
            return;
        }

        // ─── TEZGAH KUR GUI ───────────────────────────────────────────────────
        if (title.equals(C.c("&e&l🛒 TEZGAH KUR"))) {
            event.setCancelled(true);
            int rawSlot = event.getRawSlot();
            if (rawSlot >= 27) return; // envanter slotları — engelle
            if (name.equals(C.c("&6&lSAT"))) {
                String cur = data.marketPendingCurrency.getOrDefault(uuid, "zumrut");
                // Boş slot bul
                int freeSlot = market.findFreeSlot();
                if (freeSlot == 0) {
                    player.sendActionBar(C.c("&c[MARKET] &7Tüm tezgahlar dolu!"));
                    return;
                }
                // Sadece slot 2 (index 1) kontrol et
                ItemStack satilikItem = null;
                ItemStack slotIki = player.getInventory().getItem(1);
                if (slotIki != null && slotIki.getType() != Material.AIR
                        && !ItemUtil.hasLoreContaining(slotIki, "KOPYALANAMAZ")
                        && !ItemUtil.hasLoreContaining(slotIki, "YUCECELL A.S.")
                        && !headManager.isGameHead(slotIki)) {
                    satilikItem = slotIki;
                }
                if (satilikItem == null) {
                    player.sendActionBar(C.c("&c[MARKET] &7Satılacak eşyayı envanterinin 2. slotuna koy!"));
                    return;
                }
                // Slot rezerve et
                market.reserveSlot(freeSlot);
                data.marketPendingSlot.put(uuid, freeSlot);
                data.marketPendingItem.put(uuid, satilikItem.clone());
                data.marketWaitingAmount.put(uuid, true);
                player.closeInventory();
                player.sendMessage(C.c(""));
                player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                player.sendMessage(C.c(" &6&l📦 KAÇ ADET SATIYORSUN?"));
                player.sendMessage(C.c("  &7Ürün: &f" + ItemUtil.displayName(satilikItem) + " &8(Toplam: " + satilikItem.getAmount() + ")"));
                player.sendMessage(C.c("  &aChat'e sadece bir sayı yaz! &8(1-" + satilikItem.getAmount() + ")"));
                player.sendMessage(C.c("  &cİptal: &e/marketiptal"));
                player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
            } else if (name.equals(C.c("&b&lPARA: ELMAS"))) {
                data.marketPendingCurrency.put(uuid, "zumrut");
                marketGui.refreshTezgahKurGui(player);
            } else if (name.equals(C.c("&e&lPARA: ZÜMRÜT"))) {
                data.marketPendingCurrency.put(uuid, "elmas");
                marketGui.refreshTezgahKurGui(player);
            } else if (name.equals(C.c("&c&lİPTAL"))) {
                Integer ps = data.marketPendingSlot.remove(uuid);
                if (ps != null) data.marketReserved.remove(ps);
                data.marketPendingItem.remove(uuid);
                data.marketPendingCurrency.remove(uuid);
                player.closeInventory();
                Bukkit.getScheduler().runTask((org.bukkit.plugin.Plugin)Bukkit.getPluginManager().getPlugin("YucehanRP"),
                        () -> marketGui.openMarket(player));
            }
            return;
        }

        // ─── BED WARS MAĞAZA (.sk: on inventory click bwmagaza) ──────────────
        if (title.contains("BED WARS MAĞAZA")) {
            event.setCancelled(true);
            if (!data.bwTeam.containsKey(uuid)) return;
            int demir = countItem(player, Material.IRON_INGOT);
            int altin = countItem(player, Material.GOLD_INGOT);
            int elmas = countItem(player, Material.DIAMOND);
            // shopItem plain isim kullanıyor — ChatColor strip ederek karşılaştır
            String plainName = ChatColor.stripColor(name);
            switch (plainName) {
                case "Taş Kılıç"       -> bwSatin(player, Material.STONE_SWORD,     1,  8,  "demir", demir, altin, elmas);
                case "Demir Kılıç"     -> bwSatin(player, Material.IRON_SWORD,      1,  15, "demir", demir, altin, elmas);
                case "Elmas Kılıç"     -> bwSatin(player, Material.DIAMOND_SWORD,   1,  10, "altin", demir, altin, elmas);
                case "Balta"           -> bwSatin(player, Material.WOODEN_AXE,      1,  6,  "demir", demir, altin, elmas);
                case "Deri Zırh Seti"  -> bwSatinZirh(player, 12, demir);
                case "Demir Göğüslük"  -> bwSatin(player, Material.IRON_CHESTPLATE, 1,  8,  "altin", demir, altin, elmas);
                case "Demir Kask"      -> bwSatin(player, Material.IRON_HELMET,     1,  5,  "altin", demir, altin, elmas);
                case "Yün Blok x16"    -> bwSatin(player, Material.WHITE_WOOL,      16, 6,  "demir", demir, altin, elmas);
                case "Taş x16"         -> bwSatin(player, Material.SANDSTONE,       16, 9,  "demir", demir, altin, elmas);
                case "Tahta x16"       -> bwSatin(player, Material.OAK_PLANKS,      16, 5,  "demir", demir, altin, elmas);
                case "Cam x8"          -> bwSatin(player, Material.GLASS,            8, 4,  "demir", demir, altin, elmas);
                case "Obsidyen x2"     -> bwSatin(player, Material.OBSIDIAN,         2, 10, "altin", demir, altin, elmas);
                case "Bow"             -> bwSatin(player, Material.BOW,              1, 9,  "demir", demir, altin, elmas);
                case "Ok x16"          -> bwSatin(player, Material.ARROW,           16, 4,  "demir", demir, altin, elmas);
                case "İp"              -> bwSatin(player, Material.FISHING_ROD,      1, 8,  "demir", demir, altin, elmas);
                case "Altın Elma"      -> bwSatin(player, Material.GOLDEN_APPLE,     1, 5,  "altin", demir, altin, elmas);
                case "Ender İnci"      -> bwSatin(player, Material.ENDER_PEARL,      1, 4,  "altin", demir, altin, elmas);
                case "Ekmek x5"        -> bwSatin(player, Material.BREAD,            5, 4,  "demir", demir, altin, elmas);
                case "Biftek x3"       -> bwSatin(player, Material.COOKED_BEEF,      3, 6,  "demir", demir, altin, elmas);
                case "KAPAT"           -> player.closeInventory();
                default -> {} // boş slot veya fill
            }
            return;
        }
    }

    // ─── BW satın alma yardımcısı ─────────────────────────────────────────────
    private void bwSatin(Player player, Material give, int amount, int cost, String currency,
                         int demir, int altin, int elmas) {
        int sahip = "demir".equals(currency) ? demir : "altin".equals(currency) ? altin : elmas;
        Material mat = "demir".equals(currency) ? Material.IRON_INGOT
                      : "altin".equals(currency) ? Material.GOLD_INGOT : Material.DIAMOND;
        if (sahip >= cost) {
            removeExact(player, mat, cost);
            player.getInventory().addItem(new ItemStack(give, amount));
            player.sendActionBar(C.c("&a✔ " + ItemUtil.make(give,"").getType().name().replace("_"," ") + " alındı!"));
        } else {
            String paraIsim = "demir".equals(currency) ? "Demir" : "altin".equals(currency) ? "Altın" : "Elmas";
            player.sendActionBar(C.c("&c✘ Yetersiz " + paraIsim + "! &7Lazım: &e" + cost + " &7/ Sahip: &c" + sahip));
        }
    }

    private void bwSatinZirh(Player player, int cost, int demir) {
        if (demir >= cost) {
            removeExact(player, Material.IRON_INGOT, cost);
            player.getInventory().addItem(new ItemStack(Material.LEATHER_HELMET));
            player.getInventory().addItem(new ItemStack(Material.LEATHER_CHESTPLATE));
            player.getInventory().addItem(new ItemStack(Material.LEATHER_LEGGINGS));
            player.getInventory().addItem(new ItemStack(Material.LEATHER_BOOTS));
            player.sendActionBar(C.c("&a✔ Deri Zırh Seti alındı!"));
        } else {
            player.sendActionBar(C.c("&c✘ Yetersiz Demir! &7Lazım: &e" + cost + " &7/ Sahip: &c" + demir));
        }
    }

    private int countItem(Player player, Material mat) {
        int count = 0;
        for (ItemStack item : player.getInventory().getContents()) {
            if (item != null && item.getType() == mat) count += item.getAmount();
        }
        return count;
    }

    private void removeExact(Player player, Material mat, int amount) {
        int remaining = amount;
        ItemStack[] contents = player.getInventory().getContents();
        for (int i = 0; i < contents.length && remaining > 0; i++) {
            ItemStack it = contents[i];
            if (it != null && it.getType() == mat) {
                int take = Math.min(remaining, it.getAmount());
                it.setAmount(it.getAmount() - take);
                remaining -= take;
                if (it.getAmount() <= 0) contents[i] = null;
            }
        }
        player.getInventory().setContents(contents);
    }

    // ─── INVENTORY CLOSE ──────────────────────────────────────────────────────
    @EventHandler
    public void onClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player player)) return;
        UUID uuid = player.getUniqueId();
        String title = event.getView().getTitle();

        if (title.equals(C.c("Oyunlar Menusu"))) headManager.giveGameHead(player);
        if (title.equals(C.c("PVP Alani")))      headManager.giveGameHead(player);
        if (title.equals(C.c("Sumo Alani")))     headManager.giveGameHead(player);

        if (title.equals(C.c("Renk Eslestirme")) && data.targetActive.containsKey(uuid)) {
            miniGames.stopTarget(player);
        }
        if (title.equals(C.c("Reflex Oyunu")) && data.reflexActive.containsKey(uuid)) {
            if (!data.reflexTransition.containsKey(uuid)) miniGames.stopReflex(player);
        }

        // Tezgah kur GUI kapanınca temizlik (.sk: on inventory close "TEZGAH KUR")
        if (title.equals(C.c("&e&l🛒 TEZGAH KUR"))) {
            if (!data.marketWaitingPrice.containsKey(uuid) && !data.marketWaitingAmount.containsKey(uuid)) {
                Integer ps = data.marketPendingSlot.remove(uuid);
                if (ps != null) data.marketReserved.remove(ps);
                data.marketPendingItem.remove(uuid);
                data.marketPendingCurrency.remove(uuid);
            }
        }
    }

    // ─── F TUŞU SWAP ENGELİ — oyun kafası yan ele geçemesin ──────────────────
    @EventHandler
    public void onSwapHand(PlayerSwapHandItemsEvent event) {
        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();
        // Oyun kafası ana elde veya yan elde ise engelle
        if (headManager.isGameHead(event.getMainHandItem()) ||
            headManager.isGameHead(event.getOffHandItem())) {
            event.setCancelled(true);
            player.sendActionBar(C.c("&c[OYUNLAR] Kafa tasinamaz!"));
            return;
        }
        // BW oyuncusu zırhı F ile yan ele alamasın
        if (data.bwTeam.containsKey(uuid)) {
            ItemStack main = event.getMainHandItem();
            ItemStack off = event.getOffHandItem();
            String mt = main != null ? main.getType().name() : "";
            String ot = off != null ? off.getType().name() : "";
            if (mt.endsWith("_HELMET") || mt.endsWith("_CHESTPLATE") || mt.endsWith("_LEGGINGS") || mt.endsWith("_BOOTS") ||
                ot.endsWith("_HELMET") || ot.endsWith("_CHESTPLATE") || ot.endsWith("_LEGGINGS") || ot.endsWith("_BOOTS")) {
                event.setCancelled(true);
            }
        }
    }
}
