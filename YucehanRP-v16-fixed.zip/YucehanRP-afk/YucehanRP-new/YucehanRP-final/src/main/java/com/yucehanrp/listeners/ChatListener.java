package com.yucehanrp.listeners;

import com.yucehanrp.SessionData;
import com.yucehanrp.managers.*;
import com.yucehanrp.util.C;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.inventory.ItemStack;

import java.util.UUID;

/**
 * Chat sistemi — .sk on chat ile birebir:
 * 1) BW oyuncusu → BW chat ayrımı
 * 2) Market chat komutları
 * 3) Hakaret engelleyici (normalize + kelime sınırı)
 * 4) Reklam engelleyici
 * 5) KatilKim oyun içi engeli
 * 6) Telefon konuşması yönlendirmesi
 * 7) Hack modu şifre girişi
 * 8) KatilKim alan chat
 * 9) Normal chat (BW chat ayrımı dahil)
 */
public class ChatListener implements Listener {

    private static final String[] KUFORLER = {
        "amk","orospu","orosb","yarrak","yarag","amina","anani","ibne",
        "kahpe","fahise","gavat","itogl","aptal","salak","gerize","gerizeka",
        "malherif","pust","oruspu","sikko","siktir","pezevenk","haspa",
        "kaltak","dalyarak","manyak","dangalak","dingil","gerizekal",
        "serefsiz","alcak","pislik","sik","bok"
    };

    private static final String[] REKLAM_PATTERN = {
        "http://","https://","www.",".com",".net",".org",".xyz",".gg/",
        ".me/",".io/",".tk",".top",".ru",".de",".tr",".co","discord.gg",
        "discord.com/invite","bit.ly","tinyurl","youtu.be","youtube.com",
        "twitch.tv","t.me/","telegram","whatsapp",".info",".site",".web",".link"
    };

    private static final String[] REKLAM_WHITELIST = {
        "discord.gg/ushe","link-hub.net/3711","ig.me/j/abyf5","tiktok.me/group/zsy"
    };

    private final SessionData data;
    private final MarketManager market;
    private final MarketGUIManager marketGui;
    private final PhoneManager phone;

    public ChatListener(SessionData data, MarketManager market, MarketGUIManager marketGui, PhoneManager phone) {
        this.data = data;
        this.market = market;
        this.marketGui = marketGui;
        this.phone = phone;
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onChat(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();
        String msg = event.getMessage();

        // AFK aktivite güncelle
        data.afkLastActivity.put(uuid, System.currentTimeMillis());

        // ════════════════════════════════════════════════════════════════
        // BW OYUNCUSU → BW CHAT AYIRIMI (.sk'da ilk blok)
        // ════════════════════════════════════════════════════════════════
        boolean bwOyuncuMu = data.bwTeam.containsKey(uuid)
                || data.bwInLobby.containsKey(uuid)
                || data.bwSpec.containsKey(uuid);

        if (bwOyuncuMu) {
            event.setCancelled(true);
            // BW küfür kontrolü
            if (containsKufur(msg)) {
                player.sendMessage(C.c("&c&l[BW-CHAT] &7Hakaret yasaktır!"));
                int count = data.bwHakaretCount.merge(uuid, 1, Integer::sum);
                if (count >= 3) {
                    data.bwHakaretCount.put(uuid, 0);
                    // tempmute requires LiteBans/EssentialsX
                    Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "mute " + player.getName());
                }
                return;
            }
            // Mesajı doğru gruba yönlendir
            if (data.bwTeam.containsKey(uuid)) {
                String takim = data.bwTeam.get(uuid);
                for (UUID uid : data.bwTeam.keySet()) {
                    Player lp = Bukkit.getPlayer(uid);
                    if (lp != null) lp.sendMessage(C.c(bwTakimIsim(takim) + " &8› &f" + player.getName() + "&7: " + msg));
                }
                for (UUID uid : data.bwSpec.keySet()) {
                    Player lp = Bukkit.getPlayer(uid);
                    if (lp != null) lp.sendMessage(C.c("&8[SPEC] " + bwTakimIsim(takim) + "&8› &7" + player.getName() + ": " + msg));
                }
                return;
            }
            if (data.bwInLobby.containsKey(uuid)) {
                for (UUID uid : data.bwLobbyQueue) {
                    Player lp = Bukkit.getPlayer(uid);
                    if (lp != null) lp.sendMessage(C.c("&e&l[BW-LOBİ] &7" + player.getName() + "&8: &f" + msg));
                }
                return;
            }
            if (data.bwSpec.containsKey(uuid)) {
                for (UUID uid : data.bwTeam.keySet()) {
                    Player lp = Bukkit.getPlayer(uid);
                    if (lp != null) lp.sendMessage(C.c("&8[SPEC] &7" + player.getName() + ": " + msg));
                }
                for (UUID uid : data.bwSpec.keySet()) {
                    Player lp = Bukkit.getPlayer(uid);
                    if (lp != null) lp.sendMessage(C.c("&8[SPEC] &7" + player.getName() + ": " + msg));
                }
                return;
            }
            return;
        }

        // ════════════════════════════════════════════════════════════════
        // MARKET: adet bekleniyor
        // ════════════════════════════════════════════════════════════════
        if (data.marketWaitingAmount.containsKey(uuid)) {
            event.setCancelled(true);
            try {
                int amount = Integer.parseInt(msg.trim());
                ItemStack item = data.marketPendingItem.get(uuid);
                if (item == null) { player.sendMessage(C.c("&c[MARKET] Hata.")); return; }
                // Toplam envanterdeki miktarı say
                int totalInInv = 0;
                for (ItemStack s : player.getInventory().getContents()) {
                    if (s == null || s.getType() != item.getType()) continue;
                    boolean nameOk = true;
                    if (item.hasItemMeta() && item.getItemMeta().hasDisplayName()) {
                        nameOk = s.hasItemMeta() && s.getItemMeta().hasDisplayName()
                                && s.getItemMeta().getDisplayName().equals(item.getItemMeta().getDisplayName());
                    }
                    if (nameOk) totalInInv += s.getAmount();
                }
                if (amount < 1 || amount > totalInInv) {
                    player.sendMessage(C.c("&c[MARKET] &71 ile &e" + totalInInv + " &7arasında sayı gir! (Sahip olduğun kadar)"));
                    return;
                }
                data.marketWaitingAmount.remove(uuid);
                data.marketPendingAmount.put(uuid, amount);
                data.marketWaitingPrice.put(uuid, true);
                String paraIsim = "elmas".equals(data.marketPendingCurrency.getOrDefault(uuid,"zumrut")) ? "Elmas" : "Zümrüt";
                player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                player.sendMessage(C.c(" &6&l💬 FİYAT BELİRLE"));
                player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                player.sendMessage(C.c("  &7Adet: &f" + amount));
                player.sendMessage(C.c("  &7Toplam fiyat kaç &e" + paraIsim + " &7olsun?"));
                player.sendMessage(C.c("  &aChat'e sadece bir sayı yaz! &8(Örn: &e100&8)"));
                player.sendMessage(C.c("  &cİptal için: &e/marketiptal"));
            } catch (NumberFormatException e) {
                player.sendMessage(C.c("&c[MARKET] &7Lütfen sadece bir &esayı &7yaz! Örnek: &e50"));
                player.sendMessage(C.c("&c[MARKET] &7İptal için &e/marketiptal &7yaz."));
            }
            return;
        }

        // ════════════════════════════════════════════════════════════════
        // MARKET: fiyat bekleniyor
        // ════════════════════════════════════════════════════════════════
        if (data.marketWaitingPrice.containsKey(uuid)) {
            event.setCancelled(true);
            try {
                int price = Integer.parseInt(msg.trim());
                if (price <= 0) { player.sendMessage(C.c("&c[MARKET] &7Fiyat &c0'dan büyük &7olmalı!")); return; }
                String para = data.marketPendingCurrency.getOrDefault(uuid, "zumrut");
                if (!"elmas".equals(para) && price < 13) {
                    player.sendMessage(C.c("&c[MARKET] &7Zümrüt fiyatı en az &e13 Zümrüt &7olmalı!")); return;
                }
                if (price > 64000) { player.sendMessage(C.c("&c[MARKET] &7Maksimum fiyat &e64.000&7!")); return; }

                data.marketWaitingPrice.remove(uuid);
                int slot = data.marketPendingSlot.getOrDefault(uuid, 0);
                ItemStack item = data.marketPendingItem.get(uuid);
                int amount = data.marketPendingAmount.getOrDefault(uuid, 1);

                if (slot == 0 || item == null) {
                    player.sendMessage(C.c("&c[MARKET] Hata: item veya slot kayıp."));
                    return;
                }

                // Envanterden item ara — sadece slot 1 değil, tüm envanteri tara
                int totalAmount = 0;
                for (ItemStack stack : player.getInventory().getContents()) {
                    if (stack != null && stack.getType() == item.getType()
                            && stack.getType() != org.bukkit.Material.AIR) {
                        // İsim/lore eşleşmesi
                        boolean nameMatch = true;
                        if (item.hasItemMeta() && item.getItemMeta().hasDisplayName()) {
                            nameMatch = stack.hasItemMeta() && stack.getItemMeta().hasDisplayName()
                                    && stack.getItemMeta().getDisplayName().equals(item.getItemMeta().getDisplayName());
                        }
                        if (nameMatch) totalAmount += stack.getAmount();
                    }
                }
                if (totalAmount < amount) {
                    player.sendMessage(C.c("&c[MARKET] &7Yeterli item yok! &7Gerekli: &e" + amount + " &7/ Sahip: &c" + totalAmount));
                    market.clearSlot(slot);
                    data.marketPendingItem.remove(uuid);
                    data.marketPendingSlot.remove(uuid);
                    data.marketPendingAmount.remove(uuid);
                    return;
                }
                // Envanterden amount kadar al
                int remaining = amount;
                ItemStack[] contents = player.getInventory().getContents();
                ItemStack toSell = null;
                for (int i = 0; i < contents.length && remaining > 0; i++) {
                    ItemStack stack = contents[i];
                    if (stack == null || stack.getType() != item.getType()) continue;
                    boolean nameMatch = true;
                    if (item.hasItemMeta() && item.getItemMeta().hasDisplayName()) {
                        nameMatch = stack.hasItemMeta() && stack.getItemMeta().hasDisplayName()
                                && stack.getItemMeta().getDisplayName().equals(item.getItemMeta().getDisplayName());
                    }
                    if (!nameMatch) continue;
                    if (toSell == null) { toSell = stack.clone(); toSell.setAmount(0); }
                    int take = Math.min(stack.getAmount(), remaining);
                    remaining -= take;
                    stack.setAmount(stack.getAmount() - take);
                    if (stack.getAmount() <= 0) contents[i] = null;
                }
                player.getInventory().setContents(contents);
                if (toSell == null) toSell = item.clone();
                toSell.setAmount(amount);

                data.marketItem.put(slot, toSell);
                data.marketAmount.put(slot, amount);
                data.marketPrice.put(slot, price);
                data.marketOwner.put(slot, player.getName());
                data.marketTime.put(slot, System.currentTimeMillis());
                data.marketCurrency.put(slot, para);
                data.marketReserved.remove(slot);

                data.marketPendingItem.remove(uuid);
                data.marketPendingSlot.remove(uuid);
                data.marketPendingAmount.remove(uuid);
                data.marketPendingCurrency.remove(uuid);

                String itemIsim = toSell.hasItemMeta() && toSell.getItemMeta().hasDisplayName()
                        ? toSell.getItemMeta().getDisplayName() : toSell.getType().name();
                String paraIsim = "elmas".equals(para) ? "Elmas" : "Zümrüt";
                player.sendMessage(C.c(""));
                player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                player.sendMessage(C.c(" &a&l✓ TEZGAH BAŞARIYLA KURULDU!"));
                player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                player.sendMessage(C.c("  &7Ürün: &f" + itemIsim + " &8x" + amount));
                player.sendMessage(C.c("  &7Fiyat: &e" + price + " " + paraIsim));
                player.sendMessage(C.c("  &7Süre: &c10 dakika"));
                player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_PLAYER_LEVELUP, 0.5f, 1f);
                Bukkit.broadcastMessage(C.c("&6&l[MARKET] &e" + player.getName() + " &7tezgah kurdu: &f" + itemIsim + " &8→ &e" + price + " " + paraIsim));
            } catch (NumberFormatException e) {
                player.sendMessage(C.c("&c[MARKET] &7Lütfen sadece bir &esayı &7yaz! Örnek: &e10"));
                player.sendMessage(C.c("&c[MARKET] &7İptal için &e/marketiptal &7yaz."));
            }
            return;
        }

        // ════════════════════════════════════════════════════════════════
        // MARKET: tezgah kaldırma onayı
        // ════════════════════════════════════════════════════════════════
        if (data.marketRemoveConfirm.containsKey(uuid)) {
            event.setCancelled(true);
            String lower = msg.toLowerCase().trim();
            if ("evet".equals(lower)) {
                data.marketRemoveConfirm.remove(uuid);
                doMarketKaldir(player);
            } else if ("hayir".equals(lower) || "hayır".equals(lower)) {
                data.marketRemoveConfirm.remove(uuid);
                player.sendMessage(C.c("&c&l[MARKET] &7Tezgah kaldırma iptal edildi."));
            } else {
                player.sendMessage(C.c("&c&l[MARKET] &7Sadece &aevet &7veya &chayır &7yaz!"));
            }
            return;
        }

        // ════════════════════════════════════════════════════════════════
        // MARKET: satın alma onayı
        // ════════════════════════════════════════════════════════════════
        if (data.marketBuyConfirm.containsKey(uuid)) {
            event.setCancelled(true);
            String lower = msg.toLowerCase().trim();
            int confirmVal = data.marketBuyConfirm.get(uuid);
            if ("evet".equals(lower)) {
                data.marketBuyConfirm.remove(uuid);
                if (confirmVal < 0) {
                    // Kaldır onayı
                    int kaldirSlot = -confirmVal;
                    ItemStack mi = data.marketItem.get(kaldirSlot);
                    if (mi != null) player.getInventory().addItem(mi.clone());
                    market.clearSlot(kaldirSlot);
                    data.marketCooldown.put(uuid, System.currentTimeMillis());
                    player.sendMessage(C.c("&a[MARKET] &7Tezgahın kaldırıldı, item iade edildi."));
                    player.sendMessage(C.c("&c&l[MARKET] &73 dakika tezgah kurma cooldownu başladı!"));
                } else {
                    completePurchase(player, confirmVal);
                }
            } else if ("hayir".equals(lower) || "hayır".equals(lower)) {
                data.marketBuyConfirm.remove(uuid);
                player.sendMessage(C.c("&c&l[MARKET] &7İşlem iptal edildi."));
            } else {
                player.sendMessage(C.c("&c&l[MARKET] &7Sadece &aevet &7veya &chayır &7yaz! &8(İptal: /marketiptal)"));
            }
            return;
        }

        // ════════════════════════════════════════════════════════════════
        // HAKARETENGELLEYİCİ — .sk tam kopya (normalize + kelime sınırı)
        // ════════════════════════════════════════════════════════════════
        String normalized = normalize(msg);
        if (containsKufurNorm(normalized)) {
            event.setCancelled(true);
            player.sendMessage(C.c("&c&l[CHAT] &7Hakaret ve küfür yasaktır! Lütfen kurallara uy."));
            int count = data.hakaretCount.merge(uuid, 1, Integer::sum);
            if (count >= 3) {
                data.hakaretCount.put(uuid, 0);
                // tempmute requires LiteBans/EssentialsX
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "mute " + player.getName());
                Bukkit.broadcastMessage(C.c("&c&l[MOD] &e" + player.getName() + " &7hakaret nedeniyle &c5 dakika &7susturuldu!"));
            }
            return;
        }

        // ════════════════════════════════════════════════════════════════
        // REKLAM ENGELLEYİCİ — .sk tam kopya
        // ════════════════════════════════════════════════════════════════
        String msgLower = msg.toLowerCase();
        String msgNoSpace = msgLower.replace(" ", "");
        if (isReklam(msgLower, msgNoSpace)) {
            event.setCancelled(true);
            player.sendMessage(C.c("&c&l[CHAT] &7Reklam ve link paylaşımı yasaktır!"));
            int count = data.reklamCount.merge(uuid, 1, Integer::sum);
            if (count >= 2) {
                data.reklamCount.put(uuid, 0);
                // tempmute requires LiteBans/EssentialsX
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "mute " + player.getName());
                Bukkit.broadcastMessage(C.c("&c&l[MOD] &e" + player.getName() + " &7reklam nedeniyle &c10 dakika &7susturuldu!"));
            }
            return;
        }

        // ════════════════════════════════════════════════════════════════
        // KATİL KİM oyun içi chat engeli
        // ════════════════════════════════════════════════════════════════
        String kkRole = data.katilKimRole.get(uuid);
        if ("katil".equals(kkRole) || "serif".equals(kkRole) || "masum".equals(kkRole)) {
            event.setCancelled(true);
            player.sendActionBar(C.c("&4[KATİL KİM] &cOyun sırasında yazamazsın! /oyundancik ile çık."));
            return;
        }
        if (data.katilKimSpectators.contains(uuid)) {
            event.setCancelled(true);
            player.sendActionBar(C.c("&8[KATİL KİM] &7İzleyici olarak yazamazsın! /oyundancik ile çık."));
            return;
        }

        // ════════════════════════════════════════════════════════════════
        // TELEFON KONUŞMASI
        // ════════════════════════════════════════════════════════════════
        if (phone.isInCall(player)) {
            event.setCancelled(true);
            if (containsKufur(msg)) {
                player.sendMessage(C.c(SessionData.YUCECELL_PREFIX + " &cGörüşmede hakaret yasaktır!"));
                return;
            }
            Player partner = phone.getCallPartner(player);
            player.sendMessage(C.c("&b[TEL] " + player.getName() + ": &f" + msg));
            if (partner != null && partner.isOnline())
                partner.sendMessage(C.c("&b[TEL] " + player.getName() + ": &f" + msg));
            return;
        }

        // ════════════════════════════════════════════════════════════════
        // HACK MODU ŞİFRE GİRİŞİ
        // ════════════════════════════════════════════════════════════════
        if (data.hackMode.containsKey(uuid)) {
            event.setCancelled(true);
            String input = msg;
            String correct = data.hackPassword.getOrDefault(uuid, "");
            data.hackMode.remove(uuid);
            data.hackPassword.remove(uuid);
            player.sendMessage(C.c("&b&lYUCECELL &8> &7Bypass ediliyor..."));
            Bukkit.getScheduler().runTaskLater(
                    Bukkit.getPluginManager().getPlugin("YucehanRP"), () -> {
                        if (!player.isOnline()) return;
                        if (input.equals(correct)) {
                            if (Math.random() < 0.15) {
                                player.getInventory().addItem(new ItemStack(Material.DIAMOND));
                                Bukkit.broadcastMessage(C.c("&4&l[SİBER] &eBilinmeyen hacker sızdı!"));
                            } else {
                                player.getInventory().setItemInMainHand(null);
                                player.sendMessage(C.c("&4&lBASKIN! &cPolis PC'ye el koydu!"));
                            }
                        } else {
                            player.getInventory().setItemInMainHand(null);
                            player.sendMessage(C.c("&cYanlış şifre! PC kilitlendi."));
                        }
                    }, 60L);
            return;
        }

        // ════════════════════════════════════════════════════════════════
        // KATİL KİM LOBİ CHAT — tamamen kapalı
        // ════════════════════════════════════════════════════════════════
        if ("lobi".equals(kkRole)) {
            event.setCancelled(true);
            player.sendActionBar(C.c("&4[KATİL KİM] &cLobide chat kapalıdır! /oyundancik ile çık."));
            return;
        }

        // ════════════════════════════════════════════════════════════════
        // NORMAL CHAT — .sk chat ayrımı (KK alan içi vs dışı)
        // ════════════════════════════════════════════════════════════════
        event.setCancelled(true);
        double px = player.getLocation().getX();
        double pz = player.getLocation().getZ();
        boolean inKKArea = px >= -240 && px <= -145 && pz >= 10000057 && pz <= 10000168;

        if (inKKArea) {
            for (Player lp : Bukkit.getOnlinePlayers()) {
                double lx = lp.getLocation().getX();
                double lz = lp.getLocation().getZ();
                boolean lpInArea = lx >= -240 && lx <= -145 && lz >= 10000057 && lz <= 10000168;
                if (lpInArea || "lobi".equals(data.katilKimRole.get(lp.getUniqueId()))) {
                    lp.sendMessage(C.c("&8[KATİL-ALAN] &e" + player.getName() + "&7: &f" + msg));
                }
            }
        } else {
            for (Player lp : Bukkit.getOnlinePlayers()) {
                double lx = lp.getLocation().getX();
                double lz = lp.getLocation().getZ();
                boolean lpInArea = lx >= -240 && lx <= -145 && lz >= 10000057 && lz <= 10000168;
                boolean kkSpecOrLobi = data.katilKimSpectators.contains(lp.getUniqueId())
                        || "lobi".equals(data.katilKimRole.get(lp.getUniqueId()));
                if (!lpInArea && !kkSpecOrLobi) {
                    lp.sendMessage(player.getName() + ": " + msg);
                }
            }
        }
    }

    // ─── Normalize — .sk ile birebir adımlar ────────────────────────────────
    private String normalize(String input) {
        String s = input.toLowerCase();
        s = s.replace("ı","i").replace("ğ","g").replace("ü","u")
              .replace("ş","s").replace("ö","o").replace("ç","c")
              .replace("â","a").replace("î","i").replace("û","u")
              .replace("ä","a").replace("é","e").replace("è","e")
              .replace("ë","e").replace("ï","i").replace("ô","o")
              .replace("ù","u");
        // Kiril
        s = s.replace("а","a").replace("е","e").replace("о","o")
              .replace("с","c").replace("і","i").replace("ѕ","s");
        // L33t speak
        s = s.replace("0","o").replace("1","i").replace("2","z")
              .replace("3","e").replace("4","a").replace("5","s")
              .replace("6","g").replace("7","t").replace("8","b")
              .replace("9","g").replace("@","a").replace("$","s")
              .replace("!","i").replace("+","t").replace("€","e");
        // Noktalama temizle (boşluk koru)
        s = s.replaceAll("[.,\\-_*/:;?'`()\\[\\]{}<>|\\\\]","");
        // Tekrar eden harfler (orrr → or)
        for (char c = 'a'; c <= 'z'; c++) {
            String cc = String.valueOf(c);
            while (s.contains(cc+cc+cc)) s = s.replace(cc+cc+cc, cc+cc);
            s = s.replace(cc+cc, cc+"");
        }
        return s;
    }

    private boolean containsKufurNorm(String normalized) {
        String padded = " " + normalized + " ";
        String nospace = normalized.replace(" ", "");
        for (String k : KUFORLER) {
            // Kelime olarak geçiyor mu?
            if (padded.contains(" " + k + " ")) return true;
            // Kelime başında mı? (ör: "amkevladı", "orospuçocuk")
            if (nospace.contains(k)) return true;
        }
        return false;
    }

    private boolean containsKufur(String raw) {
        return containsKufurNorm(normalize(raw));
    }

    private boolean isReklam(String lower, String noSpace) {
        for (String wl : REKLAM_WHITELIST) {
            if (lower.contains(wl)) return false;
        }
        for (String p : REKLAM_PATTERN) {
            if (lower.contains(p) || noSpace.contains(p)) return true;
        }
        if (lower.contains("mc.") || lower.contains("play.") || lower.contains("join.")) return true;
        return false;
    }

    private String bwTakimIsim(String team) {
        return switch (team) {
            case "kirmizi" -> "&c&lKIRMIZI";
            case "mavi"    -> "&9&lMAVİ";
            case "sari"    -> "&e&lSARI";
            case "yesil"   -> "&a&lYEŞİL";
            default        -> "&f?";
        };
    }

    // ─── Market tezgah kaldır ─────────────────────────────────────────────
    private void doMarketKaldir(Player player) {
        UUID uuid = player.getUniqueId();
        int ownerSlot = market.findOwnerSlot(player.getName());
        if (ownerSlot > 0) {
            ItemStack item = data.marketItem.get(ownerSlot);
            if (item != null) {
                ItemStack give = item.clone();
                give.setAmount(data.marketAmount.getOrDefault(ownerSlot, 1));
                player.getInventory().addItem(give);
            }
            market.clearSlot(ownerSlot);
            data.marketCooldown.put(uuid, System.currentTimeMillis());
            player.sendMessage(C.c("&e&l[MARKET] &7Tezgahın kaldırıldı! İtemin iade edildi."));
            player.sendMessage(C.c("&c&l[MARKET] &73 dakika tezgah kurma cooldownu başladı!"));
            player.playSound(player.getLocation(), org.bukkit.Sound.BLOCK_NOTE_BLOCK_BASS, 0.5f, 0.8f);
        } else {
            player.sendMessage(C.c("&c[MARKET] Aktif tezgahın yok."));
        }
    }

    // ─── Market satın alma tamamla ────────────────────────────────────────
    private void completePurchase(Player buyer, int slot) {
        if (!data.marketItem.containsKey(slot)) {
            buyer.sendMessage(C.c("&c&l[MARKET] &7Bu tezgah artık boş!"));
            return;
        }
        if (player_name(data.marketOwner.getOrDefault(slot,"")).equals(buyer.getName())) {
            buyer.sendMessage(C.c("&c&l[MARKET] &7Kendi tezgahından alamazsın!"));
            return;
        }
        String currency = data.marketCurrency.getOrDefault(slot, "zumrut");
        int price = data.marketPrice.getOrDefault(slot, 0);
        Material payMat = "elmas".equals(currency) ? Material.DIAMOND : Material.EMERALD;
        int has = countItem(buyer, payMat);
        if (has < price) {
            buyer.sendMessage(C.c("&c&l[MARKET] &7Yeterli " + ("elmas".equals(currency)?"Elmas":"Zümrüt") + " yok! Gerekli: &e" + price));
            return;
        }
        removeItems(buyer, payMat, price);

        ItemStack item = data.marketItem.get(slot).clone();
        item.setAmount(data.marketAmount.getOrDefault(slot, 1));
        buyer.getInventory().addItem(item);

        String ownerName = data.marketOwner.getOrDefault(slot, "");
        Player owner = Bukkit.getPlayerExact(ownerName);
        if (owner != null && owner.isOnline()) {
            ItemStack pay = new ItemStack(payMat, price);
            owner.getInventory().addItem(pay);
            owner.sendMessage(C.c("&a&l[MARKET] &7Tezgahından biri satın aldı! &f+" + price + " &e" + ("elmas".equals(currency)?"Elmas":"Zümrüt") + " &7kazandın."));
            owner.sendMessage(C.c("&c&l[MARKET] &73 dakika tezgah kurma cooldownu başladı!"));
            owner.playSound(owner.getLocation(), org.bukkit.Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.8f, 1.5f);
        } else {
            // Çevrimdışı ödeme beklet
            if ("elmas".equals(currency))
                data.marketPendingElmas.merge(ownerName, price, Integer::sum);
            else
                data.marketPendingZumrut.merge(ownerName, price, Integer::sum);
        }

        data.marketCooldown.put(Bukkit.getOfflinePlayer(ownerName).getUniqueId(), System.currentTimeMillis());
        String itemIsim = item.hasItemMeta() && item.getItemMeta().hasDisplayName()
                ? item.getItemMeta().getDisplayName() : item.getType().name();
        market.clearSlot(slot);

        buyer.sendMessage(C.c(""));
        buyer.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
        buyer.sendMessage(C.c(" &a&l✓ SATIN ALINDI!"));
        buyer.sendMessage(C.c("  &7Ürün: &f" + itemIsim));
        buyer.sendMessage(C.c("  &7Ödenen: &e" + price + " " + ("elmas".equals(currency)?"Elmas":"Zümrüt")));
        buyer.sendMessage(C.c("  &7Satıcı: &f" + ownerName));
        buyer.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
        buyer.playSound(buyer.getLocation(), org.bukkit.Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.7f, 2f);
        Bukkit.broadcastMessage(C.c("&6&l[MARKET] &f" + itemIsim + " &7satıldı! Alıcı: &e" + buyer.getName()));
    }

    private String player_name(String s) { return s; }

    private int countItem(Player p, Material mat) {
        int count = 0;
        for (ItemStack s : p.getInventory().getContents())
            if (s != null && s.getType() == mat) count += s.getAmount();
        return count;
    }

    private void removeItems(Player player, Material mat, int amount) {
        ItemStack[] contents = player.getInventory().getContents();
        int rem = amount;
        for (int i = 0; i < contents.length && rem > 0; i++) {
            ItemStack s = contents[i];
            if (s != null && s.getType() == mat) {
                int take = Math.min(s.getAmount(), rem);
                s.setAmount(s.getAmount() - take);
                rem -= take;
                if (s.getAmount() <= 0) player.getInventory().setItem(i, null);
            }
        }
    }
}
