package com.yucehanrp.util;

import org.bukkit.ChatColor;

import java.util.ArrayList;
import java.util.List;

public class C {

    /** & kodlarini §'ye çevirir */
    public static String c(String s) {
        if (s == null) return "";
        return ChatColor.translateAlternateColorCodes('&', s);
    }

    /** Lore stringini || ile böler ve her satırı renklendirir */
    public static List<String> lore(String raw) {
        List<String> lines = new ArrayList<>();
        if (raw == null || raw.isEmpty()) return lines;
        for (String line : raw.split("\\|\\|")) {
            lines.add(c(line));
        }
        return lines;
    }

    /** Renk kodlarini kaldirir */
    public static String strip(String s) {
        return ChatColor.stripColor(c(s));
    }
}
