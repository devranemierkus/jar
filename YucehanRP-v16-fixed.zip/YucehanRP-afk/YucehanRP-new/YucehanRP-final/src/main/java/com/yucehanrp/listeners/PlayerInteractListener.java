package com.yucehanrp.listeners;

import com.yucehanrp.SessionData;
import com.yucehanrp.managers.*;
import com.yucehanrp.util.C;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.event.player.*;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class PlayerInteractListener implements Listener {

    private final SessionData data;
    private final GameHeadManager headManager;
    private final GamesMenuManager gamesMenu;
    private final MiniGamesManager miniGames;
    private final InventoryManager invManager;
    private final Map<UUID, Boolean> wasOnGround = new HashMap<>();
    private final Map<UUID, Boolean> kkSpecBoundaryCooldown = new HashMap<>();

    public PlayerInteractListener(SessionData data, GameHeadManager headManager,
                                   GamesMenuManager gamesMenu, MiniGamesManager miniGames,
                                   InventoryManager invManager) {
        this.data = data;
        this.headManager = headManager;
        this.gamesMenu = gamesMenu;
        this.miniGames = miniGames;
        this.invManager = invManager;
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        // .sk: on right click → guvenlikKontrol("sag")
        if (event.getAction() == org.bukkit.event.block.Action.RIGHT_CLICK_AIR
                || event.getAction() == org.bukkit.event.block.Action.RIGHT_CLICK_BLOCK) {
            guvenlikKontrol(player, "sag");
        }
        if (event.getItem() != null && headManager.isGameHead(event.getItem())) {
            if (event.getAction() == org.bukkit.event.block.Action.RIGHT_CLICK_AIR
                    || event.getAction() == org.bukkit.event.block.Action.RIGHT_CLICK_BLOCK) {
                event.setCancelled(true);
                gamesMenu.openGamesMenu(player);
            }
        }
    }

    // PlayerJumpEvent yok, PlayerMoveEvent ile zıplama tespiti
    @EventHandler
    public void onMove(PlayerMoveEvent event) {
        if (!event.hasChangedPosition()) return;

        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();

        // AFK aktivite güncelle
        data.afkLastActivity.put(uuid, System.currentTimeMillis());

        // Yasak bölge: end pearl bug alanı — giren herkesi öldür
        {
            double kx = player.getLocation().getX();
            double ky = player.getLocation().getY();
            double kz = player.getLocation().getZ();
            if (kx >= -147 && kx <= 36 && ky >= 19 && ky <= 20 && kz >= 10000003 && kz <= 10000147) {
                player.damage(9999);
                return;
            }
        }

        // SUMO: Y < -61 ise düştü — damage event gelmese bile yakala
        if (data.sumoMode.containsKey(uuid) && event.hasChangedPosition()) {
            if (player.getLocation().getY() < -61) {
                data.sumoMode.remove(uuid);
                org.bukkit.plugin.Plugin pl = org.bukkit.Bukkit.getPluginManager().getPlugin("YucehanRP");
                org.bukkit.Bukkit.getScheduler().runTaskLater(pl, () -> {
                    if (!player.isOnline()) return;
                    invManager.invGeriYukle(player);
                    player.setGameMode(org.bukkit.GameMode.ADVENTURE);
                    player.setHealth(20);
                    player.setFoodLevel(20);
                    player.teleport(new org.bukkit.Location(org.bukkit.Bukkit.getWorld("world"), -15, -60, -8));
                    headManager.giveGameHead(player);
                    player.sendMessage(com.yucehanrp.util.C.c("&a&l[SUMO] &7Platformdan düştün! Spawn'a gönderildin."));
                }, 1L);
                return;
            }
        }

        boolean onGround = player.isOnGround();
        boolean prevOnGround = wasOnGround.getOrDefault(uuid, true);

        if (!onGround && prevOnGround) {
            if (data.simonActive.containsKey(uuid) && "ZIPLA".equals(data.simonExpected.get(uuid))) {
                miniGames.simonAction(player, "ZIPLA");
            }
        }
        wasOnGround.put(uuid, onGround);

        // Simon HAREKET
        if (data.simonActive.containsKey(uuid) && "HAREKET".equals(data.simonExpected.get(uuid))) {
            miniGames.simonAction(player, "HAREKET");
        }

        // KK spectator alan sınırı
        if (data.katilKimSpectators.contains(uuid)) {
            if (!kkSpecBoundaryCooldown.getOrDefault(uuid, false)) {
                double sx = player.getLocation().getX();
                double sz = player.getLocation().getZ();
                if (sx < -242 || sx > -143 || sz < 10000055 || sz > 10000170) {
                    kkSpecBoundaryCooldown.put(uuid, true);
                    player.teleport(new org.bukkit.Location(
                        org.bukkit.Bukkit.getWorld("world"), -192, -20, 10000112));
                    player.sendActionBar(org.bukkit.ChatColor.translateAlternateColorCodes('&',
                        "&c[KATİL KİM] &7Spectator olarak alan dışına çıkamazsın!"));
                    org.bukkit.Bukkit.getScheduler().runTaskLater(
                        org.bukkit.Bukkit.getPluginManager().getPlugin("YucehanRP"),
                        () -> kkSpecBoundaryCooldown.remove(uuid), 40L);
                }
            }
        }

        // BW spec oyuncusu alan dışına çıkamasın
        if (data.bwSpec.containsKey(uuid)) {
            double px = player.getLocation().getX();
            double pz = player.getLocation().getZ();
            if (px < -148 || px > 37 || pz < 10000002 || pz > 10000148) {
                event.setCancelled(true);
                player.sendActionBar(C.c("&c[BW] Spectator olarak alan dışına çıkamazsın!"));
            }
        }
    }

    @EventHandler
    public void onSneak(PlayerToggleSneakEvent event) {
        if (!event.isSneaking()) return;
        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();
        if (data.simonActive.containsKey(uuid) && data.simonExpected.containsKey(uuid)) {
            // Eğildi: beklenen EGIL ise doğru, değilse yanlış
            miniGames.simonAction(player, "EGIL");
        }
    }

    @EventHandler
    public void onInteractLeft(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();
        if (event.getAction() == org.bukkit.event.block.Action.LEFT_CLICK_AIR
                || event.getAction() == org.bukkit.event.block.Action.LEFT_CLICK_BLOCK) {
            // .sk: on left click → guvenlik + simon VUR
            guvenlikKontrol(player, "sol");
            if (data.simonActive.containsKey(uuid) && data.simonExpected.containsKey(uuid)) {
                // Vurdu: beklenen VUR ise doğru, değilse yanlış
                miniGames.simonAction(player, "VUR");
            }
        }
    }

    // ─── Anti-cheat: profesyonelGuvenlikKontrol — .sk ile birebir ──────────
    private void guvenlikKontrol(org.bukkit.entity.Player p, String tur) {
        String uuid = p.getUniqueId().toString();
        String key = tur + ":" + uuid;
        float yaw   = p.getLocation().getYaw();
        float pitch = p.getLocation().getPitch();
        long now    = System.currentTimeMillis();

        Float prevYaw   = data.guvenlikYaw.get(key);
        Float prevPitch = data.guvenlikPitch.get(key);
        Long  prevZaman = data.guvenlikZaman.get(key);

        if (prevYaw != null) {
            float farkYaw   = Math.abs(yaw   - prevYaw);
            float farkPitch = Math.abs(pitch - prevPitch);
            long  zamanMs   = prevZaman != null ? (now - prevZaman) : 999;

            if (farkYaw < 0.0001f && farkPitch < 0.0001f) {
                // Robotik (kafa hiç hareket etmiyor)
                int rob = data.guvenlikRobotik.merge(key, 1, Integer::sum);
                if (rob >= 150) {
                    resetGuvenlik(key);
                    Bukkit.getBanList(org.bukkit.BanList.Type.NAME).addBan(
                        p.getName(), "GUVENLiK: Robotik Islem", null, "YucehanRP-AntiCheat");
                    p.kickPlayer(org.bukkit.ChatColor.translateAlternateColorCodes('&',
                        "&4&lGÜVENLİK: &fRobotik İşlem Tespit Edildi!"));
                    Bukkit.broadcastMessage(org.bukkit.ChatColor.translateAlternateColorCodes('&',
                        "&4&l[ANTİ-CHEAT] &e" + p.getName() + " &7robotik işlem nedeniyle &cbanlandı."));
                }
            } else if (zamanMs < 10) {
                // Çok hızlı tıklama
                int hiz = data.guvenlikHiz.merge(key, 1, Integer::sum);
                if (hiz >= 100) {
                    resetGuvenlik(key);
                    Bukkit.getBanList(org.bukkit.BanList.Type.NAME).addBan(
                        p.getName(), "GUVENLiK: Auto Clicker", null, "YucehanRP-AntiCheat");
                    p.kickPlayer(org.bukkit.ChatColor.translateAlternateColorCodes('&',
                        "&4&lGÜVENLİK: &fAuto Clicker Tespit Edildi!"));
                    Bukkit.broadcastMessage(org.bukkit.ChatColor.translateAlternateColorCodes('&',
                        "&4&l[ANTİ-CHEAT] &e" + p.getName() + " &7auto clicker nedeniyle &cbanlandı."));
                }
            } else {
                data.guvenlikRobotik.put(key, 0);
                data.guvenlikHiz.put(key, 0);
            }
        }
        data.guvenlikYaw.put(key, yaw);
        data.guvenlikPitch.put(key, pitch);
        data.guvenlikZaman.put(key, now);
    }

    private void resetGuvenlik(String key) {
        data.guvenlikYaw.remove(key);
        data.guvenlikPitch.remove(key);
        data.guvenlikZaman.remove(key);
        data.guvenlikRobotik.put(key, 0);
        data.guvenlikHiz.put(key, 0);
    }

    @EventHandler
    public void onCommand(PlayerCommandPreprocessEvent event) {
        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();
        String cmd = event.getMessage().toLowerCase();
        String cmdNorm = cmd.replace("\u0131","i").replace("\u015f","s")
                           .replace("\u00f6","o").replace("\u00fc","u")
                           .replace("\u011f","g").replace("\u00e7","c");

        // /warp meslekseç → rehber akışı: ışınla + 3 saniye bekle + mesajlar
        if (cmdNorm.startsWith("/warp mesleksec")) {
            if ("BASLADI".equals(data.guideState.get(uuid)) && Boolean.TRUE.equals(data.guideAccepted.get(uuid))) {
                // Hemen meslek meydanı mesajı
                player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                player.sendMessage(C.c("&d&lKALYX &8› &fBurası &e&lMeslek Meydanı&f!"));
                player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                // 3 saniye sonra dondurmacıya tp + mesajlar
                Bukkit.getScheduler().runTaskLater(Bukkit.getPluginManager().getPlugin("YucehanRP"), () -> {
                    if (!player.isOnline()) return;
                    player.teleport(new org.bukkit.Location(Bukkit.getWorld("world"), 98.83, -60.0, 9999925.52));
                    data.guideState.put(uuid, "KULAH");
                    player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                    player.sendMessage(C.c("&d&lKALYX &8› &7Burada &e&lbirden fazla meslek &7var!"));
                    player.sendMessage(C.c("&d&lKALYX &8› &7Ama önce &b&lDondurmacılık &7ile başlayalım!"));
                    player.sendMessage(C.c("&d&lKALYX &8› &e&l⚑ 1. GÖREV &8— &fMalzeme Topla"));
                    player.sendMessage(C.c("&d&lKALYX &8› &7Tezgahtan &b&l7 adet Dondurma Külahı &7al!"));
                    player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                }, 60L); // 3 saniye
            }
            return;
        }

        // .sk: on command "/back" → BW de yasak
        if (cmd.startsWith("/back")) {
            if (data.bwTeam.containsKey(uuid) || data.bwInLobby.containsKey(uuid)) {
                event.setCancelled(true);
                player.sendActionBar(C.c("&c[BW] Oyun sırasında /back kullanamazsın!"));
                return;
            }
        }

        // .sk: BW oyuncusu sadece /bwmagaza ve /oyundancik kullanabilir
        if (data.bwTeam.containsKey(uuid)) {
            if (!cmd.startsWith("/bwmagaza") && !cmd.startsWith("/oyundancik")) {
                event.setCancelled(true);
                player.sendActionBar(C.c("&c[OYUN] Oyun sırasında komut kullanılamaz! /oyundancik ile çık."));
                return;
            }
        }

        // .sk: BW lobi/spec de de komut engeli
        if (data.bwInLobby.containsKey(uuid) || data.bwSpec.containsKey(uuid)) {
            if (!cmd.startsWith("/oyundancik") && !cmd.startsWith("/bwmagaza")) {
                event.setCancelled(true);
                player.sendActionBar(C.c("&c[BW] Bu komut BW lobisinde kullanılamaz! /oyundancik ile çık."));
                return;
            }
        }

        // .sk: KatilKim oyun içi komut engeli — TÜM roller (lobi dahil)
        String kkRole = data.katilKimRole.get(uuid);
        boolean kkSpec = data.katilKimSpectators.contains(uuid);
        if (kkRole != null || kkSpec) {
            if (!cmd.startsWith("/oyundancik")) {
                event.setCancelled(true);
                player.sendActionBar(C.c("&c[KATİL KİM] Oyun sırasında komut kullanılamaz! /oyundancik ile çık."));
                return;
            }
        }

        // .sk: /sit, /lay, /crawl, /bellyflop, /spin BW/KK de yasak
        if (cmd.startsWith("/sit") || cmd.startsWith("/lay") || cmd.startsWith("/crawl")
                || cmd.startsWith("/bellyflop") || cmd.startsWith("/spin")) {
            if (data.bwTeam.containsKey(uuid) || data.bwInLobby.containsKey(uuid)
                    || data.katilKimRole.containsKey(uuid)) {
                event.setCancelled(true);
                player.sendActionBar(C.c("&c[OYUN] Bu komut oyun sırasında yasak!"));
            }
        }
    }

    // Tüm oyuncular için yatak uyuma engeli (BW alanında)
    @EventHandler
    public void onRightClickBlock(org.bukkit.event.player.PlayerInteractEvent bedEvent) {
        if (bedEvent.getClickedBlock() == null) return;
        if (bedEvent.getAction() != org.bukkit.event.block.Action.RIGHT_CLICK_BLOCK) return;
        org.bukkit.Material bt = bedEvent.getClickedBlock().getType();
        if (!bt.name().endsWith("_BED")) return;
        // BW alanında olan herkes yatağa yatamasın
        double bx = bedEvent.getClickedBlock().getX();
        double bz = bedEvent.getClickedBlock().getZ();
        if (bx >= -148 && bx <= 37 && bz >= 10000002 && bz <= 10000148) {
            bedEvent.setCancelled(true);
        }
    }

    @EventHandler
    public void onRightClickPlayer(PlayerInteractAtEntityEvent event) {
        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();
        double x = player.getLocation().getX();
        double z = player.getLocation().getZ();
        if (x >= -148 && x <= 37 && z >= 10000002 && z <= 10000148) {
            event.setCancelled(true);
            return;
        }
        if (data.bwTeam.containsKey(uuid) || data.bwInLobby.containsKey(uuid)) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onBedEnter(org.bukkit.event.player.PlayerBedEnterEvent event) {
        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();
        // BW alanında yatma tamamen yasak
        if (data.bwTeam.containsKey(uuid) || data.bwInLobby.containsKey(uuid)
                || data.bwSpec.containsKey(uuid)) {
            event.setCancelled(true);
        }
        // KK alanında yatma yasak
        if (data.katilKimRole.containsKey(uuid) || data.katilKimSpectators.contains(uuid)) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onBlockBreak(BlockBreakEvent event) {
        data.afkLastActivity.put(event.getPlayer().getUniqueId(), System.currentTimeMillis());
    }

    @EventHandler
    public void onBlockPlace(BlockPlaceEvent event) {
        data.afkLastActivity.put(event.getPlayer().getUniqueId(), System.currentTimeMillis());
    }
}
