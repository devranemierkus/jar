package com.yucehanrp.managers;

import com.yucehanrp.SessionData;

import java.util.List;
import java.util.Random;

public class CryptoManager {

    public static final List<String> COINS = List.of("sunpar", "yucecoin", "tavukcoin", "kredix", "emeraldcoin");

    private final SessionData data;
    private final Random rng = new Random();

    public CryptoManager(SessionData data) {
        this.data = data;
        initPrices();
    }

    private void initPrices() {
        for (String coin : COINS) {
            if (!data.cryptoPrice.containsKey(coin)) {
                data.cryptoPrice.put(coin, rng.nextInt(170) + 10);
                data.cryptoArrow.put(coin, "&7—");
            }
        }
    }

    public void updatePrices() {
        for (String coin : COINS) {
            int current = data.cryptoPrice.getOrDefault(coin, 50);
            int change = rng.nextInt(71) - 35; // -35 to +35
            int newPrice = Math.max(0, Math.min(180, current + change));
            data.cryptoArrow.put(coin, newPrice > current ? "&a▲" : "&c▼");
            data.cryptoPrice.put(coin, newPrice);
        }
    }

    public int getPrice(String coin) {
        return data.cryptoPrice.getOrDefault(coin, 0);
    }

    public String getArrow(String coin) {
        return data.cryptoArrow.getOrDefault(coin, "&7—");
    }

    public boolean isValidCoin(String coin) {
        return COINS.contains(coin.toLowerCase());
    }

    public String normalizeCoin(String input) {
        if (input == null) return null;
        return COINS.stream()
                .filter(c -> c.equalsIgnoreCase(input))
                .findFirst()
                .orElse(null);
    }
}
