package com.yucehanrp.listeners;

import com.yucehanrp.SessionData;
import com.yucehanrp.managers.*;
import com.yucehanrp.util.C;
import com.yucehanrp.util.ItemUtil;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.Material;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerPickupItemEvent;
import org.bukkit.inventory.ItemStack;

import java.util.UUID;

public class CombatListener implements Listener {

    private final SessionData data;
    private final InventoryManager invManager;
    private final GameHeadManager headManager;
    private final PvpSumoManager pvpSumo;
    private final KatilKimManager katilKim;
    private final BedWarsManager bedWars;

    public CombatListener(SessionData data, InventoryManager invManager, GameHeadManager headManager,
                          PvpSumoManager pvpSumo, KatilKimManager katilKim, BedWarsManager bedWars) {
        this.data = data;
        this.invManager = invManager;
        this.headManager = headManager;
        this.pvpSumo = pvpSumo;
        this.katilKim = katilKim;
        this.bedWars = bedWars;
    }

    // ==================== HASAR ====================
    // .sk: on damage — tüm hasar tipleri için BW lobi koruması
    @EventHandler
    public void onDamageAny(org.bukkit.event.entity.EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player victim)) return;
        UUID victimUUID = victim.getUniqueId();

        // BW lobi hasar koruması
        if (data.bwInLobby.containsKey(victimUUID)) {
            event.setCancelled(true);
            return;
        }

        // PVP: void/fall hasarını engelle, sadece hasar al ama void'e düşmesin
        if (data.pvpMode.containsKey(victimUUID)) {
            if (event.getCause() == org.bukkit.event.entity.EntityDamageEvent.DamageCause.VOID
             || event.getCause() == org.bukkit.event.entity.EntityDamageEvent.DamageCause.FALL) {
                event.setCancelled(true);
                // Y ekseni çok düştüyse spawn'a at
                if (victim.getLocation().getY() < -70) {
                    data.pvpMode.remove(victimUUID);
                    invManager.invGeriYukle(victim);
                    victim.setGameMode(GameMode.ADVENTURE);
                    victim.setHealth(20);
                    victim.teleport(new Location(Bukkit.getWorld("world"), -15, -60, -8));
                    headManager.giveGameHead(victim);
                    victim.sendMessage(C.c("&c&l[PVP] &7Düştün! Spawn'a gönderildin."));
                }
                return;
            }
        }

        // SUMO: void/fall hasarını engelle, Y kontrolü ile spawn
        if (data.sumoMode.containsKey(victimUUID)) {
            if (event.getCause() == org.bukkit.event.entity.EntityDamageEvent.DamageCause.VOID
             || event.getCause() == org.bukkit.event.entity.EntityDamageEvent.DamageCause.FALL) {
                event.setCancelled(true);
                // Sumo platformu Y=-59, aşağısı hava — Y < -61 yeterli
                if (victim.getLocation().getY() < -61) {
                    data.sumoMode.remove(victimUUID);
                    org.bukkit.plugin.Plugin pl = Bukkit.getPluginManager().getPlugin("YucehanRP");
                    Bukkit.getScheduler().runTaskLater(pl, () -> {
                        if (!victim.isOnline()) return;
                        invManager.invGeriYukle(victim);
                        victim.setGameMode(GameMode.ADVENTURE);
                        victim.setHealth(20);
                        victim.setFoodLevel(20);
                        victim.teleport(new Location(Bukkit.getWorld("world"), -15, -60, -8));
                        headManager.giveGameHead(victim);
                        victim.sendMessage(C.c("&a&l[SUMO] &7Platformdan düştün! Spawn'a gönderildin."));
                    }, 1L);
                }
                return;
            }
        }

        // KK: çevre hasar engelle (fall, void, mob vs.)
        if (data.katilKimActive && data.katilKimRole.containsKey(victimUUID)) {
            if (event.getCause() != org.bukkit.event.entity.EntityDamageEvent.DamageCause.ENTITY_ATTACK
             && event.getCause() != org.bukkit.event.entity.EntityDamageEvent.DamageCause.PROJECTILE) {
                event.setCancelled(true);
            }
        }
    }

    @EventHandler
    public void onDamage(EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof Player victim)) return;
        UUID victimUUID = victim.getUniqueId();

        // BW lobi koruması
        if (data.bwInLobby.containsKey(victimUUID)) { event.setCancelled(true); return; }

        // KatilKim: çevre hasar (mob, fall, vs.) engelle
        if (data.katilKimActive && data.katilKimRole.containsKey(victimUUID)
                && !(event.getDamager() instanceof Player)) {
            event.setCancelled(true);
            victim.setHealth(20);
            victim.teleport(new Location(Bukkit.getWorld("world"), -230, -60, 10000157));
            victim.sendActionBar(C.c("&4[KATİL KİM] &7Güvenli alana getirildin!"));
            return;
        }

        // PVP: sadece PVP silahıyla vurabilir
        if (event.getDamager() instanceof Player attacker) {
            UUID attackerUUID = attacker.getUniqueId();
            if (data.pvpMode.containsKey(attackerUUID)) {
                if (!pvpSumo.isPvpWeapon(attacker.getInventory().getItemInMainHand())) {
                    event.setCancelled(true);
                    attacker.sendActionBar(C.c("&c[PVP] Sadece Sistem baltasini kullanabilirsin!"));
                    return;
                }
            }

            // SUMO: her zaman vurabilir (yumruk zorunluluğu kaldırıldı)
            if (data.sumoMode.containsKey(attackerUUID)) {
                // Sumo'da vurma serbesttir
            }

            // KatilKim PvP kuralları
            if (data.katilKimActive) {
                String ar = data.katilKimRole.get(attackerUUID);
                String vr = data.katilKimRole.get(victimUUID);
                if (ar != null && vr != null) {
                    event.setCancelled(true);
                    if ("katil".equals(ar)) {
                        String weaponName = ItemUtil.displayName(attacker.getInventory().getItemInMainHand());
                        if (weaponName.equals(C.c("&c&lKATİL KILICI"))) {
                            if ("masum".equals(vr) || "serif".equals(vr)) {
                                katilKim.playerEliminated(victim, "Katil tarafindan olduruldu");
                            }
                        }
                    }
                    return;
                }
                if (vr != null || ar != null) { event.setCancelled(true); return; }
            }

            // BW hasar kuralları
            if (data.bwActive) {
                String at = data.bwTeam.get(attackerUUID);
                String vt = data.bwTeam.get(victimUUID);
                if (at != null && vt != null && at.equals(vt)) {
                    // Takım hasarı yok
                    event.setCancelled(true);
                    return;
                }
                if (at != null) {
                    data.bwPvpActive.put(attackerUUID, true);
                    data.bwPvpHits.merge(attackerUUID, 1, Integer::sum);
                }
            }
        }
    }

    // ==================== ÖLÜM ====================
    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        Player victim = event.getEntity();
        UUID victimUUID = victim.getUniqueId();

        // PVP stats — sadece gerçek PVP/Sumo alanında olan oyuncular için
        if (event.getEntity().getKiller() != null) {
            org.bukkit.entity.Player killer = event.getEntity().getKiller();
            boolean pvpOlumu = data.pvpMode.containsKey(victimUUID)
                    || data.sumoMode.containsKey(victimUUID)
                    || data.pvpMode.containsKey(killer.getUniqueId())
                    || data.sumoMode.containsKey(killer.getUniqueId());
            if (pvpOlumu) {
                data.pvpKills.merge(killer.getUniqueId(), 1, Integer::sum);
                data.pvpDeaths.merge(victimUUID, 1, Integer::sum);
                org.bukkit.Bukkit.broadcastMessage(com.yucehanrp.util.C.c("&4&l[PVP] &e" + killer.getName()
                        + " &7öldürdü &c" + victim.getName() + "&7'i! &8(&a"
                        + data.pvpKills.getOrDefault(killer.getUniqueId(), 0) + " &7öldürme&8)"));
            }
        }

        // PVP ölüm
        if (data.pvpMode.containsKey(victimUUID)) {
            event.setCancelled(true);
            event.getDrops().clear();
            data.pvpMode.remove(victimUUID);
            victim.setHealth(20);
            victim.setFoodLevel(20);
            victim.setGameMode(GameMode.ADVENTURE);
            victim.sendMessage(C.c("&c&l[PVP] &7Oldun! Spawn'a gonderildin."));
            Bukkit.getScheduler().runTaskLater(Bukkit.getPluginManager().getPlugin("YucehanRP"), () -> {
                if (!victim.isOnline()) return;
                invManager.invGeriYukle(victim);
                victim.teleport(new Location(Bukkit.getWorld("world"), -15, -60, -8));
                headManager.giveGameHead(victim);
            }, 2L);
            return;
        }

        // SUMO ölüm — normalde onDamageAny halleder ama yine de tetiklenirse
        if (data.sumoMode.containsKey(victimUUID)) {
            event.setCancelled(true);
            event.getDrops().clear();
            data.sumoMode.remove(victimUUID);
            victim.setHealth(20);
            victim.setFoodLevel(20);
            victim.setGameMode(GameMode.ADVENTURE);
            victim.sendMessage(C.c("&a&l[SUMO] &7Spawn'a gonderildin."));
            Bukkit.getScheduler().runTaskLater(Bukkit.getPluginManager().getPlugin("YucehanRP"), () -> {
                if (!victim.isOnline()) return;
                invManager.invGeriYukle(victim);
                victim.teleport(new Location(Bukkit.getWorld("world"), -15, -60, -8));
                headManager.giveGameHead(victim);
            }, 2L);
            return;
        }

        // KatilKim ölüm engelle
        if (data.katilKimActive && data.katilKimRole.containsKey(victimUUID)) {
            event.setCancelled(true);
            event.getDrops().clear();
            victim.setHealth(20);
            victim.teleport(new Location(Bukkit.getWorld("world"), -230, -60, 10000157));
            victim.sendActionBar(C.c("&4[KATİL KİM] &7Güvenli alana getirildin!"));
            return;
        }

        // BW ölüm - .sk: on death → play sound + explosion particle
        if (data.bwActive && data.bwTeam.containsKey(victimUUID)) {
            event.setCancelled(true);
            event.getDrops().clear();
            // .sk: play sound "entity.generic.explode" + particle explosion_emitter
            victim.getWorld().playSound(victim.getLocation(), org.bukkit.Sound.ENTITY_GENERIC_EXPLODE, 1f, 1f);
            victim.getWorld().spawnParticle(org.bukkit.Particle.EXPLOSION, victim.getLocation(), 1);
            String team = data.bwTeam.get(victimUUID);
            victim.getInventory().clear();

            boolean bedAlive = Boolean.TRUE.equals(data.bwBedAlive.get(team));
            if (bedAlive) {
                // Yatak sağlamsa yeniden doğ
                Bukkit.getScheduler().runTaskLater(Bukkit.getPluginManager().getPlugin("YucehanRP"), () -> {
                    if (!victim.isOnline()) return;
                    victim.setHealth(20);
                    victim.setFoodLevel(20);
                    bedWars.giveTeamKit(victim, team);
                    victim.teleport(bedWars.spawnLoc(team));
                    victim.sendActionBar(C.c("&c[BW] Öldün! Eşyaların gitti, yeniden doğdun."));
                    victim.sendTitle(C.c("&cÖLDÜN"), C.c("&7Doğuyor..."), 10, 40, 10);
                }, 20L);
            } else {
                // Yatak kırıksa elendin — önce temizle, sonra spec olarak ekle
                data.bwTeam.remove(victimUUID);
                data.clearBwPlayer(victimUUID); // bwSpec'i temizler
                data.bwSpec.put(victimUUID, true); // sonra spec ekle
                // .sk: effect clear slowness + glowing on elimination
                victim.removePotionEffect(org.bukkit.potion.PotionEffectType.SLOWNESS);
                victim.removePotionEffect(org.bukkit.potion.PotionEffectType.GLOWING);

                Bukkit.getScheduler().runTaskLater(Bukkit.getPluginManager().getPlugin("YucehanRP"), () -> {
                    if (!victim.isOnline()) return;
                    victim.setGameMode(GameMode.SPECTATOR);
                    victim.teleport(new Location(Bukkit.getWorld("world"), -55, 80, 10000075));
                    victim.sendMessage(C.c("&c&l[BED WARS] Elendin!"));
                    victim.sendTitle(C.c("&c&lELENDİN"), C.c("&7Spectator olarak izliyorsun!"), 10, 70, 20);

                    for (UUID uid : data.bwTeam.keySet()) {
                        Player p = Bukkit.getPlayer(uid);
                        if (p != null)
                            p.sendMessage(C.c("&c&l[BW] &f" + victim.getName() + " &c(" + bedWars.teamColorCode(team) + "&c) elendi!"));
                    }
                }, 20L);
                bedWars.checkWinner();
            }
            return;
        }

        // BW lobi ölüm
        if (data.bwInLobby.containsKey(victimUUID)) {
            event.setCancelled(true);
            event.getDrops().clear();
            Bukkit.getScheduler().runTaskLater(Bukkit.getPluginManager().getPlugin("YucehanRP"), () -> {
                if (victim.isOnline()) {
                    victim.setHealth(20);
                    victim.setFoodLevel(20);
                    victim.teleport(bedWars.lobbyLoc());
                }
            }, 1L);
        }
    }

    // ==================== OK ATIŞI - KatilKim Şerif ====================
    @EventHandler
    public void onShoot(ProjectileLaunchEvent event) {
        if (!(event.getEntity().getShooter() instanceof Player shooter)) return;
        UUID uuid = shooter.getUniqueId();
        if (!data.katilKimActive) return;
        String role = data.katilKimRole.get(uuid);
        if ("katil".equals(role) || "masum".equals(role)) {
            event.setCancelled(true);
            return;
        }
        if ("serif".equals(role)) {
            Long lastShot = data.serifArrowCooldown.get(uuid);
            if (lastShot != null) {
                long elapsed = (System.currentTimeMillis() - lastShot) / 1000;
                if (elapsed < 10) {
                    event.setCancelled(true);
                    shooter.sendActionBar(C.c("&c[SERİF] Ok cooldown: &e" + (10 - elapsed) + "sn bekle!"));
                    return;
                }
            }
            data.serifArrowCooldown.put(uuid, System.currentTimeMillis());
            shooter.sendActionBar(C.c("&e[SERİF] Ok atildi! &c10sn &7cooldown."));
            // 10 saniye sonra yeni ok ver
            Bukkit.getScheduler().runTaskLater(Bukkit.getPluginManager().getPlugin("YucehanRP"), () -> {
                if (!shooter.isOnline()) return;
                if (!"serif".equals(data.katilKimRole.get(uuid))) return;
                if (!data.katilKimActive) return;
                // Envanterinde ok yoksa ver
                boolean hasArrow = false;
                for (ItemStack item : shooter.getInventory().getContents()) {
                    if (item != null && item.getType() == Material.ARROW
                            && ItemUtil.uncoloredName(item).contains("SERIF OKU")) {
                        hasArrow = true; break;
                    }
                }
                if (!hasArrow) {
                    shooter.getInventory().setItem(7, katilKim.makeSerifOku());
                    shooter.sendActionBar(C.c("&e[SERİF] Ok yenilendi!"));
                }
            }, 200L); // 10 saniye
        }
    }

    @EventHandler
    public void onProjectileHit(ProjectileHitEvent event) {
        if (!(event.getEntity().getShooter() instanceof Player shooter)) return;
        if (!(event.getHitEntity() instanceof Player victim)) return;
        UUID shooterUUID = shooter.getUniqueId();
        if (!data.katilKimActive) return;
        if (!"serif".equals(data.katilKimRole.get(shooterUUID))) return;

        event.setCancelled(true);
        UUID victimUUID = victim.getUniqueId();
        String victimRole = data.katilKimRole.get(victimUUID);
        if ("katil".equals(victimRole)) {
            katilKim.endGame("serif_katili_vurdu");
            shooter.sendMessage(C.c("&e&l[SERİF] &7Katili vurdum!"));
        } else if ("masum".equals(victimRole)) {
            katilKim.broadcastToAll(C.c("&e▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
            katilKim.broadcastToAll(C.c("&c&l  ⚖ SERİF YANLIŞ ATTI!"));
            katilKim.broadcastToAll(C.c("&7  " + shooter.getName() + " masumu vurdu!"));
            katilKim.broadcastToAll(C.c("&7  Serif de elendi!"));
            katilKim.playerEliminated(victim, "Serif tarafindan yanlis vuruldu");
            katilKim.playerEliminated(shooter, "Masumu vurdu, cezayi cekti");
        }
    }

    // ==================== ITEM DROP ====================
    @EventHandler
    public void onDrop(PlayerDropItemEvent event) {
        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();

        // Oyun kafası hiçbir şekilde atılamaz — dupe önleme
        if (headManager.isGameHead(event.getItemDrop().getItemStack())) {
            event.setCancelled(true);
            // Geri ver, dupe olmasın
            Bukkit.getScheduler().runTaskLater(
                Bukkit.getPluginManager().getPlugin("YucehanRP"), () -> {
                    if (player.isOnline()) headManager.giveGameHead(player);
                }, 1L);
            return;
        }
        // BW: zırh atılamaz
        if (data.bwTeam.containsKey(uuid)) {
            String t = event.getItemDrop().getItemStack().getType().name();
            if (t.endsWith("_HELMET") || t.endsWith("_CHESTPLATE") ||
                t.endsWith("_LEGGINGS") || t.endsWith("_BOOTS")) {
                event.setCancelled(true);
                return;
            }
        }
        // Simon: drop engelle
        if (data.simonActive.containsKey(uuid)) { event.setCancelled(true); return; }
        // KK: drop engelle
        String kkRole = data.katilKimRole.get(uuid);
        if ("katil".equals(kkRole) || "serif".equals(kkRole)) { event.setCancelled(true); return; }
        if (data.katilKimSpectators.contains(uuid)) { event.setCancelled(true); return; }
        // PVP silahı atılamaz
        if (pvpSumo.isPvpWeapon(event.getItemDrop().getItemStack())) {
            event.setCancelled(true);
            player.sendActionBar(C.c("&c[PVP] Bu silah atilamazsiniz!"));
        }
    }

    // ==================== ITEM PICKUP ====================
    @EventHandler
    public void onPickup(EntityPickupItemEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        UUID uuid = player.getUniqueId();
        Item dropped = event.getItem();
        String itemName = ItemUtil.displayName(dropped.getItemStack());
        org.bukkit.Material itemType = dropped.getItemStack().getType();

        // .sk: BW aktifken yatak itemi alınamaz (on pickup)
        if (data.bwActive) {
            if (itemType == Material.RED_BED || itemType == Material.BLUE_BED
                    || itemType == Material.YELLOW_BED || itemType == Material.LIME_BED
                    || itemType == Material.WHITE_BED ) {
                event.setCancelled(true);
                return;
            }
        }

        // PVP silahını sadece PVP oyuncusu alabilir
        if (itemName.equals(C.c(SessionData.PVP_WEAPON_NAME))) {
            if (!data.pvpMode.containsKey(uuid)) {
                event.setCancelled(true);
                dropped.remove();
            }
        }
        // KK özel itemleri
        if (itemName.equals(C.c("&c&lKATİL KILICI")) && data.katilKimActive) {
            if (!"katil".equals(data.katilKimRole.get(uuid))) {
                event.setCancelled(true);
                dropped.remove();
            }
        }
        if (itemName.equals(C.c("&e&lSERIF YAYI")) && data.katilKimActive) {
            if (!"serif".equals(data.katilKimRole.get(uuid))) {
                event.setCancelled(true);
                dropped.remove();
            }
        }
        // KK aktifken ok — HİÇ KİMSE ALAMAZ, yok olur
        if (data.katilKimActive && itemType == Material.ARROW) {
            event.setCancelled(true);
            dropped.remove();
        }
    }
}
