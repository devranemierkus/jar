package com.yucehanrp.commands;

import com.yucehanrp.SessionData;
import com.yucehanrp.managers.*;
import com.yucehanrp.util.C;
import com.yucehanrp.util.ItemUtil;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.NotNull;

import java.util.UUID;

public class CommandManager implements CommandExecutor {

    private final Plugin plugin;
    private final SessionData data;
    private final InventoryManager invManager;
    private final GameHeadManager headManager;
    private final PhoneManager phone;
    private final CryptoManager crypto;
    private final MarketManager market;
    private final MarketGUIManager marketGui;
    private final GamesMenuManager gamesMenu;
    private final GameQuitManager quitManager;
    private final KatilKimManager katilKim;
    private final BedWarsManager bedWars;

    public CommandManager(Plugin plugin, SessionData data, InventoryManager invManager,
                          GameHeadManager headManager, PhoneManager phone, CryptoManager crypto,
                          MarketManager market, MarketGUIManager marketGui, GamesMenuManager gamesMenu,
                          GameQuitManager quitManager, KatilKimManager katilKim, BedWarsManager bedWars) {
        this.plugin = plugin;
        this.data = data;
        this.invManager = invManager;
        this.headManager = headManager;
        this.phone = phone;
        this.crypto = crypto;
        this.market = market;
        this.marketGui = marketGui;
        this.gamesMenu = gamesMenu;
        this.quitManager = quitManager;
        this.katilKim = katilKim;
        this.bedWars = bedWars;
    }

    public void registerAll() {
        for (String cmd : new String[]{
                "rehber","rehberkabul","rehberkapat","koordinat","arsanasil","kurallar",
                "telefonbataryadoldur","telefonozellikleri","telefonsatinal","telefonarama","telefonkapat","telefonmsj",
                "bilgisayarac","bilgisayarkriptobak","bilgisayarkriptoal","bilgisayarkriptosat","bilgisayarsatinal","bilgisayarkapat","kriptocuzdan",
                "market","marketiptal",
                "metroyabin","otobusebin","sefersatinal","seferyap","seferbak","pvpstats",
                "telefonac","telefonaraac","telefonarareddet","telefonarakapat","sohbettemizle",
                "oyundancik","herkesoyundancik","yetkilioyundancikar","bwmagaza",
                "telefonsessizal","telefonrahatsizEtmeal"
        }) {
            if (((JavaPlugin)plugin).getCommand(cmd) != null)
                ((JavaPlugin)plugin).getCommand(cmd).setExecutor(this);
        }
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player player)) {
            // Konsol komutları
            String cmd = command.getName().toLowerCase();
            if ("herkesoyundancik".equals(cmd)) {
                quitManager.evictAll();
                sender.sendMessage("[YucehanRP] Tüm oyuncular oyundan çıkarıldı.");
            }
            return true;
        }

        UUID uuid = player.getUniqueId();
        String cmd = command.getName().toLowerCase().replace("ı","i").replace("İ","i");

        switch (cmd) {
            // ==================== REHBER ====================
            case "rehber" -> {
                data.guideState.put(uuid, "BASLADI");
                player.sendMessage(C.c(""));
                player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                player.sendMessage(C.c("       &d&l✦ &5&lKALYX &d&lREHBERİ &d&l✦"));
                player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                player.sendMessage(C.c("&d&lKALYX &8› &fSelam &e&l" + player.getName() + "&f! Ben &d&lKalyx&f, bu şehrin rehberiyim."));
                player.sendMessage(C.c("&d&lKALYX &8› &7Sana &b&lDondurmacılık &7mesleğini öğreteceğim."));
                player.sendMessage(C.c("&d&lKALYX &8› &fHazır mısın?"));
                player.sendMessage(C.c("&a&l  ✔ Kabul etmek için: &e/rehberkabul &a yaz!"));
                player.sendMessage(C.c("&c&l  ✘ İptal etmek için: &e/rehberkapat &c yaz!"));
                player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
            }
            case "rehberkabul" -> {
                if ("BASLADI".equals(data.guideState.get(uuid))) {
                    data.guideAccepted.put(uuid, true);
                    player.sendMessage(C.c("&d&lKALYX &8› &a&l✔ Süper! &fO zaman başlayalım."));
                    player.sendMessage(C.c("&d&lKALYX &8› &7Meslek Meydanına gitmek için: &e/warp meslekseç &7yaz!"));
                } else {
                    player.sendMessage(C.c("&cÖnce &e/rehber &cyazmalısın."));
                }
            }
            case "rehberkapat" -> {
                data.guideState.remove(uuid);
                data.guideAccepted.remove(uuid);
                player.sendMessage(C.c("&d&lKALYX &8› &cRehber kapatıldı. Tekrar başlamak için &e/rehber &cyaz."));
            }

            // ==================== KOORDİNAT ====================
            case "koordinat" -> {
                double kx = Math.floor(player.getLocation().getX() * 100) / 100;
                double ky = Math.floor(player.getLocation().getY() * 100) / 100;
                double kz = Math.floor(player.getLocation().getZ() * 100) / 100;
                player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                player.sendMessage(C.c(" &e&l📍 MEVCUT KONUMUN"));
                player.sendMessage(C.c("  &7X: &e" + kx));
                player.sendMessage(C.c("  &7Y: &e" + ky));
                player.sendMessage(C.c("  &7Z: &e" + kz));
                player.sendMessage(C.c("  &7Dünya: &b" + player.getWorld().getName()));
                player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                player.sendActionBar(C.c("&e📍 &b" + kx + ", " + ky + ", " + kz));
            }

            // ==================== ARSA ====================
            case "arsanasil" -> {
                player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                player.sendMessage(C.c(" &6&l🏠 ARSA SATIN ALMA REHBERİ"));
                player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                player.sendMessage(C.c("  &71. &fİstediğin &eBOŞ &farsa bölgesine git, koordinatları al (/koordinat)"));
                player.sendMessage(C.c("  &72. &fEnvanterinde arsa parasının &aHAZIR &folduğundan emin ol"));
                player.sendMessage(C.c("  &73. &fAşağıdaki 3 platformdan biriyle iletişime geç"));
                player.sendMessage(C.c("  &b&lDiscord:    &fhttps://discord.gg/UsHEmQ6gKE"));
                player.sendMessage(C.c("  &d&lInstagram: &fhttps://ig.me/j/AbYf5xko7wYSwck4/"));
                player.sendMessage(C.c("  &a&lTikTok:     &fhttps://tiktok.me/group/ZSy3LJJDn/"));
                player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
            }

            case "kurallar" -> {
                player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                player.sendMessage(C.c(" &c&l⚠ SUNUCU KURALLARI"));
                player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                player.sendMessage(C.c("&7Kurallar için web sitesini ziyaret et:"));
                player.sendMessage(C.c("&e&lyucehanrp.gamer.gd"));
                player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
            }

            // ==================== TELEFON ====================
            case "telefonbataryadoldur" -> {
                if (phone.hasPhone(player)) {
                    phone.startCharging(player);
                    player.sendMessage(C.c(SessionData.YUCECELL_PREFIX + " &eSarj baslatildi."));
                } else {
                    player.sendMessage(C.c(SessionData.YUCECELL_PREFIX + " " + SessionData.YUCECELL_NO_PHONE));
                }
            }
            case "telefonozellikleri" -> {
                player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                player.sendMessage(C.c(" &b&lYUCECELL TEKNOLOJI KATALOGU"));
                player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                player.sendMessage(C.c("&e1. Lite Model:  &7SMS -5 | Arama -10 | &a32 Zümrüt"));
                player.sendMessage(C.c("&e2. Basic Model: &7SMS -3 | Arama -7  | &a48 Zümrüt"));
                player.sendMessage(C.c("&e3. V1 Model:    &7SMS -2 | Arama -5  | &a64 Zümrüt"));
                player.sendMessage(C.c("&d4. Pro Model:   &bSMS -1 | Arama -3  | &a96 Zümrüt"));
                player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
            }
            case "telefonsatinal" -> {
                if (args.length < 1) { player.sendMessage(C.c("&cKullanım: /telefonsatinal <lite|basic|v1|pro>")); return true; }
                String model = args[0].toLowerCase();
                int cost = switch (model) {
                    case "lite" -> 32; case "basic" -> 48; case "v1" -> 64; case "pro" -> 96; default -> -1;
                };
                if (cost < 0) { player.sendMessage(C.c("&cGeçersiz model! lite, basic, v1 veya pro yaz.")); return true; }
                if (!player.getInventory().contains(org.bukkit.Material.EMERALD, cost)) {
                    player.sendMessage(C.c(SessionData.YUCECELL_PREFIX + " &c" + cost + " Zümrüt gerekiyor!")); return true;
                }
                removeItems(player, org.bukkit.Material.EMERALD, cost);
                // Telefonu ver (Paper item ile temsil)
                ItemStack phoneItem = new ItemStack(org.bukkit.Material.PAPER);
                org.bukkit.inventory.meta.ItemMeta meta = phoneItem.getItemMeta();
                if (meta != null) {
                    meta.setDisplayName(C.c("&bYucecell &7- &e" + capitalize(model) + " Model"));
                    meta.setLore(java.util.List.of(C.c(SessionData.YUCECELL_LORE)));
                    phoneItem.setItemMeta(meta);
                }
                player.getInventory().addItem(phoneItem);
                phone.setPhoneModel(player, model);
                player.sendMessage(C.c(SessionData.YUCECELL_PREFIX + " &aYucecell " + capitalize(model) + " Model alındı!"));
            }
            case "telefonarama" -> {
                if (args.length < 1) { player.sendMessage(C.c("&cKullanım: /telefonarama <oyuncu>")); return true; }
                if (!phone.hasPhone(player)) { player.sendMessage(C.c(SessionData.YUCECELL_PREFIX + " " + SessionData.YUCECELL_NO_PHONE)); return true; }
                if (phone.isInCall(player)) { player.sendMessage(C.c(SessionData.YUCECELL_PREFIX + " &cZaten bir görüşmedeysiniz!")); return true; }
                if (data.busyWith.containsKey(uuid)) { player.sendMessage(C.c(SessionData.YUCECELL_PREFIX + " &cZaten birini arıyorsunuz!")); return true; }
                // Spam koruması: 10 saniyede bir arama
                Long lastCall = data.aramaSpamCooldown.get(uuid);
                if (lastCall != null && System.currentTimeMillis() - lastCall < 10_000L) {
                    long kalan = (10_000L - (System.currentTimeMillis() - lastCall)) / 1000;
                    player.sendMessage(C.c(SessionData.YUCECELL_PREFIX + " &cSpam arama! &e" + kalan + " saniye bekle."));
                    return true;
                }
                Player target = Bukkit.getPlayerExact(args[0]);
                if (target == null || !target.isOnline()) { player.sendMessage(C.c(SessionData.YUCECELL_PREFIX + " &cOyuncu bulunamadı!")); return true; }
                if (target.getUniqueId().equals(uuid)) { player.sendMessage(C.c(SessionData.YUCECELL_PREFIX + " &cKendinizi arayamazsınız!")); return true; }
                if (!phone.hasPhone(target)) { player.sendMessage(C.c(SessionData.YUCECELL_PREFIX + " &cKarşı tarafın telefonu yok!")); return true; }
                if (phone.isInCall(target) || data.busyWith.containsKey(target.getUniqueId())) { player.sendMessage(C.c(SessionData.YUCECELL_PREFIX + " &cKarşı taraf meşgul!")); return true; }
                // Sessiz mod veya rahatsız etme kontrolü
                if (data.telefonSessiz.contains(target.getUniqueId()) || data.telefonRahatsizEtme.contains(target.getUniqueId())) {
                    player.sendMessage(C.c(SessionData.YUCECELL_PREFIX + " &cKarşı taraf şu an aramayı kapalı tutmuş!"));
                    return true;
                }
                data.aramaSpamCooldown.put(uuid, System.currentTimeMillis());
                // Kabul bekleniyor — sadece busyWith ile işaretle, inCall'a KOYMA
                data.busyWith.put(uuid, target.getUniqueId());
                data.busyWith.put(target.getUniqueId(), uuid);
                player.sendMessage(C.c(SessionData.YUCECELL_PREFIX + " &e" + target.getName() + " &7aranıyor..."));
                target.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                target.sendMessage(C.c(SessionData.YUCECELL_PREFIX + " &e" + player.getName() + " &7sizi arıyor!"));
                target.sendMessage(C.c("  &aKabul: &e/telefonaraac"));
                target.sendMessage(C.c("  &cReddet: &e/telefonarakapat"));
                target.sendMessage(C.c("  &7Rahatsız edilmek istemiyorsanız: &e/telefonrahatsizEtmeal"));
                target.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                target.playSound(target.getLocation(), org.bukkit.Sound.BLOCK_NOTE_BLOCK_PLING, 1f, 1.5f);
            }
            case "telefonkapat" -> {
                if (!phone.isInCall(player)) { player.sendMessage(C.c(SessionData.YUCECELL_PREFIX + " &cGörüşmede değilsiniz!")); return true; }
                Player partner = phone.getCallPartner(player);
                phone.endCall(player);
                player.sendMessage(C.c(SessionData.YUCECELL_PREFIX + " &cGörüşme kapatıldı."));
                if (partner != null && partner.isOnline())
                    partner.sendMessage(C.c(SessionData.YUCECELL_PREFIX + " &cKarşı taraf görüşmeyi kapattı."));
            }
            case "telefonmsj" -> {
                if (args.length < 2) { player.sendMessage(C.c("&cKullanım: /telefonmsj <oyuncu> <mesaj>")); return true; }
                if (!phone.hasPhone(player)) { player.sendMessage(C.c(SessionData.YUCECELL_PREFIX + " " + SessionData.YUCECELL_NO_PHONE)); return true; }
                Player target = Bukkit.getPlayerExact(args[0]);
                if (target == null) { player.sendMessage(C.c(SessionData.YUCECELL_PREFIX + " &cOyuncu bulunamadı!")); return true; }
                if (!phone.hasPhone(target)) { player.sendMessage(C.c(SessionData.YUCECELL_PREFIX + " &cKarşı tarafın telefonu yok!")); return true; }
                // Sessiz mod kontrolü
                if (data.telefonSessiz.contains(target.getUniqueId())) {
                    player.sendMessage(C.c(SessionData.YUCECELL_PREFIX + " &cKarşı taraf mesajları kapalı tutmuş!"));
                    return true;
                }
                int smsCost = phone.getCallCost(player) / 2;
                if (phone.getBattery(player) < smsCost) { player.sendMessage(C.c(SessionData.YUCECELL_PREFIX + " &cBatarya yetersiz!")); return true; }
                phone.removeBattery(player, smsCost);
                String msg = String.join(" ", java.util.Arrays.copyOfRange(args, 1, args.length));
                player.sendMessage(C.c("&b[SMS → " + target.getName() + "] &f" + msg));
                target.sendMessage(C.c("&b[SMS ← " + player.getName() + "] &f" + msg));
                target.playSound(target.getLocation(), org.bukkit.Sound.BLOCK_NOTE_BLOCK_PLING, 0.5f, 2f);
            }

            // ==================== TELEFON MOD ====================
            case "telefonsessizal", "telefonrahatsizEtmeal" -> {
                if (!phone.hasPhone(player)) { player.sendMessage(C.c(SessionData.YUCECELL_PREFIX + " " + SessionData.YUCECELL_NO_PHONE)); return true; }
                if (args.length < 1) {
                    player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                    player.sendMessage(C.c(SessionData.YUCECELL_PREFIX + " &eKullanım:"));
                    player.sendMessage(C.c("  &e/telefonrahatsizetmeal arama &8› &7Aramaları engelle/aç"));
                    player.sendMessage(C.c("  &e/telefonrahatsizetmeal mesaj &8› &7Mesajları engelle/aç"));
                    player.sendMessage(C.c("  &e/telefonrahatsizetmeal hepsi &8› &7Arama + mesajların hepsini engelle/aç"));
                    player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                    return true;
                }
                switch (args[0].toLowerCase()) {
                    case "arama" -> {
                        if (data.telefonRahatsizEtme.contains(uuid)) {
                            data.telefonRahatsizEtme.remove(uuid);
                            player.sendMessage(C.c(SessionData.YUCECELL_PREFIX + " &aArama engeli kaldırıldı."));
                        } else {
                            data.telefonRahatsizEtme.add(uuid);
                            player.sendMessage(C.c(SessionData.YUCECELL_PREFIX + " &6Arama engeli açıldı. Artık arama alamazsınız."));
                        }
                    }
                    case "mesaj" -> {
                        if (data.telefonSessiz.contains(uuid)) {
                            data.telefonSessiz.remove(uuid);
                            player.sendMessage(C.c(SessionData.YUCECELL_PREFIX + " &aMesaj engeli kaldırıldı."));
                        } else {
                            data.telefonSessiz.add(uuid);
                            player.sendMessage(C.c(SessionData.YUCECELL_PREFIX + " &6Mesaj engeli açıldı. Artık mesaj alamazsınız."));
                        }
                    }
                    case "hepsi" -> {
                        boolean hepsiVar = data.telefonSessiz.contains(uuid) && data.telefonRahatsizEtme.contains(uuid);
                        if (hepsiVar) {
                            data.telefonSessiz.remove(uuid);
                            data.telefonRahatsizEtme.remove(uuid);
                            player.sendMessage(C.c(SessionData.YUCECELL_PREFIX + " &aTüm engeller kaldırıldı. Arama ve mesaj alabilirsiniz."));
                        } else {
                            data.telefonSessiz.add(uuid);
                            data.telefonRahatsizEtme.add(uuid);
                            player.sendMessage(C.c(SessionData.YUCECELL_PREFIX + " &6Tüm engeller açıldı. Ne arama ne mesaj alırsınız."));
                        }
                    }
                    default -> player.sendMessage(C.c(SessionData.YUCECELL_PREFIX + " &cGeçersiz! &e/telefonrahatsizetmeal <arama|mesaj|hepsi>"));
                }
            }

            // ==================== BİLGİSAYAR / KRİPTO ====================
            case "bilgisayarac" -> {
                org.bukkit.inventory.ItemStack pcItem = player.getInventory().getItemInMainHand();
                boolean hasPC = pcItem != null
                        && pcItem.getType() == org.bukkit.Material.COMPASS
                        && ItemUtil.hasLoreContaining(pcItem, "YUCECELL A.S.");
                if (hasPC) {
                    data.pcOpen.put(uuid, true);
                    player.sendMessage(C.c("&b&lYUCECELL OS &8> &aSistem açıldı."));
                } else {
                    player.sendMessage(C.c("&b&lYUCECELL OS &8> &cElinde aktif bir YUCECELL bilgisayar bulunamadı!"));
                }
            }
            case "bilgisayarkriptobak" -> {
                if (!data.pcOpen.containsKey(uuid)) { player.sendMessage(C.c("&b&lYUCECELL OS &8> &cPC Kapalı!")); return true; }
                player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                player.sendMessage(C.c(" &6&lYUCE-EXCHANGE &7(Cüzdan: &e/kriptocuzdan&7)"));
                player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                for (String coin : CryptoManager.COINS) {
                    player.sendMessage(C.c("&e" + coin + ": &f" + crypto.getPrice(coin) + " Z &8| " + crypto.getArrow(coin)));
                }
                player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
            }
            case "bilgisayarkriptoal" -> {
                if (!data.pcOpen.containsKey(uuid)) { player.sendMessage(C.c("&b&lYUCECELL OS &8> &cPC Kapalı!")); return true; }
                if (args.length < 1) { player.sendMessage(C.c("&cKullanım: /bilgisayarkriptoal <coin>")); return true; }
                Long lastBuy = data.cryptoBuyCooldown.get(uuid);
                if (lastBuy != null && System.currentTimeMillis() - lastBuy < 10 * 60 * 1000L) {
                    long kalan = 10 - (System.currentTimeMillis() - lastBuy) / 60000;
                    player.sendMessage(C.c("&b&lYUCECELL OS &8> &cBekle: &e~" + kalan + " dk")); return true;
                }
                String coin = crypto.normalizeCoin(args[0]);
                if (coin == null) { player.sendMessage(C.c("&cGeçerli coin: " + String.join(", ", CryptoManager.COINS))); return true; }
                if (!player.getInventory().contains(org.bukkit.Material.EMERALD, 192)) {
                    player.sendMessage(C.c("&b&lYUCECELL OS &8> &c192 Zümrüt (3 stack) gerekiyor!")); return true;
                }
                removeItems(player, org.bukkit.Material.EMERALD, 192);
                data.addCryptoWallet(uuid, coin, 1);
                data.cryptoBuyCooldown.put(uuid, System.currentTimeMillis());
                player.sendMessage(C.c("&b&lYUCECELL OS &8> &a1 Adet &e" + coin + " &aalındı. (192Z)"));
                player.sendMessage(C.c("&c&lUYARI! &7Sunucu yeniden başladığında coinler kaybolur."));
            }
            case "bilgisayarkriptosat" -> {
                if (!data.pcOpen.containsKey(uuid)) { player.sendMessage(C.c("&b&lYUCECELL OS &8> &cPC Kapalı!")); return true; }
                if (args.length < 1) { player.sendMessage(C.c("&cKullanım: /bilgisayarkriptosat <coin>")); return true; }
                Long lastSell = data.cryptoSellCooldown.get(uuid);
                if (lastSell != null && System.currentTimeMillis() - lastSell < 10 * 60 * 1000L) {
                    long kalan = 10 - (System.currentTimeMillis() - lastSell) / 60000;
                    player.sendMessage(C.c("&b&lYUCECELL OS &8> &cBekle: &e~" + kalan + " dk")); return true;
                }
                String coin = crypto.normalizeCoin(args[0]);
                if (coin == null) { player.sendMessage(C.c("&cGeçerli coin: " + String.join(", ", CryptoManager.COINS))); return true; }
                int amount = data.getCryptoWallet(uuid, coin);
                if (amount < 1) { player.sendMessage(C.c("&b&lYUCECELL OS &8> &cCüzdanında &e" + coin + " &cyok!")); return true; }
                int price = crypto.getPrice(coin);
                int earnings = price;
                data.removeCryptoWallet(uuid, coin, 1);
                data.cryptoSellCooldown.put(uuid, System.currentTimeMillis());
                giveEmeralds(player, earnings);
                player.sendMessage(C.c("&b&lYUCECELL OS &8> &a1 &e" + coin + " &a" + earnings + "Z'ye satıldı!"));
            }
            case "bilgisayarsatinal" -> {
                if (args.length < 1) {
                    player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                    player.sendMessage(C.c(" &b&lYUCECELL BİLGİSAYAR KATALOGU"));
                    player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                    player.sendMessage(C.c("&e1. Lite:  &732 Zümrüt"));
                    player.sendMessage(C.c("&e2. Basic: &764 Zümrüt"));
                    player.sendMessage(C.c("&e3. V1:    &796 Zümrüt"));
                    player.sendMessage(C.c("&d4. Pro:   &7128 Zümrüt"));
                    player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                    player.sendMessage(C.c("&7Kullanım: &e/bilgisayarsatinal <lite|basic|v1|pro>"));
                    return true;
                }
                String pcModel = args[0].toLowerCase();
                int pcCost = switch (pcModel) {
                    case "lite" -> 32;
                    case "basic" -> 64;
                    case "v1" -> 96;
                    case "pro" -> 128;
                    default -> -1;
                };
                if (pcCost < 0) {
                    player.sendMessage(C.c("&b&lYUCECELL OS &8> &cGeçerli model: lite, basic, v1, pro"));
                    return true;
                }
                if (!player.getInventory().contains(org.bukkit.Material.EMERALD, pcCost)) {
                    player.sendMessage(C.c("&b&lYUCECELL OS &8> &c" + pcCost + " Zümrüt gerekiyor!"));
                    return true;
                }
                removeItems(player, org.bukkit.Material.EMERALD, pcCost);
                org.bukkit.inventory.ItemStack pcItem = new org.bukkit.inventory.ItemStack(org.bukkit.Material.COMPASS);
                org.bukkit.inventory.meta.ItemMeta pcMeta = pcItem.getItemMeta();
                if (pcMeta != null) {
                    String modelName = pcModel.substring(0, 1).toUpperCase() + pcModel.substring(1);
                    pcMeta.setDisplayName(C.c("&eYUCECELL &f" + modelName + " Bilgisayar"));
                    java.util.List<String> pcLore = new java.util.ArrayList<>();
                    pcLore.add(C.c("&8YUCECELL A.S. RESMİ CİHAZ"));
                    pcLore.add(C.c("&7/bilgisayarac ile ac"));
                    pcLore.add(C.c("&7/bilgisayarkriptobak - al - sat"));
                    pcMeta.setLore(pcLore);
                    pcItem.setItemMeta(pcMeta);
                }
                player.getInventory().addItem(pcItem);
                player.sendMessage(C.c("&b&lYUCECELL OS &8> &a" + args[0] + " bilgisayar alındı!"));
            }
            case "kriptocuzdan" -> {
                player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                player.sendMessage(C.c(" &6&lKRİPTO CÜZDAN"));
                player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                for (String coin : CryptoManager.COINS) {
                    int amt = data.getCryptoWallet(uuid, coin);
                    player.sendMessage(C.c("&e" + coin + ": &f" + amt + " adet"));
                }
                player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
            }
            // .sk: command /bilgisayarkapat
            case "bilgisayarkapat" -> {
                data.pcOpen.remove(uuid);
                player.sendMessage(C.c("&b&lYUCECELL OS &8> &7Sistem kapatıldı."));
            }


            // ==================== ULAŞIM ====================
            case "metroyabin" -> {
                if (data.metroCooldown.containsKey(uuid)) {
                    long elapsed = System.currentTimeMillis() - data.metroCooldown.get(uuid);
                    if (elapsed < 30_000L) {
                        long kalan = (30_000L - elapsed) / 1000;
                        player.sendMessage(C.c("&c&l[METRO] &7Metro kullanmak için &e" + kalan + "sn &7beklemelisin!"));
                        return true;
                    }
                }
                if (!player.getInventory().contains(org.bukkit.Material.EMERALD, 5)) {
                    player.sendMessage(C.c("&c&l[METRO] &7Metroya binmek için &e5 Zümrüt &7gerekiyor!"));
                    return true;
                }
                removeItems(player, org.bukkit.Material.EMERALD, 5);
                data.metroCooldown.put(uuid, System.currentTimeMillis());
                player.teleport(new org.bukkit.Location(org.bukkit.Bukkit.getWorld("world"), 1191.25, -60, -616.49));
                player.sendMessage(C.c("&a&l[METRO] &fMetroya bindiniz!"));
                player.sendTitle(C.c("&6&lMETRO"), C.c("&aSeyahat başladı!"), 10, 60, 20);
                player.playSound(player.getLocation(), org.bukkit.Sound.BLOCK_NOTE_BLOCK_BELL, 1f, 2f);
            }
            case "otobusebin" -> {
                if (data.otobusCooldown.containsKey(uuid)) {
                    long elapsed = System.currentTimeMillis() - data.otobusCooldown.get(uuid);
                    if (elapsed < 30_000L) {
                        long kalan = (30_000L - elapsed) / 1000;
                        player.sendMessage(C.c("&c&l[OTOBÜS] &7Otobüs kullanmak için &e" + kalan + "sn &7beklemelisin!"));
                        return true;
                    }
                }
                if (!player.getInventory().contains(org.bukkit.Material.EMERALD, 4)) {
                    player.sendMessage(C.c("&c&l[OTOBÜS] &7Otobüse binmek için &e4 Zümrüt &7gerekiyor!"));
                    return true;
                }
                removeItems(player, org.bukkit.Material.EMERALD, 4);
                data.otobusCooldown.put(uuid, System.currentTimeMillis());
                player.teleport(new org.bukkit.Location(org.bukkit.Bukkit.getWorld("world"), -81.44, -60, 9999897.45));
                player.sendMessage(C.c("&a&l[OTOBÜS] &fOtobüse bindiniz!"));
                player.sendTitle(C.c("&6&lOTOBÜS"), C.c("&aSeyahat başladı!"), 10, 60, 20);
                player.playSound(player.getLocation(), org.bukkit.Sound.BLOCK_NOTE_BLOCK_BELL, 1f, 2f);
            }
            case "seferbak" -> {
                player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                player.sendMessage(C.c(" &e&l✈ AKTİF SEFER LİSTESİ"));
                player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                player.sendMessage(C.c("&7Aktif Sefer: &a&lİstanbul (AÇIK)"));
                player.sendMessage(C.c("&7Bilet Fiyatı: &e64 Zümrüt"));
                player.sendMessage(C.c("&a/sefersatinal istanbul &8- &7Bilet al"));
                player.sendMessage(C.c("&a/seferyap istanbul &8- &7Sefere git"));
                player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
            }
            case "sefersatinal" -> {
                if (args.length < 1 || !args[0].equalsIgnoreCase("istanbul")) {
                    player.sendMessage(C.c("&e&l[SEFER] &cKullanım: &e/sefersatinal istanbul"));
                    return true;
                }
                if (!player.getInventory().contains(org.bukkit.Material.EMERALD, 64)) {
                    player.sendMessage(C.c("&e&l[SEFER] &c64 Zümrüt gerekiyor!"));
                    return true;
                }
                removeItems(player, org.bukkit.Material.EMERALD, 64);
                org.bukkit.inventory.ItemStack bilet = new org.bukkit.inventory.ItemStack(org.bukkit.Material.PAPER);
                org.bukkit.inventory.meta.ItemMeta bm = bilet.getItemMeta();
                if (bm != null) {
                    bm.setDisplayName(C.c("&e&lUÇAK BİLETİ &8- &bİstanbul"));
                    java.util.List<String> bl = new java.util.ArrayList<>();
                    bl.add(C.c("&8Kopyalanamaz Özel Bilet"));
                    bl.add(C.c("&7Hedef: &bİstanbul"));
                    bl.add(C.c("&cTek Kullanımlık"));
                    bm.setLore(bl);
                    bilet.setItemMeta(bm);
                }
                player.getInventory().addItem(bilet);
                player.sendMessage(C.c("&e&l[SEFER] &aİstanbul bileti satın alındı!"));
                player.sendMessage(C.c("&e&l[SEFER] &7Kullanmak için: &e/seferyap istanbul"));
            }
            case "seferyap" -> {
                if (args.length < 1) { player.sendMessage(C.c("&e&l[SEFER] &cKullanım: &e/seferyap istanbul")); return true; }
                if (data.seferCooldown.containsKey(uuid)) {
                    long elapsed = System.currentTimeMillis() - data.seferCooldown.get(uuid);
                    if (elapsed < 20 * 60_000L) {
                        long kalan = (20 * 60_000L - elapsed) / 1000;
                        player.sendMessage(C.c("&e&l[SEFER] &cBir sefer yaptın! &eKalan: " + (kalan/60) + "dk " + (kalan%60) + "sn"));
                        return true;
                    }
                }
                // Bilet ara
                boolean biletVar = false;
                for (org.bukkit.inventory.ItemStack it : player.getInventory().getContents()) {
                    if (it != null && it.hasItemMeta() && it.getItemMeta().hasDisplayName()
                            && it.getItemMeta().getDisplayName().contains("UÇAK BİLETİ")
                            && it.getItemMeta().getDisplayName().contains("istanbul".equals(args[0].toLowerCase()) ? "İstanbul" : "X")) {
                        player.getInventory().remove(it);
                        biletVar = true;
                        break;
                    }
                }
                if (!biletVar) { player.sendMessage(C.c("&e&l[SEFER] &cİstanbul bileti bulunamadı!")); return true; }
                player.sendMessage(C.c("&e&l[SEFER] &bİstanbul&7'a gidiyorsun..."));
                data.seferCooldown.put(uuid, System.currentTimeMillis());
                org.bukkit.Bukkit.getScheduler().runTaskLater(plugin, () -> {
                    if (player.isOnline())
                        player.teleport(new org.bukkit.Location(org.bukkit.Bukkit.getWorld("world"), -1229, -57, -328));
                }, 60L);
            }
            // ==================== PVP STATS ====================
            case "pvpstats" -> {
                player.sendMessage(C.c("&c[PVP] &7PVP istatistikleri bu sürümde devre dışı bırakıldı."));
            }
            // ==================== TELEFON EK ====================
            case "telefonac" -> {
                org.bukkit.inventory.ItemStack tool = player.getInventory().getItemInMainHand();
                boolean hasPhone = tool != null
                        && tool.getType() == org.bukkit.Material.PAPER
                        && ItemUtil.hasLoreContaining(tool, "YUCECELL A.S.");
                if (hasPhone) {
                    data.phoneOpen.put(uuid, true);
                    player.sendTitle(C.c("&b&lYUCECELL OS"), C.c("&aAciliyor..."), 10, 40, 20);
                    int bat = phone.getBattery(player);
                    player.sendMessage(C.c("&bYUCECELL &8> &aTelefon açıldı. &7Batarya: &e" + bat + "%"));
                } else {
                    player.sendMessage(C.c("&bYUCECELL &8> &cElinde aktif bir YUCECELL cihazı bulunamadı!"));
                }
            }
            case "telefonaraac" -> {
                java.util.UUID arayan = data.busyWith.get(uuid);
                if (arayan != null && !data.inCall.containsKey(uuid)) {
                    data.inCall.put(uuid, true);
                    data.inCall.put(arayan, true);
                    player.sendMessage(C.c(SessionData.YUCECELL_PREFIX + " &aGörüşme başladı."));
                    org.bukkit.entity.Player arayP = org.bukkit.Bukkit.getPlayer(arayan);
                    if (arayP != null) arayP.sendMessage(C.c(SessionData.YUCECELL_PREFIX + " &e" + player.getName() + " &aaramayı kabul etti. Görüşme başladı."));
                } else {
                    player.sendMessage(C.c(SessionData.YUCECELL_PREFIX + " &cKabul bekleyen bir arama yok!"));
                }
            }
            case "telefonarareddet" -> {
                java.util.UUID arayan = data.busyWith.get(uuid);
                if (arayan != null && !data.inCall.containsKey(uuid)) {
                    org.bukkit.entity.Player arayP = org.bukkit.Bukkit.getPlayer(arayan);
                    player.sendMessage(C.c("&bYUCECELL &8> &cAramayi reddettiniz."));
                    if (arayP != null) arayP.sendMessage(C.c("&bYUCECELL &8> &c" + player.getName() + " aramayi reddetti."));
                    data.busyWith.remove(uuid);
                    data.busyWith.remove(arayan);
                } else {
                    player.sendMessage(C.c("&bYUCECELL &8> &cGorusme sirasinda reddedemezsiniz. /telefonarakapat kullanin."));
                }
            }
            case "telefonarakapat" -> {
                java.util.UUID diger = data.busyWith.get(uuid);
                if (diger != null) {
                    org.bukkit.entity.Player digerP = org.bukkit.Bukkit.getPlayer(diger);
                    data.inCall.remove(uuid);
                    data.inCall.remove(diger);
                    data.busyWith.remove(uuid);
                    data.busyWith.remove(diger);
                    player.sendMessage(C.c("&bYUCECELL &8> &c&lGorusme Bitti: &7Siz kapattiniz."));
                    if (digerP != null) digerP.sendMessage(C.c("&bYUCECELL &8> &c&lGorusme Bitti: &e" + player.getName() + " &7kapatti."));
                }
            }
            case "sohbettemizle" -> {
                if (!player.isOp()) { player.sendMessage(C.c("&c[CHAT] &7Bu komutu kullanma yetkin yok!")); return true; }
                org.bukkit.Bukkit.broadcastMessage(C.c("&8&l[SOHBET] &e" + player.getName() + " &7sohbeti temizledi."));
                for (int i = 0; i < 100; i++) org.bukkit.Bukkit.broadcastMessage("");
                org.bukkit.Bukkit.broadcastMessage(C.c("&a&l[SOHBET] &7Temizlendi!"));
            }

            // ==================== MARKET ====================
            case "market" -> marketGui.openMarket(player);
            case "marketiptal" -> {
                data.marketWaitingPrice.remove(uuid);
                data.marketWaitingAmount.remove(uuid);
                data.marketBuyConfirm.remove(uuid);
                ItemStack pending = data.marketPendingItem.remove(uuid);
                if (pending != null) player.getInventory().addItem(pending);
                Integer pendingSlot = data.marketPendingSlot.remove(uuid);
                if (pendingSlot != null) data.marketReserved.remove(pendingSlot);
                data.marketPendingCurrency.remove(uuid);
                player.sendMessage(C.c("&c[MARKET] &7İptal edildi."));
            }

            // ==================== OYUNDAN ÇIK ====================
            case "oyundancik" -> quitManager.quitAllGames(player);

            // ==================== ADMİN ====================
            case "herkesoyundancik" -> {
                if (!player.isOp()) { player.sendMessage(C.c("&cBu komutu kullanma yetkin yok!")); return true; }
                quitManager.evictAll();
                player.sendMessage(C.c("&a&l[SİSTEM] &7Tüm oyuncular oyundan çıkarıldı."));
            }
            case "yetkilioyundancikar" -> {
                if (!player.isOp()) { player.sendMessage(C.c("&cBu komutu kullanma yetkin yok!")); return true; }
                if (args.length < 1) { player.sendMessage(C.c("&cKullanım: /yetkilioyundancikar <oyuncu>")); return true; }
                Player target = Bukkit.getPlayerExact(args[0]);
                if (target == null) { player.sendMessage(C.c("&c" + args[0] + " çevrimiçi değil!")); return true; }
                quitManager.quitAllGames(target);
                player.sendMessage(C.c("&a[YETKİLİ] &f" + target.getName() + " &7oyundan çıkarıldı."));
            }

            default -> { return false; }
        }
        return true;
    }

    private String capitalize(String s) {
        if (s == null || s.isEmpty()) return s;
        return Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }

    private void removeItems(Player player, org.bukkit.Material mat, int amount) {
        ItemStack[] contents = player.getInventory().getContents();
        int remaining = amount;
        for (int i = 0; i < contents.length && remaining > 0; i++) {
            ItemStack s = contents[i];
            if (s != null && s.getType() == mat) {
                int take = Math.min(s.getAmount(), remaining);
                s.setAmount(s.getAmount() - take);
                remaining -= take;
                if (s.getAmount() <= 0) player.getInventory().setItem(i, null);
            }
        }
    }

    private void giveEmeralds(Player player, int amount) {
        while (amount > 0) {
            int stack = Math.min(64, amount);
            player.getInventory().addItem(new ItemStack(org.bukkit.Material.EMERALD, stack));
            amount -= stack;
        }
    }
}
