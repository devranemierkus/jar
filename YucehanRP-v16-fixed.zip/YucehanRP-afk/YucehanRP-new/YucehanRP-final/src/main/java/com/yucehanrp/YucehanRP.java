package com.yucehanrp;

import com.yucehanrp.commands.CommandManager;
import com.yucehanrp.listeners.*;
import com.yucehanrp.managers.*;
import org.bukkit.command.PluginCommand;
import com.yucehanrp.util.C;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Map;
import java.util.UUID;

public class YucehanRP extends JavaPlugin {

    private static YucehanRP instance;

    // Veri
    private SessionData data;

    // Manager'lar
    private InventoryManager invManager;
    private GameHeadManager headManager;
    private PhoneManager phoneManager;
    private CryptoManager cryptoManager;
    private MarketManager marketManager;
    private MarketGUIManager marketGUIManager;
    private GamesMenuManager gamesMenuManager;
    private PvpSumoManager pvpSumoManager;
    private MiniGamesManager miniGamesManager;
    private KatilKimManager katilKimManager;
    private BedWarsManager bedWarsManager;
    private GameQuitManager gameQuitManager;
    private SchedulerManager schedulerManager;
    private CommandManager commandManager;
    private BedWarsListener bedWarsListener;
    private DcSaveManager dcSaveManager;

    @Override
    public void onEnable() {
        instance = this;
        getLogger().info("=== YucehanRP v16 baslatiliyor... ===");

        // Veri katmanı
        data = new SessionData();


        // DC Save sistemi (GZIP+BLOB)
        dcSaveManager = new DcSaveManager(this);

        // Manager'ları başlat
        invManager = new InventoryManager(data, this);
        headManager = new GameHeadManager(data);
        phoneManager = new PhoneManager(data);
        cryptoManager = new CryptoManager(data);
        marketManager = new MarketManager(data);
        marketGUIManager = new MarketGUIManager(data, marketManager);
        pvpSumoManager = new PvpSumoManager(data, invManager, headManager);
        miniGamesManager = new MiniGamesManager(data, invManager, headManager);
        katilKimManager = new KatilKimManager(data, invManager, headManager);
        bedWarsManager = new BedWarsManager(data, invManager, headManager);
        gamesMenuManager = new GamesMenuManager(data, headManager);
        gameQuitManager = new GameQuitManager(data, invManager, headManager, pvpSumoManager,
                miniGamesManager, katilKimManager, bedWarsManager);

        // Komutlar
        commandManager = new CommandManager(this, data, invManager, headManager, phoneManager,
                cryptoManager, marketManager, marketGUIManager, gamesMenuManager, gameQuitManager,
                katilKimManager, bedWarsManager);
        commandManager.registerAll();

        // Listener'ları kaydet
        Bukkit.getPluginManager().registerEvents(
                new ConnectionListener(this, data, invManager, headManager, gameQuitManager, dcSaveManager, marketManager), this);
        Bukkit.getPluginManager().registerEvents(
                new ChatListener(data, marketManager, marketGUIManager, phoneManager), this);
        Bukkit.getPluginManager().registerEvents(
                new InventoryClickListener(data, gamesMenuManager, pvpSumoManager, miniGamesManager,
                        katilKimManager, bedWarsManager, headManager, marketManager, marketGUIManager), this);
        Bukkit.getPluginManager().registerEvents(
                new CombatListener(data, invManager, headManager, pvpSumoManager, katilKimManager, bedWarsManager), this);
        Bukkit.getPluginManager().registerEvents(
                new PlayerInteractListener(data, headManager, gamesMenuManager, miniGamesManager, invManager), this);

        // BedWars blok + mağaza
        bedWarsListener = new BedWarsListener(this, data, bedWarsManager, invManager, headManager);
        Bukkit.getPluginManager().registerEvents(bedWarsListener, this);
        PluginCommand bwCmd = getCommand("bwmagaza");
        if (bwCmd != null) bwCmd.setExecutor(bedWarsListener);

        // BW yataklarını başlat (.sk on load: BW sıfırla)
        data.bwActive = false;
        data.bwCountdownActive = false;
        data.bwLobbyQueue.clear();
        data.bwPlacedBlocks.clear();
        data.bwBedAlive.put("kirmizi", true);
        data.bwBedAlive.put("mavi", true);
        data.bwBedAlive.put("sari", true);
        data.bwBedAlive.put("yesil", true);

        // .sk on load: IP sayılarını sıfırla
        data.ipCount.clear();

        // Kripto borsa ilk değerleri (.sk: borsaGuncelle() on load)
        cryptoManager.updatePrices();

        getLogger().info("[YucehanRP] IP limitleri başarıyla sıfırlandı.");
        getLogger().info("[YucehanRP] BW verileri temizlendi.");

        // Periyodik görevleri başlat
        schedulerManager = new SchedulerManager(this, data, phoneManager, cryptoManager,
                marketManager, miniGamesManager, headManager, bedWarsManager);
        schedulerManager.startAll();

        getLogger().info("=== YucehanRP v15 hazir! ===");
        getLogger().info("IP limiti, telefon, kripto, market, 7 oyun aktif.");
    }

    @Override
    public void onDisable() {
        getLogger().info("=== YucehanRP kapaniyor... ===");

        // Stop/restart: oyundaki tüm oyuncular için batch DC kayıt (async, SHA-1 korumalı)
        if (dcSaveManager != null && invManager != null) {
            Map<UUID, DcSaveManager.SaveRequest> batch = new java.util.HashMap<>();
            for (org.bukkit.entity.Player p : Bukkit.getOnlinePlayers()) {
                if (invManager.isInvSaved(p)) {
                    org.bukkit.inventory.ItemStack[] inv   = invManager.getSavedInventory(p);
                    org.bukkit.inventory.ItemStack[] armor = invManager.getSavedArmor(p);
                    if (inv != null && armor != null) {
                        batch.put(p.getUniqueId(), new DcSaveManager.SaveRequest(inv, armor));
                    }
                }
            }
            if (!batch.isEmpty()) {
                getLogger().info("[YucehanRP] " + batch.size() + " oyuncu icin DC kaydi basliyor...");
                dcSaveManager.saveBatch(batch);
                getLogger().info("[YucehanRP] DC batch kaydi tamamlandi.");
            }
        }

        // .sk on skript stop: katilKimArenaTemizle + BW temizlik + herkesOyundanCikHepsi
        if (katilKimManager != null) katilKimManager.arenaTemizle();
        if (bedWarsManager  != null) {
            bedWarsManager.bwItemTemizle();
            data.bwActive = false;
            data.bwCountdownActive = false;
            data.bwLobbyQueue.clear();
            data.bwBedAlive.clear();
            data.bwPlacedBlocks.clear();
        }
        if (gameQuitManager != null) gameQuitManager.evictAll();
        // KatilKim genel temizlik
        data.katilKimActive = false;
        data.katilKimLobbyCountdown = false;
        data.katilKimQueue.clear();
        data.katilKimPlayers.clear();
        data.katilKimSpectators.clear();

        getLogger().info("=== YucehanRP kapatildi. Tum oturum verisi temizlendi. ===");
    }

    public static YucehanRP getInstance() { return instance; }
    public SessionData getData() { return data; }
    public InventoryManager getInvManager() { return invManager; }
    public GameHeadManager getHeadManager() { return headManager; }
    public PhoneManager getPhoneManager() { return phoneManager; }
    public CryptoManager getCryptoManager() { return cryptoManager; }
    public BedWarsManager getBedWarsManager() { return bedWarsManager; }
    public KatilKimManager getKatilKimManager() { return katilKimManager; }
    public GameQuitManager getGameQuitManager() { return gameQuitManager; }
    public DcSaveManager getDcSaveManager() { return dcSaveManager; }
}
