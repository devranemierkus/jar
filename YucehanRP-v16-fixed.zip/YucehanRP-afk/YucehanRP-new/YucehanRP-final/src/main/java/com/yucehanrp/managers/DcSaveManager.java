package com.yucehanrp.managers;

import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.bukkit.util.io.BukkitObjectInputStream;
import org.bukkit.util.io.BukkitObjectOutputStream;

import java.io.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.*;
import java.util.concurrent.*;
import java.util.logging.Level;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

/**
 * DC durumunda envanteri diske kaydeder.
 *
 * Format (dosya yapısı):
 *   [4 byte: veri uzunluğu]
 *   [N byte: GZIP( BukkitObjectOutputStream { inv, armor } )]
 *   [20 byte: SHA-1 hash of the N bytes above]
 *
 * SHA-1 hash eşleşmezse dosya bozuk kabul edilir, crash recovery devreye girer.
 *
 * Async batch save: onDisable'da tüm oyuncuları aynı anda yazmak yerine
 * bir ExecutorService ile paralel yazılır, CountDownLatch ile tamamlanması beklenir.
 */
public class DcSaveManager {

    private static final int  BATCH_SIZE    = 20;   // aynı anda max yazılacak oyuncu sayısı
    private static final long SHUTDOWN_WAIT = 5_000; // ms — onDisable timeout

    private final File    saveDir;
    private final Plugin  plugin;

    public DcSaveManager(Plugin plugin) {
        this.plugin  = plugin;
        this.saveDir = new File(plugin.getDataFolder(), "dc_saves");
        if (!saveDir.exists()) saveDir.mkdirs();
    }

    // ════════════════════════════════════════════════════════
    // KAYDET — tek oyuncu (normal async çağrı)
    // ════════════════════════════════════════════════════════

    public void save(UUID uuid, ItemStack[] inv, ItemStack[] armor) {
        byte[] payload;
        try {
            payload = serialize(inv, armor);
        } catch (Exception e) {
            plugin.getLogger().log(Level.SEVERE, "[DcSave] Seri hata: " + uuid, e);
            return;
        }
        writeToDisk(uuid, payload);
    }

    // ════════════════════════════════════════════════════════
    // BATCH SAVE — onDisable için (async, timeout ile)
    // ════════════════════════════════════════════════════════

    /**
     * Birden fazla oyuncuyu BATCH_SIZE kadar paralel yazar.
     * onDisable'da çağrılmalı. SHUTDOWN_WAIT ms bekler; zaman aşımında
     * yazılamayan oyuncular için uyarı loglar.
     */
    public void saveBatch(Map<UUID, SaveRequest> requests) {
        if (requests.isEmpty()) return;

        List<Map.Entry<UUID, SaveRequest>> entries = new ArrayList<>(requests.entrySet());
        ExecutorService pool = Executors.newFixedThreadPool(
                Math.min(BATCH_SIZE, entries.size()));
        CountDownLatch latch = new CountDownLatch(entries.size());

        for (Map.Entry<UUID, SaveRequest> e : entries) {
            UUID uuid = e.getKey();
            SaveRequest req = e.getValue();
            pool.submit(() -> {
                try {
                    byte[] payload = serialize(req.inv, req.armor);
                    writeToDisk(uuid, payload);
                } catch (Exception ex) {
                    plugin.getLogger().log(Level.SEVERE,
                            "[DcSave] Batch kayıt hatası: " + uuid, ex);
                } finally {
                    latch.countDown();
                }
            });
        }

        pool.shutdown();
        try {
            boolean done = latch.await(SHUTDOWN_WAIT, TimeUnit.MILLISECONDS);
            if (!done) {
                plugin.getLogger().warning(
                    "[DcSave] Zaman asimi! " + latch.getCount() + " oyuncu kaydedilemedi.");
            }
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
        }
    }

    // ════════════════════════════════════════════════════════
    // YÜKLEMELaşım — SHA-1 kontrolü ile
    // ════════════════════════════════════════════════════════

    public SavedData load(UUID uuid) {
        File file = fileFor(uuid);
        if (!file.exists()) return null;

        try {
            byte[] raw = readAllBytes(file);

            // Format: [4 byte uzunluk][N byte payload][20 byte SHA-1]
            if (raw.length < 24) {
                plugin.getLogger().warning("[DcSave] Dosya cok kucuk, bozuk: " + uuid);
                return loadCorrupted(uuid);
            }

            int payloadLen = ((raw[0] & 0xFF) << 24) | ((raw[1] & 0xFF) << 16)
                           | ((raw[2] & 0xFF) <<  8) |  (raw[3] & 0xFF);

            if (raw.length != 4 + payloadLen + 20) {
                plugin.getLogger().warning("[DcSave] Boyut uyumsuz, bozuk: " + uuid);
                return loadCorrupted(uuid);
            }

            byte[] payload  = Arrays.copyOfRange(raw, 4, 4 + payloadLen);
            byte[] hashRead = Arrays.copyOfRange(raw, 4 + payloadLen, raw.length);
            byte[] hashCalc = sha1(payload);

            if (!Arrays.equals(hashRead, hashCalc)) {
                plugin.getLogger().warning("[DcSave] Hash eslesmiyor, dosya bozuk: " + uuid);
                return loadCorrupted(uuid);
            }

            return deserialize(payload);

        } catch (Exception e) {
            plugin.getLogger().log(Level.WARNING, "[DcSave] Yukleme hatasi: " + uuid, e);
            return loadCorrupted(uuid);
        }
    }

    /**
     * Bozuk dosya tespit edilince: dosyayı .corrupted olarak yeniden adlandır,
     * log at ve null dön (crash recovery devreye girer).
     */
    private SavedData loadCorrupted(UUID uuid) {
        File file = fileFor(uuid);
        File corrupted = new File(saveDir, uuid + ".corrupted");
        if (file.exists()) file.renameTo(corrupted);
        plugin.getLogger().severe(
            "[DcSave] Bozuk dosya yedeklendi: " + uuid + ".corrupted — crash recovery devreye girecek.");
        return null;
    }

    // ════════════════════════════════════════════════════════
    // YARDIMCI
    // ════════════════════════════════════════════════════════

    private byte[] serialize(ItemStack[] inv, ItemStack[] armor) throws Exception {
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        try (BukkitObjectOutputStream out =
                new BukkitObjectOutputStream(new GZIPOutputStream(b))) {
            out.writeInt(inv.length);
            for (ItemStack item : inv) out.writeObject(item);
            out.writeInt(armor.length);
            for (ItemStack item : armor) out.writeObject(item);
        }
        return b.toByteArray();
    }

    private SavedData deserialize(byte[] payload) throws Exception {
        ByteArrayInputStream b = new ByteArrayInputStream(payload);
        try (BukkitObjectInputStream in =
                new BukkitObjectInputStream(new GZIPInputStream(b))) {
            int invSize = in.readInt();
            ItemStack[] inv = new ItemStack[invSize];
            for (int i = 0; i < invSize; i++) inv[i] = (ItemStack) in.readObject();

            int armorSize = in.readInt();
            ItemStack[] armor = new ItemStack[armorSize];
            for (int i = 0; i < armorSize; i++) armor[i] = (ItemStack) in.readObject();

            return new SavedData(inv, armor);
        }
    }

    /** Dosyaya yaz: [4 byte len][payload][20 byte SHA-1] */
    private void writeToDisk(UUID uuid, byte[] payload) {
        File file = fileFor(uuid);
        try {
            byte[] hash = sha1(payload);
            try (FileOutputStream fos = new FileOutputStream(file);
                 DataOutputStream dos = new DataOutputStream(fos)) {
                dos.writeInt(payload.length);
                dos.write(payload);
                dos.write(hash);
            }
        } catch (Exception e) {
            plugin.getLogger().log(Level.SEVERE, "[DcSave] Disk yazma hatasi: " + uuid, e);
        }
    }

    private byte[] sha1(byte[] data) {
        try {
            return MessageDigest.getInstance("SHA-1").digest(data);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-1 yok?", e);
        }
    }

    private byte[] readAllBytes(File file) throws IOException {
        try (FileInputStream fis = new FileInputStream(file)) {
            return fis.readAllBytes();
        }
    }

    public void delete(UUID uuid) {
        File file = fileFor(uuid);
        if (file.exists()) file.delete();
    }

    public boolean hasSave(UUID uuid) {
        return fileFor(uuid).exists();
    }

    private File fileFor(UUID uuid) {
        return new File(saveDir, uuid.toString() + ".dat");
    }

    // ════════════════════════════════════════════════════════
    // VERİ SINIFLARI
    // ════════════════════════════════════════════════════════

    public static class SavedData {
        public final ItemStack[] inventory;
        public final ItemStack[] armor;
        public SavedData(ItemStack[] inventory, ItemStack[] armor) {
            this.inventory = inventory;
            this.armor     = armor;
        }
    }

    public static class SaveRequest {
        public final ItemStack[] inv;
        public final ItemStack[] armor;
        public SaveRequest(ItemStack[] inv, ItemStack[] armor) {
            this.inv   = inv;
            this.armor = armor;
        }
    }
}
