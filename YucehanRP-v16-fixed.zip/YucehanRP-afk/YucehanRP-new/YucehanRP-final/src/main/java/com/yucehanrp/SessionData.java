package com.yucehanrp;

import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.inventory.ItemStack;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Tüm oturum verilerini tutan merkezi sınıf.
 * Sunucu kapanınca tüm veriler silinir - kasıtlı olarak kalıcı değil.
 */
public class SessionData {

    // ==================== IP SİSTEMİ ====================
    public final Map<String, Integer> ipCount = new ConcurrentHashMap<>();

    // ==================== BATARYA & TELEFON ====================
    public final Map<UUID, Integer> battery = new ConcurrentHashMap<>();
    public final Map<UUID, Boolean> charging = new ConcurrentHashMap<>();
    public final Map<UUID, Boolean> calling = new ConcurrentHashMap<>();
    public final Map<UUID, UUID> busyWith = new ConcurrentHashMap<>();   // mesgul: kim ile konusuyor
    public final Map<UUID, Boolean> inCall = new ConcurrentHashMap<>();  // konusma
    // Ulaşım cooldown
    public final Map<UUID, Long> metroCooldown = new ConcurrentHashMap<>();
    public final Map<UUID, Long> otobusCooldown = new ConcurrentHashMap<>();
    public final Map<UUID, Long> seferCooldown = new ConcurrentHashMap<>();

    // PVP istatistikleri
    public final Map<UUID, Integer> pvpKills = new ConcurrentHashMap<>();
    public final Map<UUID, Integer> pvpDeaths = new ConcurrentHashMap<>();
    public final Map<UUID, Integer> pvpHits = new ConcurrentHashMap<>();

    // Telefon açık mı
    public final Map<UUID, Boolean> phoneOpen = new ConcurrentHashMap<>();

    // Telefon modeli maliyet: UUID -> maliyet (batarya/30sn)
    public final Map<UUID, Integer> phoneCost = new ConcurrentHashMap<>();
    // PC acik mi
    public final Map<UUID, Boolean> pcOpen = new ConcurrentHashMap<>();

    // ==================== KRIPTO ====================
    // kripto::fiyat::coin -> fiyat (Integer)
    public final Map<String, Integer> cryptoPrice = new ConcurrentHashMap<>();
    public final Map<String, String> cryptoArrow = new ConcurrentHashMap<>();
    // cuzdan::uuid::coin -> adet
    public final Map<String, Integer> cryptoWallet = new ConcurrentHashMap<>();
    // cooldown zamanlari
    public final Map<UUID, Long> cryptoBuyCooldown = new ConcurrentHashMap<>();
    public final Map<UUID, Long> cryptoSellCooldown = new ConcurrentHashMap<>();

    // ==================== ENVANTER KAYIT ====================
    public final Map<UUID, ItemStack[]> savedInventory = new ConcurrentHashMap<>();
    public final Map<UUID, ItemStack[]> savedArmor = new ConcurrentHashMap<>();
    public final Map<UUID, Boolean> invSaved = new ConcurrentHashMap<>();
    public final Map<UUID, GameMode> savedGameMode = new ConcurrentHashMap<>();

    // ==================== OYUNLAR ====================
    public final Map<UUID, Boolean> pvpMode = new ConcurrentHashMap<>();
    public final Map<UUID, Boolean> sumoMode = new ConcurrentHashMap<>();

    // Flappy Bird
    public final Map<UUID, Boolean> flappyActive = new ConcurrentHashMap<>();
    public final Map<UUID, Integer> flappyY = new ConcurrentHashMap<>();
    public final Map<UUID, Integer> flappyScore = new ConcurrentHashMap<>();
    public final Map<UUID, Integer> flappyTick = new ConcurrentHashMap<>();
    public final Map<UUID, Boolean> flappyFreeze = new ConcurrentHashMap<>();
    // Boru sistemi (sk: flappy.pipe.x / flappy.pipe.gap / flappy.freeze integer)
    public final Map<UUID, Integer> flappyPipeX = new ConcurrentHashMap<>();
    public final Map<UUID, Integer> flappyPipeGap = new ConcurrentHashMap<>();
    public final Map<UUID, Integer> flappyFreezeCount = new ConcurrentHashMap<>();

    // Snake
    public final Map<UUID, Boolean> snakeActive = new ConcurrentHashMap<>();
    public final Map<UUID, String> snakeDir = new ConcurrentHashMap<>();
    public final Map<UUID, Integer> snakeScore = new ConcurrentHashMap<>();
    public final Map<UUID, List<Integer>> snakeBody = new ConcurrentHashMap<>();
    public final Map<UUID, Integer> snakeFood = new ConcurrentHashMap<>();

    // Hedef Vurma
    public final Map<UUID, Boolean> targetActive = new ConcurrentHashMap<>();
    public final Map<UUID, Integer> targetScore = new ConcurrentHashMap<>();
    public final Map<UUID, Integer> targetTime = new ConcurrentHashMap<>();
    public final Map<UUID, Integer> targetSlot = new ConcurrentHashMap<>();
    public final Map<UUID, Integer> targetTick = new ConcurrentHashMap<>();

    // Simon Says
    public final Map<UUID, Boolean> simonActive = new ConcurrentHashMap<>();
    public final Map<UUID, Integer> simonScore = new ConcurrentHashMap<>();
    public final Map<UUID, String> simonExpected = new ConcurrentHashMap<>();
    public final Map<UUID, Boolean> simonTrap = new ConcurrentHashMap<>();
    public final Map<UUID, Integer> simonTime = new ConcurrentHashMap<>();

    // Reflex
    public final Map<UUID, Boolean> reflexActive = new ConcurrentHashMap<>();
    public final Map<UUID, Integer> reflexScore = new ConcurrentHashMap<>();
    public final Map<UUID, Integer> reflexTargetSlot = new ConcurrentHashMap<>();
    public final Map<UUID, Double> reflexTimeLeft = new ConcurrentHashMap<>();
    public final Map<UUID, Boolean> reflexTransition = new ConcurrentHashMap<>();

    // ==================== KATİL KİM ====================
    public boolean katilKimActive = false;
    public boolean katilKimLobbyCountdown = false;
    public int katilKimLobbyTime = 120;
    public int katilKimTime = 600; // 10 dakika
    public UUID katilKimKatil = null;
    public UUID katilKimSerif = null;
    public final List<UUID> katilKimQueue = new ArrayList<>();
    public final List<UUID> katilKimPlayers = new ArrayList<>();
    public final List<UUID> katilKimSpectators = new ArrayList<>();
    public final Map<UUID, String> katilKimRole = new ConcurrentHashMap<>(); // katil/serif/masum/lobi
    public final Map<UUID, Long> serifArrowCooldown = new ConcurrentHashMap<>();

    // ==================== BED WARS ====================
    public boolean bwActive = false;
    public boolean bwCountdownActive = false;
    public int bwTimeLeft = 600;
    public final Map<String, Boolean> bwBedAlive = new ConcurrentHashMap<>(); // kirmizi/mavi/sari/yesil -> alive
    public final List<UUID> bwLobbyQueue = new ArrayList<>();
    public final Map<UUID, String> bwTeam = new ConcurrentHashMap<>();   // UUID -> takim adı
    public final Map<UUID, Boolean> bwSpec = new ConcurrentHashMap<>();   // elenenler
    public final Map<UUID, Boolean> bwInLobby = new ConcurrentHashMap<>();
    public final Map<UUID, Boolean> bwPvpActive = new ConcurrentHashMap<>();
    public final Map<UUID, Integer> bwPvpHits = new ConcurrentHashMap<>();
    public final Map<UUID, Integer> bwRunnerCount = new ConcurrentHashMap<>();
    public final Map<UUID, Integer> bwAfkCount = new ConcurrentHashMap<>();
    public final Map<UUID, Double> bwPosX = new ConcurrentHashMap<>();
    public final Map<UUID, Double> bwPosZ = new ConcurrentHashMap<>();
    public final Map<UUID, Double> bwPrevPosX = new ConcurrentHashMap<>();
    public final Map<UUID, Double> bwPrevPosZ = new ConcurrentHashMap<>();
    public final Set<Location> bwPlacedBlocks = Collections.synchronizedSet(new HashSet<>());

    // ==================== MARKET ====================
    // slot 1-7
    public final Map<Integer, ItemStack> marketItem = new ConcurrentHashMap<>();
    public final Map<Integer, Integer> marketAmount = new ConcurrentHashMap<>();
    public final Map<Integer, Integer> marketPrice = new ConcurrentHashMap<>();
    public final Map<Integer, String> marketOwner = new ConcurrentHashMap<>();
    public final Map<Integer, Long> marketTime = new ConcurrentHashMap<>();
    public final Map<Integer, Boolean> marketReserved = new ConcurrentHashMap<>();
    public final Map<Integer, String> marketCurrency = new ConcurrentHashMap<>(); // zumrut/elmas
    // Player market state
    public final Map<UUID, ItemStack> marketPendingItem = new ConcurrentHashMap<>();
    public final Map<UUID, Integer> marketPendingAmount = new ConcurrentHashMap<>();
    public final Map<UUID, Integer> marketPendingSlot = new ConcurrentHashMap<>();
    public final Map<UUID, Boolean> marketWaitingPrice = new ConcurrentHashMap<>();
    public final Map<UUID, Boolean> marketWaitingAmount = new ConcurrentHashMap<>();
    public final Map<UUID, String> marketPendingCurrency = new ConcurrentHashMap<>();
    public final Map<UUID, Integer> marketBuyConfirm = new ConcurrentHashMap<>(); // slot bekleyen onay
    public final Map<UUID, Long> marketCooldown = new ConcurrentHashMap<>(); // 3 dakika cooldown
    // .sk: market.bekleyen.item — tezgah süresi dolunca çevrimdışı oyuncunun itemi
    public final Map<String, org.bukkit.inventory.ItemStack> marketBekleyenItem = new ConcurrentHashMap<>();
    public final Map<String, Integer> marketPendingElmas  = new ConcurrentHashMap<>(); // çevrimdışı ödeme
    public final Map<String, Integer> marketPendingZumrut = new ConcurrentHashMap<>();
    public final Map<UUID, Boolean>   marketRemoveConfirm = new ConcurrentHashMap<>();

    // ==================== CHAT SAYAÇLARI ====================
    public final Map<UUID, Integer> hakaretCount   = new ConcurrentHashMap<>();
    public final Map<UUID, Integer> reklamCount    = new ConcurrentHashMap<>();
    // Telefon: sessiz mod (msj ve arama yok) + rahatsız etme (sadece arama yok)
    public final java.util.Set<UUID> telefonSessiz       = java.util.Collections.newSetFromMap(new ConcurrentHashMap<>());
    public final java.util.Set<UUID> telefonRahatsizEtme = java.util.Collections.newSetFromMap(new ConcurrentHashMap<>());
    // Spam arama koruması: son arama zamanı
    public final Map<UUID, Long> aramaSpamCooldown = new ConcurrentHashMap<>();
    public final Map<UUID, Integer> bwHakaretCount = new ConcurrentHashMap<>();
    // AFK: son aktivite zamanı (hareket, chat, blok kırma)
    public final Map<UUID, Long> afkLastActivity   = new ConcurrentHashMap<>();

    // ==================== REHBER ====================
    public final Map<UUID, String> guideState = new ConcurrentHashMap<>();
    public final Map<UUID, Boolean> guideAccepted = new ConcurrentHashMap<>();

    // ==================== HACK MODU ====================
    public final Map<UUID, Boolean> hackMode = new ConcurrentHashMap<>();
    public final Map<UUID, String> hackPassword = new ConcurrentHashMap<>();

    // ==================== OYUN KAFASI ====================
    public static final String GAME_HEAD_NAME = "\u00a76\u00a7lOYUNLAR";

    // ==================== GLOBAl PREFIX'LER ====================
    public static final String YUCECELL_PREFIX = "\u00a7bYUCECELL \u00a78>";
    public static final String YUCECELL_LORE   = "\u00a78YUCECELL A.S. RESM\u0130 C\u0130HAZ";
    public static final String YUCECELL_NO_PHONE = "\u00a7c\u00a7lHATA: \u00a77Elinizde aktif bir \u00a7eYUCECELL \u00a77cihazi bulunamadi!";
    public static final String PVP_WEAPON_NAME = "\u00a7c\u00a7lS\u0130STEM";
    public static final String PVP_WEAPON_LORE = "\u00a78[PVP-KOPYALANAMAZ]||\u00a77Bu silah yalnizca PVP alanina ozgudur.";

    // ==================== YARDIMCI METODLAR ====================
    public boolean isInAnyGame(UUID uuid) {
        return pvpMode.containsKey(uuid)
                || sumoMode.containsKey(uuid)
                || flappyActive.containsKey(uuid)
                || snakeActive.containsKey(uuid)
                || targetActive.containsKey(uuid)
                || simonActive.containsKey(uuid)
                || reflexActive.containsKey(uuid)
                || katilKimRole.containsKey(uuid)
                || katilKimSpectators.contains(uuid)
                || bwTeam.containsKey(uuid)
                || bwSpec.containsKey(uuid)
                || bwInLobby.containsKey(uuid);
    }

    public void clearPlayerGameState(UUID uuid) {
        pvpMode.remove(uuid);
        sumoMode.remove(uuid);
        clearFlappy(uuid);
        clearSnake(uuid);
        clearTarget(uuid);
        clearSimon(uuid);
        clearReflex(uuid);
    }

    public void clearFlappy(UUID uuid) {
        flappyActive.remove(uuid);
        flappyY.remove(uuid);
        flappyScore.remove(uuid);
        flappyTick.remove(uuid);
        flappyFreeze.remove(uuid);
        flappyPipeX.remove(uuid);
        flappyPipeGap.remove(uuid);
        flappyFreezeCount.remove(uuid);
    }

    public void clearSnake(UUID uuid) {
        snakeActive.remove(uuid);
        snakeDir.remove(uuid);
        snakeScore.remove(uuid);
        snakeBody.remove(uuid);
        snakeFood.remove(uuid);
    }

    public void clearTarget(UUID uuid) {
        targetActive.remove(uuid);
        targetScore.remove(uuid);
        targetTime.remove(uuid);
        targetSlot.remove(uuid);
        targetTick.remove(uuid);
    }

    public void clearSimon(UUID uuid) {
        simonActive.remove(uuid);
        simonScore.remove(uuid);
        simonExpected.remove(uuid);
        simonTrap.remove(uuid);
        simonTime.remove(uuid);
    }

    public void clearReflex(UUID uuid) {
        reflexActive.remove(uuid);
        reflexScore.remove(uuid);
        reflexTargetSlot.remove(uuid);
        reflexTimeLeft.remove(uuid);
        reflexTransition.remove(uuid);
    }

    public void clearBwPlayer(UUID uuid) {
        bwTeam.remove(uuid);
        bwSpec.remove(uuid);
        bwInLobby.remove(uuid);
        bwPvpActive.remove(uuid);
        bwPvpHits.remove(uuid);
        bwRunnerCount.remove(uuid);
        bwAfkCount.remove(uuid);
        bwPosX.remove(uuid);
        bwPosZ.remove(uuid);
        bwPrevPosX.remove(uuid);
        bwPrevPosZ.remove(uuid);
    }

    public void clearKKPlayer(UUID uuid) {
        katilKimRole.remove(uuid);
        katilKimPlayers.remove(uuid);
        katilKimSpectators.remove(uuid);
        katilKimQueue.remove(uuid);
    }

    public String cryptoWalletKey(UUID uuid, String coin) {
        return uuid.toString() + ":" + coin;
    }

    public int getCryptoWallet(UUID uuid, String coin) {
        return cryptoWallet.getOrDefault(cryptoWalletKey(uuid, coin), 0);
    }

    public void addCryptoWallet(UUID uuid, String coin, int amount) {
        String key = cryptoWalletKey(uuid, coin);
        cryptoWallet.merge(key, amount, Integer::sum);
    }

    public void removeCryptoWallet(UUID uuid, String coin, int amount) {
        String key = cryptoWalletKey(uuid, coin);
        int current = cryptoWallet.getOrDefault(key, 0);
        int newVal = current - amount;
        if (newVal <= 0) cryptoWallet.remove(key);
        else cryptoWallet.put(key, newVal);
    }

    // ==================== ANTİ-CHEAT ====================
    // profesyonelGuvenlikKontrol — .sk sol/sag tıklama güvenlik
    public final Map<String, Float>   guvenlikYaw      = new ConcurrentHashMap<>();
    public final Map<String, Float>   guvenlikPitch    = new ConcurrentHashMap<>();
    public final Map<String, Long>    guvenlikZaman    = new ConcurrentHashMap<>();
    public final Map<String, Integer> guvenlikRobotik  = new ConcurrentHashMap<>();
    public final Map<String, Integer> guvenlikHiz      = new ConcurrentHashMap<>();

    // ==================== PLAYTIME TAKİBİ ====================
    // Oyuncunun bugün kaç ms oynadığı (gün bazlı, sıfırlanır)
    public final Map<UUID, Long> playtimeJoinMs   = new ConcurrentHashMap<>(); // giriş zamanı
    public final Map<UUID, Long> playtimeTodayMs  = new ConcurrentHashMap<>(); // bugünkü toplam ms
    public final Map<UUID, String> playtimeLastDay = new ConcurrentHashMap<>(); // son sayılan gün (yyyy-MM-dd)
    public final Map<UUID, Long> lastLoginDate    = new ConcurrentHashMap<>(); // son geçerli giriş (epoch ms)
}

