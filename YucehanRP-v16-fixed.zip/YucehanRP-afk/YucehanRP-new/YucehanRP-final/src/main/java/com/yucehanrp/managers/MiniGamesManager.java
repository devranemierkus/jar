package com.yucehanrp.managers;

import com.yucehanrp.SessionData;
import com.yucehanrp.util.C;
import com.yucehanrp.util.ItemUtil;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class MiniGamesManager {

    private final SessionData data;
    private final InventoryManager invManager;
    private final GameHeadManager headManager;
    private final Random rng = new Random();

    // Inventory referansları - her tick yeniden açılmaması için
    private final Map<UUID, Inventory> flappyInvs = new ConcurrentHashMap<>();
    private final Map<UUID, Inventory> snakeInvs  = new ConcurrentHashMap<>();
    private final Map<UUID, Inventory> targetInvs = new ConcurrentHashMap<>();
    private final Map<UUID, Inventory> reflexInvs = new ConcurrentHashMap<>();

    public MiniGamesManager(SessionData data, InventoryManager invManager, GameHeadManager headManager) {
        this.data = data;
        this.invManager = invManager;
        this.headManager = headManager;
    }

    // ==================== FLAPPY BIRD ====================
    // .sk ile birebir: 4-row (36 slot), rows 0-2=oyun, row 3=UI
    // Kuş: sütun 2, satır=birdY (0-2)
    // Boru: sütun=pipeX (8→-1), boşluk=pipeGap (0/1/2)
    // Her saniye: yerçekimi (birdY++) + boru ilerler (pipeX--)
    // pipeX==2 && birdY!=gap → game over
    // pipeX<0 → skor++, yeni boru
    // Zipla: birdY-=2, min 0
    // Freeze: 2 saniye başlangıçta bekle

    public void startFlappy(Player player) {
        UUID uuid = player.getUniqueId();
        if (data.isInAnyGame(uuid)) return;
        invManager.invKaydet(player);
        data.flappyActive.put(uuid, true);
        data.flappyY.put(uuid, 1);               // .sk: start Y=1
        data.flappyScore.put(uuid, 0);
        data.flappyPipeX.put(uuid, 8);            // .sk: pipe.x=8
        data.flappyPipeGap.put(uuid, rng.nextInt(3)); // .sk: random 0-2
        data.flappyFreezeCount.put(uuid, 2);      // .sk: freeze=2

        Inventory gui = Bukkit.createInventory(null, 36, "Flappy Bird");
        flappyInvs.put(uuid, gui);
        player.openInventory(gui);
        renderFlappy(player, gui);

        player.sendTitle(C.c("&b&lFLAPPY BIRD"), C.c("&7Slot 32 ile zipla!"), 10, 50, 10);
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.3f, 1f);
    }

    /** Mevcut inventory'yi çizer - YENİ INVENTORY AÇMAZ. */
    public void renderFlappy(Player player, Inventory gui) {
        UUID uuid = player.getUniqueId();
        int birdY = data.flappyY.getOrDefault(uuid, 1);
        int pipeX  = data.flappyPipeX.getOrDefault(uuid, 8);
        int gap    = data.flappyPipeGap.getOrDefault(uuid, 1);
        int score  = data.flappyScore.getOrDefault(uuid, 0);

        // Oyun alanı: slot 0-26 (satır 0-2, sütun 0-8)
        for (int slot = 0; slot < 27; slot++) {
            int row = slot / 9;
            int col = slot % 9;
            if (col == 2 && row == birdY) {
                // Kuş
                gui.setItem(slot, ItemUtil.make(Material.YELLOW_STAINED_GLASS_PANE, "&e&lKUŞ"));
            } else if (col == pipeX && row != gap) {
                // Boru
                gui.setItem(slot, ItemUtil.makeGlass(DyeColor.LIME, "&a&l[BORU]"));
            } else {
                // Gökyüzü
                gui.setItem(slot, ItemUtil.makeGlass(DyeColor.LIGHT_BLUE, " "));
            }
        }
        // UI satırı (slot 27-35)
        for (int s = 27; s < 36; s++)
            gui.setItem(s, ItemUtil.makeGlass(DyeColor.BLACK, " "));
        gui.setItem(27, ItemUtil.make(Material.PAPER, "&b&lSkor: &f" + score));
        gui.setItem(31, ItemUtil.make(Material.FEATHER, "&e&l^ ZİPLA"));
        gui.setItem(35, ItemUtil.make(Material.BARRIER, "&c&lCIKIS"));
    }

    /** Yenileme: dışarıdan GUI alınır (InventoryClickEvent veya Scheduler). */
    public void drawFlappy(Player player) {
        UUID uuid = player.getUniqueId();
        Inventory gui = flappyInvs.get(uuid);
        if (gui == null) return;
        renderFlappy(player, gui);
    }

    /** Her saniye çağrılır: freeze kontrolü + yerçekimi + boru. */
    public void tickFlappy(Player player) {
        UUID uuid = player.getUniqueId();
        if (!data.flappyActive.containsKey(uuid)) return;
        Inventory gui = flappyInvs.get(uuid);
        if (gui == null) { stopFlappy(player); return; }

        // Freeze kontrolü (.sk: if freeze set → decrement, redraw, return)
        int freeze = data.flappyFreezeCount.getOrDefault(uuid, 0);
        if (freeze > 0) {
            data.flappyFreezeCount.put(uuid, freeze - 1);
            renderFlappy(player, gui);
            return;
        }

        // Yerçekimi: birdY++
        int y = data.flappyY.getOrDefault(uuid, 1) + 1;
        data.flappyY.put(uuid, y);

        // Zemine çarpma
        if (y > 2) {
            flappyGameOver(player, "Zemine çarptın!");
            return;
        }

        // Boru ilerler
        int pipeX = data.flappyPipeX.getOrDefault(uuid, 8) - 1;
        data.flappyPipeX.put(uuid, pipeX);

        // Boru çarpışma (pipeX==2 == kuşun sütunu)
        if (pipeX == 2) {
            int gap = data.flappyPipeGap.getOrDefault(uuid, 1);
            if (y != gap) {
                flappyGameOver(player, "Boruya çarptın!");
                return;
            }
        }

        // Boru geçildi → yeni boru
        if (pipeX < 0) {
            data.flappyScore.merge(uuid, 1, Integer::sum);
            data.flappyPipeX.put(uuid, 8);
            data.flappyPipeGap.put(uuid, rng.nextInt(3));
            int sc = data.flappyScore.get(uuid);
            player.sendActionBar(C.c("&b&lFlappy &8| Skor: &f" + sc));
        }

        renderFlappy(player, gui);
    }

    /** Zipla komutu (InventoryClickListener'dan slot 31). */
    public void flappyJump(Player player) {
        UUID uuid = player.getUniqueId();
        if (data.flappyFreezeCount.getOrDefault(uuid, 0) > 0) return;
        int y = Math.max(0, data.flappyY.getOrDefault(uuid, 1) - 2); // .sk: remove 2, min 0
        data.flappyY.put(uuid, y);
        Inventory gui = flappyInvs.get(uuid);
        if (gui != null) renderFlappy(player, gui);
        player.playSound(player.getLocation(), Sound.ENTITY_FIREWORK_ROCKET_LAUNCH, 0.2f, 2f);
    }

    private void flappyGameOver(Player player, String msg) {
        int score = data.flappyScore.getOrDefault(player.getUniqueId(), 0);
        stopFlappy(player);
        player.sendTitle(C.c("&c&lOYUN BİTTİ!"), C.c("&7" + msg + " | Skor: " + score), 10, 70, 20);
        player.sendMessage(C.c("&b&l[FLAPPY] &7Bitti! Skor: &f" + score));
        player.playSound(player.getLocation(), Sound.ENTITY_WITHER_DEATH, 0.3f, 1f);
    }

    public void stopFlappy(Player player) {
        UUID uuid = player.getUniqueId();
        flappyInvs.remove(uuid);
        data.clearFlappy(uuid);
        player.closeInventory();
        invManager.invGeriYukle(player);
        headManager.giveGameHead(player);
    }

    // ==================== SNAKE ====================
    // .sk: 4-row (36 slot), oyun alanı 27 slot (3 satır), kontroller row 3
    // Her saniye (20 tick) oyun ilerler.
    // Java versiyonu: 36 slot, oyun alanı 27, kontroller 27-35

    public void startSnake(Player player) {
        UUID uuid = player.getUniqueId();
        if (data.isInAnyGame(uuid)) return;
        invManager.invKaydet(player);
        data.snakeActive.put(uuid, true);
        data.snakeDir.put(uuid, "r");
        data.snakeScore.put(uuid, 0);
        List<Integer> body = new ArrayList<>();
        body.add(13); body.add(12); // .sk: add 13 to body, add 12 to body
        data.snakeBody.put(uuid, body);
        data.snakeFood.put(uuid, randomFreeSnakeSlot(body));

        Inventory gui = Bukkit.createInventory(null, 36, "Yilan Oyunu");
        snakeInvs.put(uuid, gui);
        player.openInventory(gui);
        renderSnake(player, gui);

        player.sendTitle(C.c("&2&lYILAN OYUNU"), C.c("&7Butonlarla yön ver!"), 10, 60, 20);
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.3f, 1f);
    }

    private int randomFreeSnakeSlot(List<Integer> occupied) {
        int slot;
        do { slot = rng.nextInt(27); } while (occupied.contains(slot));
        return slot;
    }

    private void renderSnake(Player player, Inventory gui) {
        UUID uuid = player.getUniqueId();
        List<Integer> body = data.snakeBody.getOrDefault(uuid, new ArrayList<>());
        int food  = data.snakeFood.getOrDefault(uuid, 0);
        int score = data.snakeScore.getOrDefault(uuid, 0);

        // Oyun alanı (0-26)
        for (int i = 0; i < 27; i++)
            gui.setItem(i, ItemUtil.makeGlass(DyeColor.BLACK, " "));

        if (food >= 0 && food < 27)
            gui.setItem(food, ItemUtil.make(Material.RED_CONCRETE, "&c[YEM]"));

        for (int s : body)
            if (s >= 0 && s < 27)
                gui.setItem(s, ItemUtil.makeGlass(DyeColor.LIME, "&aYILAN"));

        if (!body.isEmpty())
            gui.setItem(body.get(0), ItemUtil.make(Material.GREEN_CONCRETE, "&2&l[BAS]"));

        // Kontroller satırı (27-35)
        for (int s = 27; s < 36; s++)
            gui.setItem(s, ItemUtil.makeGlass(DyeColor.GRAY, " "));
        gui.setItem(27, ItemUtil.make(Material.PAPER, "&a&lSkor: &f" + score));
        gui.setItem(29, ItemUtil.make(Material.ARROW, "&e< SOL"));
        gui.setItem(30, ItemUtil.make(Material.ARROW, "&ev ASAGI"));
        gui.setItem(31, ItemUtil.make(Material.ARROW, "&e^ YUKARI"));
        gui.setItem(32, ItemUtil.make(Material.ARROW, "&e> SAG"));
        gui.setItem(35, ItemUtil.make(Material.BARRIER, "&c&lCIKIS"));
    }

    /** Her tick çağrılır (scheduler). */
    public void tickSnake(Player player) {
        UUID uuid = player.getUniqueId();
        if (!data.snakeActive.containsKey(uuid)) return;
        Inventory gui = snakeInvs.get(uuid);
        if (gui == null) { stopSnake(player); return; }

        String dir = data.snakeDir.getOrDefault(uuid, "r");
        List<Integer> body = data.snakeBody.getOrDefault(uuid, new ArrayList<>());
        if (body.isEmpty()) return;

        int head = body.get(0);
        int row = head / 9;
        int col = head % 9;

        int newHead = switch (dir) {
            case "r" -> (col >= 8) ? -1 : head + 1;
            case "l" -> (col <= 0) ? -1 : head - 1;
            case "u" -> (row <= 0) ? -1 : head - 9;
            case "d" -> (row >= 2) ? -1 : head + 9; // 3 satır (0-2)
            default  -> -1;
        };

        if (newHead < 0 || newHead >= 27 || body.contains(newHead)) {
            snakeGameOver(player);
            return;
        }

        body.add(0, newHead);
        int food = data.snakeFood.getOrDefault(uuid, -1);
        if (newHead == food) {
            data.snakeScore.merge(uuid, 1, Integer::sum);
            data.snakeFood.put(uuid, randomFreeSnakeSlot(body));
            int sc = data.snakeScore.get(uuid);
            player.sendActionBar(C.c("&2&lYILAN | Skor: &f" + sc));
        } else {
            body.remove(body.size() - 1);
        }
        data.snakeBody.put(uuid, body);
        renderSnake(player, gui);
    }

    public void drawSnake(Player player) {
        UUID uuid = player.getUniqueId();
        Inventory gui = snakeInvs.get(uuid);
        if (gui == null) return;
        renderSnake(player, gui);
    }

    private void snakeGameOver(Player player) {
        int score = data.snakeScore.getOrDefault(player.getUniqueId(), 0);
        stopSnake(player);
        player.sendTitle(C.c("&c&lOYUN BİTTİ!"), C.c("&7Skor: " + score), 10, 70, 20);
        player.sendMessage(C.c("&2&l[YILAN] &7Oyun bitti! Skor: &f" + score));
        player.playSound(player.getLocation(), Sound.ENTITY_WITHER_DEATH, 0.3f, 1f);
    }

    public void stopSnake(Player player) {
        UUID uuid = player.getUniqueId();
        snakeInvs.remove(uuid);
        data.clearSnake(uuid);
        player.closeInventory();
        invManager.invGeriYukle(player);
        headManager.giveGameHead(player);
    }

    /** InventoryClickListener'dan çağrılır. */
    public Inventory getSnakeInv(UUID uuid) { return snakeInvs.get(uuid); }
    public Inventory getFlappyInv(UUID uuid) { return flappyInvs.get(uuid); }

    // ==================== RENK EŞLEŞTİRME ====================
    // Reflex'ten farklı: ortada hedef renk gösterilir, kenarda o rengi bul ve tıkla
    // Yanlış tıklayınca -1 puan, doğruysa +1

    private static final DyeColor[] RENKLER = {
        DyeColor.RED, DyeColor.BLUE, DyeColor.YELLOW, DyeColor.GREEN,
        DyeColor.ORANGE, DyeColor.PURPLE, DyeColor.CYAN, DyeColor.PINK
    };

    private String renkAdi(DyeColor c) {
        return switch (c) {
            case RED    -> "&c&lKIRMIZI";
            case BLUE   -> "&9&lMAVİ";
            case YELLOW -> "&e&lSARI";
            case GREEN  -> "&a&lYEŞİL";
            case ORANGE -> "&6&lTURUNCU";
            case PURPLE -> "&5&lMOR";
            case CYAN   -> "&b&lCYAN";
            case PINK   -> "&d&lPEMBE";
            default     -> "&f&l?";
        };
    }

    public void startTarget(Player player) {
        UUID uuid = player.getUniqueId();
        if (data.isInAnyGame(uuid)) return;
        invManager.invKaydet(player);
        data.targetActive.put(uuid, true);
        data.targetScore.put(uuid, 0);
        data.targetTime.put(uuid, 45);
        data.targetTick.put(uuid, 0);
        // Cached inventory oluştur, sadece bir kez aç
        Inventory gui = Bukkit.createInventory(null, 54, C.c("Renk Eslestirme"));
        targetInvs.put(uuid, gui);
        player.openInventory(gui);
        newTargetRound(player);
        player.sendMessage(C.c("&e&l[RENK EŞLEŞTİR] &7Ortadaki rengi bul ve tıkla! Yanlış = -1 puan!"));
    }

    private void newTargetRound(Player player) {
        UUID uuid = player.getUniqueId();
        int hedefIdx = rng.nextInt(RENKLER.length);
        data.targetSlot.put(uuid, hedefIdx);
        int dogruSlot = rng.nextInt(45);
        data.targetTick.put(uuid, dogruSlot);
        renderTarget(player);
    }

    private void renderTarget(Player player) {
        UUID uuid = player.getUniqueId();
        Inventory gui = targetInvs.get(uuid);
        if (gui == null) return;
        int score     = data.targetScore.getOrDefault(uuid, 0);
        int time      = data.targetTime.getOrDefault(uuid, 0);
        int hedefIdx  = data.targetSlot.getOrDefault(uuid, 0);
        int dogruSlot = data.targetTick.getOrDefault(uuid, 0);
        DyeColor hedefRenk = RENKLER[hedefIdx % RENKLER.length];

        for (int i = 0; i < 45; i++) {
            if (i == dogruSlot) {
                gui.setItem(i, ItemUtil.makeGlass(hedefRenk, "&a&lTIKLA!"));
            } else {
                DyeColor r;
                do { r = RENKLER[rng.nextInt(RENKLER.length)]; } while (r == hedefRenk);
                gui.setItem(i, ItemUtil.makeGlass(r, "&7·"));
            }
        }
        gui.setItem(45, ItemUtil.makeGlass(DyeColor.BLACK, ""));
        gui.setItem(46, ItemUtil.makeGlass(DyeColor.BLACK, ""));
        gui.setItem(47, ItemUtil.makeGlass(DyeColor.BLACK, ""));
        gui.setItem(48, ItemUtil.make(Material.BOOK, "&6Skor: &f" + score + (score < 0 ? " &c(dikkat!)" : "")));
        gui.setItem(49, ItemUtil.makeGlass(hedefRenk, renkAdi(hedefRenk) + " &7rengi bul!"));
        gui.setItem(50, ItemUtil.make(Material.CLOCK, "&eSure: &f" + time + "sn"));
        gui.setItem(51, ItemUtil.makeGlass(DyeColor.BLACK, ""));
        gui.setItem(52, ItemUtil.makeGlass(DyeColor.BLACK, ""));
        gui.setItem(53, ItemUtil.make(Material.BARRIER, "&c&lCIKIS"));
    }

    public void drawTarget(Player player) {
        renderTarget(player);
    }

    public void hitTarget(Player player) {
        UUID uuid = player.getUniqueId();
        // hitTarget = doğru renk tıklandı
        data.targetScore.merge(uuid, 1, Integer::sum);
        int score = data.targetScore.get(uuid);
        player.sendActionBar(C.c("&a&lDOĞRU! Skor: &f" + score));
        player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.7f, 2f);
        newTargetRound(player);
    }

    public void hitTargetWrong(Player player) {
        UUID uuid = player.getUniqueId();
        // Yanlış renk tıklandı: puan düşür
        data.targetScore.merge(uuid, -1, Integer::sum);
        int score = data.targetScore.get(uuid);
        player.sendActionBar(C.c("&c&lYANLIŞ! -1 Skor: &f" + score));
        player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 0.8f, 0.5f);
        newTargetRound(player);
    }

    public void tickTarget(Player player) {
        UUID uuid = player.getUniqueId();
        int time = data.targetTime.getOrDefault(uuid, 0) - 1;
        data.targetTime.put(uuid, time);
        if (time <= 0) {
            endTarget(player);
        } else {
            // Süre azaldıkça renkleri yenile (baskı hissi)
            int score = data.targetScore.getOrDefault(uuid, 0);
            // Her 3-8 saniyede bir renkleri yenile (skor arttıkça hızlanır)
            // tick sayacı burada yok, sadece her saniye drawTarget çağır
            if (time <= 3) player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_HAT, 0.5f, 2f);
            drawTarget(player);
        }
    }

    public void endTarget(Player player) {
        UUID uuid = player.getUniqueId();
        int score = data.targetScore.getOrDefault(uuid, 0);
        targetInvs.remove(uuid);
        data.clearTarget(uuid);
        player.closeInventory();
        invManager.invGeriYukle(player);
        headManager.giveGameHead(player);
        String dereceMsg = score >= 20 ? "&6&lEFSANE!" : score >= 10 ? "&a&lİYİ!" : score >= 0 ? "&e&lFENA DEĞİL" : "&c&lÇOK YEŞİL!";
        player.sendTitle(C.c("&c&lSURE BİTTİ!"), C.c(dereceMsg + " &7Skor: &f" + score), 10, 70, 20);
        player.sendMessage(C.c("&e&l[RENK EŞLEŞTİR] &7Oyun bitti! Skor: &f" + score));
    }

    public void stopTarget(Player player) {
        UUID uuid = player.getUniqueId();
        targetInvs.remove(uuid);
        data.clearTarget(uuid);
        player.closeInventory();
        invManager.invGeriYukle(player);
        headManager.giveGameHead(player);
    }

    // ==================== SIMON SAYS ====================
    public void startSimon(Player player) {
        UUID uuid = player.getUniqueId();
        if (data.isInAnyGame(uuid)) return;
        invManager.invKaydet(player);
        data.simonActive.put(uuid, true);
        data.simonScore.put(uuid, 0);
        player.sendTitle(C.c("&d&l&oSIMON SAYS"), C.c("&7Hazir ol..."), 10, 50, 10);
        player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 0.6f, 1f);
        Bukkit.getScheduler().runTaskLater(Bukkit.getPluginManager().getPlugin("YucehanRP"),
                () -> { if (data.simonActive.containsKey(uuid)) newSimonCommand(player); }, 30L);
    }

    public void newSimonCommand(Player player) {
        UUID uuid = player.getUniqueId();
        if (!data.simonActive.containsKey(uuid)) return;
        data.simonExpected.remove(uuid);
        data.simonTrap.remove(uuid);
        String[] cmds = {"ZIPLA", "EGIL", "VUR", "HAREKET"};
        String cmd = cmds[rng.nextInt(4)];
        data.simonExpected.put(uuid, cmd);
        int score = data.simonScore.getOrDefault(uuid, 0);
        boolean trap = score >= 5 && rng.nextInt(10) < 3;
        if (trap) data.simonTrap.put(uuid, true);
        data.simonTime.put(uuid, 3);
        showSimonCommand(player);
    }

    private void showSimonCommand(Player player) {
        UUID uuid = player.getUniqueId();
        String cmd = data.simonExpected.getOrDefault(uuid, "ZIPLA");
        int score  = data.simonScore.getOrDefault(uuid, 0);
        boolean trap = data.simonTrap.containsKey(uuid);
        if (trap) {
            player.sendTitle(C.c("&8&o( Simon demedi )"), C.c("&e&l" + cmd), 5, 40, 5);
            player.sendActionBar(C.c("&7Dikkat! Yapma! Sure: &c3"));
            player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 0.5f, 0.8f);
        } else {
            player.sendTitle(C.c("&d&lSIMON SAYS:"), C.c("&a&l" + cmd), 5, 40, 5);
            player.sendActionBar(C.c("&eSkor: &f" + score + " &8| Sure: &c3"));
            player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BELL, 0.7f, 2f);
        }
    }

    public void simonAction(Player player, String action) {
        UUID uuid = player.getUniqueId();
        if (!data.simonActive.containsKey(uuid)) return;
        if (!data.simonExpected.containsKey(uuid)) return;
        if (data.simonTrap.containsKey(uuid)) { simonLose(player, "Tuzaga dustun!"); return; }
        if (action.equals(data.simonExpected.get(uuid))) simonCorrect(player);
        else simonLose(player, "Yanlis hareket!");
    }

    private void simonCorrect(Player player) {
        UUID uuid = player.getUniqueId();
        data.simonScore.merge(uuid, 1, Integer::sum);
        data.simonExpected.remove(uuid);
        data.simonTrap.remove(uuid);
        int score = data.simonScore.get(uuid);
        player.sendActionBar(C.c("&a&lDOGRU! &8| Skor: &f" + score));
        player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.7f, 2f);
        Bukkit.getScheduler().runTaskLater(Bukkit.getPluginManager().getPlugin("YucehanRP"),
                () -> { if (data.simonActive.containsKey(uuid)) newSimonCommand(player); }, 8L);
    }

    private void simonLose(Player player, String reason) {
        int score = data.simonScore.getOrDefault(player.getUniqueId(), 0);
        data.clearSimon(player.getUniqueId());
        invManager.invGeriYukle(player);
        headManager.giveGameHead(player);
        player.sendTitle(C.c("&c&lKAYBETTİN!"), C.c("&7Skor: " + score), 10, 70, 20);
        player.sendMessage(C.c("&d&l[SIMON] &7Bitti! Skor: &f" + score + " | " + reason));
        player.playSound(player.getLocation(), Sound.ENTITY_WITHER_DEATH, 0.3f, 1f);
    }

    public void tickSimon(Player player) {
        UUID uuid = player.getUniqueId();
        if (!data.simonActive.containsKey(uuid)) return;
        if (!data.simonExpected.containsKey(uuid)) return;
        int time = data.simonTime.getOrDefault(uuid, 3) - 1;
        data.simonTime.put(uuid, time);
        if (time <= 0) {
            if (data.simonTrap.containsKey(uuid)) simonCorrect(player);
            else simonLose(player, "Sure bitti!");
        } else if (time == 1) {
            player.sendActionBar(C.c("&c&l!!! 1 SANIYE !!!"));
            player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_HAT, 0.6f, 2f);
        }
    }

    public void stopSimon(Player player) {
        data.clearSimon(player.getUniqueId());
        invManager.invGeriYukle(player);
        headManager.giveGameHead(player);
    }

    // ==================== REFLEX ====================
    public void startReflex(Player player) {
        UUID uuid = player.getUniqueId();
        if (data.isInAnyGame(uuid)) return;
        invManager.invKaydet(player);
        data.reflexActive.put(uuid, true);
        data.reflexScore.put(uuid, 0);
        data.reflexTimeLeft.put(uuid, 3.0);
        // Cached inventory — sadece bir kez aç
        Inventory gui = Bukkit.createInventory(null, 54, C.c("Reflex Oyunu"));
        reflexInvs.put(uuid, gui);
        player.openInventory(gui);
        newReflexTarget(player);
    }

    private void newReflexTarget(Player player) {
        UUID uuid = player.getUniqueId();
        data.reflexTargetSlot.put(uuid, rng.nextInt(45));
        int score = data.reflexScore.getOrDefault(uuid, 0);
        double maxTime = Math.max(0.5, 3.0 - (score / 3) * 0.5);
        data.reflexTimeLeft.put(uuid, maxTime);
        data.reflexTransition.put(uuid, true);
        // Ekranı boşalt (kısa transition efekti)
        Inventory gui = reflexInvs.get(uuid);
        if (gui != null) {
            for (int i = 0; i < 54; i++) gui.setItem(i, ItemUtil.makeGlass(DyeColor.BLACK, " "));
        }
        Bukkit.getScheduler().runTaskLater(Bukkit.getPluginManager().getPlugin("YucehanRP"), () -> {
            data.reflexTransition.remove(uuid);
            drawReflex(player);
        }, 2L);
    }

    public void drawReflex(Player player) {
        UUID uuid = player.getUniqueId();
        if (!data.reflexActive.containsKey(uuid)) return;
        Inventory gui = reflexInvs.get(uuid);
        if (gui == null) return;
        int score    = data.reflexScore.getOrDefault(uuid, 0);
        double tLeft = data.reflexTimeLeft.getOrDefault(uuid, 3.0);
        int tSlot    = data.reflexTargetSlot.getOrDefault(uuid, 0);
        for (int i = 0; i < 45; i++) {
            gui.setItem(i, i == tSlot
                    ? ItemUtil.makeGlass(DyeColor.LIME, "&a&lTIKLA!")
                    : ItemUtil.makeGlass(DyeColor.RED, "·"));
        }
        gui.setItem(49, ItemUtil.make(Material.BOOK, "&6&lSkor: &f" + score));
        gui.setItem(50, ItemUtil.make(Material.CLOCK, "&e&lSure: &f" + String.format("%.1f", tLeft) + " sn"));
        gui.setItem(53, ItemUtil.make(Material.BARRIER, "&c&lCIKIS"));
    }

    public void reflexClick(Player player) {
        UUID uuid = player.getUniqueId();
        data.reflexScore.merge(uuid, 1, Integer::sum);
        player.sendActionBar(C.c("&a&lDOGRU! Skor: &f" + data.reflexScore.get(uuid)));
        player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.7f, 1f);
        newReflexTarget(player);
    }

    public void tickReflex(Player player) {
        UUID uuid = player.getUniqueId();
        if (!data.reflexActive.containsKey(uuid)) return;
        double tLeft = data.reflexTimeLeft.getOrDefault(uuid, 0.0) - 0.1;
        data.reflexTimeLeft.put(uuid, tLeft);
        if (tLeft <= 0) endReflex(player);
        else drawReflex(player);
    }

    private void endReflex(Player player) {
        UUID uuid = player.getUniqueId();
        int score = data.reflexScore.getOrDefault(uuid, 0);
        reflexInvs.remove(uuid);
        data.clearReflex(uuid);
        player.closeInventory();
        invManager.invGeriYukle(player);
        headManager.giveGameHead(player);
        player.sendTitle(C.c("&c&lSURE BİTTİ!"), C.c("&7Skor: " + score), 10, 70, 20);
        player.sendMessage(C.c("&6&l[REFLEX] &7Oyun bitti! Skor: &f" + score));
    }

    public void stopReflex(Player player) {
        UUID uuid = player.getUniqueId();
        reflexInvs.remove(uuid);
        data.clearReflex(uuid);
        player.closeInventory();
        invManager.invGeriYukle(player);
        headManager.giveGameHead(player);
    }
}
