package com.yucehanrp.managers;

import com.yucehanrp.SessionData;
import com.yucehanrp.util.C;
import com.yucehanrp.util.ItemUtil;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;

/**
 * Tüm periyodik görevler — .sk every X seconds bloklarının tam karşılığı.
 */
public class SchedulerManager {

    private final Plugin plugin;
    private final SessionData data;
    private final PhoneManager phone;
    private final CryptoManager crypto;
    private final MarketManager market;
    private final MiniGamesManager miniGames;
    private final GameHeadManager headManager;
    private final BedWarsManager bedWars;

    public SchedulerManager(Plugin plugin, SessionData data, PhoneManager phone, CryptoManager crypto,
                            MarketManager market, MiniGamesManager miniGames, GameHeadManager headManager,
                            BedWarsManager bedWars) {
        this.plugin = plugin;
        this.data = data;
        this.phone = phone;
        this.crypto = crypto;
        this.market = market;
        this.miniGames = miniGames;
        this.headManager = headManager;
        this.bedWars = bedWars;
    }

    public void startAll() {

        // ════════════════════════════════════════════════════════
        // TELEFON: Sarj (every 15 seconds)
        // ════════════════════════════════════════════════════════
        new BukkitRunnable() {
            @Override public void run() {
                for (Player p : Bukkit.getOnlinePlayers()) {
                    UUID uuid = p.getUniqueId();
                    if (!data.charging.containsKey(uuid)) continue;
                    if (phone.hasPhone(p)) {
                        int bat = phone.getBattery(p);
                        if (bat < 100) {
                            phone.addBattery(p, 2);
                            p.sendActionBar(C.c("&b⚡ Sarj: " + phone.getBattery(p) + "%"));
                        } else {
                            phone.stopCharging(p);
                            p.sendMessage(C.c(SessionData.YUCECELL_PREFIX + " &aBatarya tamamen doldu!"));
                        }
                    } else {
                        phone.stopCharging(p);
                    }
                }
            }
        }.runTaskTimer(plugin, 20*15, 20*15);

        // ════════════════════════════════════════════════════════
        // TELEFON: Arama batarya tuketimi (every 30 seconds)
        // ════════════════════════════════════════════════════════
        new BukkitRunnable() {
            @Override public void run() {
                for (Player p : Bukkit.getOnlinePlayers()) {
                    if (phone.isInCall(p)) phone.tickCallBattery(p);
                }
            }
        }.runTaskTimer(plugin, 20*30, 20*30);

        // ════════════════════════════════════════════════════════
        // KRIPTO: Borsa güncelleme (every 1 minute)
        // ════════════════════════════════════════════════════════
        new BukkitRunnable() {
            @Override public void run() { crypto.updatePrices(); }
        }.runTaskTimer(plugin, 20*60, 20*60);

        // ════════════════════════════════════════════════════════
        // MARKET: Süresi dolan tezgah iadesi (every 30 seconds)
        // ════════════════════════════════════════════════════════
        new BukkitRunnable() {
            @Override public void run() {
                for (int i = 1; i <= 7; i++) {
                    if (data.marketItem.containsKey(i) && market.isExpired(i)) {
                        String ownerName = data.marketOwner.getOrDefault(i, "");
                        ItemStack item = data.marketItem.get(i).clone();
                        item.setAmount(data.marketAmount.getOrDefault(i, 1));
                        market.clearSlot(i);
                        // .sk: cooldown başlat
                        org.bukkit.OfflinePlayer offOwner = Bukkit.getOfflinePlayer(ownerName);
                        if (offOwner.getUniqueId() != null)
                            data.marketCooldown.put(offOwner.getUniqueId(), System.currentTimeMillis());
                        Player owner = Bukkit.getPlayerExact(ownerName);
                        if (owner != null && owner.isOnline()) {
                            owner.getInventory().addItem(item);
                            owner.sendMessage(C.c("&e[MARKET] &7Tezgahının süresi doldu. İtemin iade edildi."));
                            owner.sendMessage(C.c("&c&l[MARKET] &73 dakika tezgah kurma cooldownu başladı!"));
                        } else {
                            // .sk: market.bekleyen.item — çevrimdışıyken sakla
                            data.marketBekleyenItem.put(ownerName, item);
                        }
                    }
                }
            }
        }.runTaskTimer(plugin, 20*30, 20*30);

        // ════════════════════════════════════════════════════════
        // OYUN KAFASI: Her 20 saniyede oyun dışı oyunculara ver
        // ════════════════════════════════════════════════════════
        new BukkitRunnable() {
            @Override public void run() {
                for (Player p : Bukkit.getOnlinePlayers()) {
                    if (!data.isInAnyGame(p.getUniqueId())) {
                        headManager.giveGameHead(p);
                    }
                }
            }
        }.runTaskTimer(plugin, 20*20, 20*20);

        // ════════════════════════════════════════════════════════
        // BROADCAST: Şikayet duyurusu (every 5 minutes)
        // ════════════════════════════════════════════════════════
        new BukkitRunnable() {
            @Override public void run() {
                Bukkit.broadcastMessage(C.c(""));
                Bukkit.broadcastMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                Bukkit.broadcastMessage(C.c(" &c&l⚠ KURAL İHLALİ Mİ YAŞADIN?"));
                Bukkit.broadcastMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                Bukkit.broadcastMessage(C.c("&7Birine hakaret, tehdit veya haksız davranış mı yaşadın?"));
                Bukkit.broadcastMessage(C.c("&7Kanıtını bizimle paylaş!"));
                Bukkit.broadcastMessage(C.c("&a&l✦ Kanıt türleri: &fVideo, ekran görüntüsü, fotoğraf"));
                Bukkit.broadcastMessage(C.c("&b&l📸 Instagram: &fhttps://ig.me/j/AbYf5xko7wYSwck4/"));
                Bukkit.broadcastMessage(C.c("&a&l🎵 TikTok:    &fhttps://tiktok.me/group/ZSy3LJJDn/"));
                Bukkit.broadcastMessage(C.c("&d&l💬 Discord:  &fhttps://discord.gg/UsHEmQ6gKE"));
                Bukkit.broadcastMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                Bukkit.broadcastMessage(C.c(""));
            }
        }.runTaskTimer(plugin, 20*60*5, 20*60*5);

        // ════════════════════════════════════════════════════════
        // BROADCAST: Hoş geldin duyurusu (every 5 minutes, +30sn offset)
        // ════════════════════════════════════════════════════════
        new BukkitRunnable() {
            @Override public void run() {
                Bukkit.broadcastMessage(C.c(""));
                Bukkit.broadcastMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                Bukkit.broadcastMessage(C.c(" &6&l🌟 YUCEHAN RP'YE HOŞ GELDİNİZ!"));
                Bukkit.broadcastMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                Bukkit.broadcastMessage(C.c("&a✔ &7Sunucumuz &e7/24 &7açıktır!"));
                Bukkit.broadcastMessage(C.c("&c⚠ &7Her zaman yetkili olmayabilir."));
                Bukkit.broadcastMessage(C.c("&b➡ &7Yardım için: &e/rehber &7yazın!"));
                Bukkit.broadcastMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                Bukkit.broadcastMessage(C.c(""));
            }
        }.runTaskTimer(plugin, 20*60*5 + 20*30, 20*60*5);

        // ════════════════════════════════════════════════════════
        // BROADCAST: Destek duyurusu (every 7 minutes)
        // ════════════════════════════════════════════════════════
        new BukkitRunnable() {
            @Override public void run() {
                Bukkit.broadcastMessage(C.c(""));
                Bukkit.broadcastMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                Bukkit.broadcastMessage(C.c("&6&l🎉 Sunucumuzu destekle, Destekçi rolünü kazan!"));
                Bukkit.broadcastMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                Bukkit.broadcastMessage(C.c("&e➡ Discord'a katıl: &bhttps://discord.gg/UsHEmQ6gKE"));
                Bukkit.broadcastMessage(C.c("&e➡ Reklamı izle: &bhttps://link-hub.net/3711390/0LOreebfF7ZO"));
                Bukkit.broadcastMessage(C.c("&e➡ Thank You ekranının screenshot'unu al ve Discord'da ticket aç."));
                Bukkit.broadcastMessage(C.c("&a✅ Ödül: &fDestekçi rolü + özel sohbet kanalı"));
                Bukkit.broadcastMessage(C.c("&c⚠ &7Her kullanıcı yalnızca &e1 kez &7rol kazanabilir."));
                Bukkit.broadcastMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                Bukkit.broadcastMessage(C.c(""));
            }
        }.runTaskTimer(plugin, 20*60*7, 20*60*7);

        // ════════════════════════════════════════════════════════
        // BROADCAST: Arsa satış duyurusu (every 3 minutes)
        // ════════════════════════════════════════════════════════
        new BukkitRunnable() {
            @Override public void run() {
                for (Player p : Bukkit.getOnlinePlayers()) {
                    p.sendMessage(C.c(""));
                    p.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                    p.sendMessage(C.c("&6&l🏠 ARSA SATIŞI AÇIK!"));
                    p.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                    p.sendMessage(C.c("&7Kendi arsanı kurmak mı istiyorsun?"));
                    p.sendMessage(C.c("&e➡ Boş alan bul → koordinat al → para hazırla"));
                    p.sendMessage(C.c("&e➡ 3 platformdan biriyle iletişime geç → &asıraya alınırsın!"));
                    p.sendMessage(C.c("  &b&lDiscord:    &fhttps://discord.gg/UsHEmQ6gKE"));
                    p.sendMessage(C.c("  &d&lInstagram: &fhttps://ig.me/j/AbYf5xko7wYSwck4/"));
                    p.sendMessage(C.c("  &a&lTikTok:     &fhttps://tiktok.me/group/ZSy3LJJDn/"));
                    p.sendMessage(C.c("&7Detay için: &e/arsanasil"));
                    p.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                    p.sendMessage(C.c(""));
                }
            }
        }.runTaskTimer(plugin, 20*60*3, 20*60*3);

        // ════════════════════════════════════════════════════════
        // BROADCAST: Anti-cheat uyarısı (every 5 minutes)
        // ════════════════════════════════════════════════════════
        new BukkitRunnable() {
            @Override public void run() {
                Bukkit.broadcastMessage(C.c(""));
                Bukkit.broadcastMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                Bukkit.broadcastMessage(C.c("&4&l⚠ ANTİ-CHEAT SİSTEMİ UYARISI ⚠"));
                Bukkit.broadcastMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                Bukkit.broadcastMessage(C.c("&c&l✖ F3 + T &7ve &c&lAuto Clicker &7kullanımı tespit edilmektedir!"));
                Bukkit.broadcastMessage(C.c("&7Mesleklerden para kazanırken kafanızı hareket ettirin."));
                Bukkit.broadcastMessage(C.c("&7Sabitlenerek spam yaparsanız &c&lOTOMATİK BAN&7 yersiniz!"));
                Bukkit.broadcastMessage(C.c("&a&l✓ Güvenli Oyun = Hareket + Doğal Davranış"));
                Bukkit.broadcastMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                Bukkit.broadcastMessage(C.c(""));
            }
        }.runTaskTimer(plugin, 20*60*5 + 20*60, 20*60*5);

        // ════════════════════════════════════════════════════════
        // MİNİGAMES: Target + Simon (every 20 ticks)
        // ════════════════════════════════════════════════════════
        new BukkitRunnable() {
            @Override public void run() {
                if (data.targetActive.isEmpty() && data.simonActive.isEmpty()) return;
                for (Player p : Bukkit.getOnlinePlayers()) {
                    UUID uuid = p.getUniqueId();
                    if (data.targetActive.containsKey(uuid)) miniGames.tickTarget(p);
                    if (data.simonActive.containsKey(uuid)) miniGames.tickSimon(p);
                }
            }
        }.runTaskTimer(plugin, 20, 20);

        // ════════════════════════════════════════════════════════
        // MİNİGAMES: Reflex (every 2 ticks) — sadece aktif oyuncu varsa
        // ════════════════════════════════════════════════════════
        new BukkitRunnable() {
            @Override public void run() {
                if (data.reflexActive.isEmpty()) return;
                for (Player p : Bukkit.getOnlinePlayers()) {
                    UUID uuid = p.getUniqueId();
                    if (data.reflexActive.containsKey(uuid) && !data.reflexTransition.containsKey(uuid)) {
                        miniGames.tickReflex(p);
                    }
                }
            }
        }.runTaskTimer(plugin, 2, 2);

        // ════════════════════════════════════════════════════════
        // MİNİGAMES: Flappy + Snake — tek loop, sadece aktifse
        // ════════════════════════════════════════════════════════
        new BukkitRunnable() {
            @Override public void run() {
                if (data.flappyActive.isEmpty() && data.snakeActive.isEmpty()) return;
                for (Player p : Bukkit.getOnlinePlayers()) {
                    UUID uuid = p.getUniqueId();
                    if (data.flappyActive.containsKey(uuid)) miniGames.tickFlappy(p);
                    if (data.snakeActive.containsKey(uuid)) miniGames.tickSnake(p);
                }
            }
        }.runTaskTimer(plugin, 10, 10);

        // ════════════════════════════════════════════════════════
        // PVP ALANI İTEM TEMİZLEME — her 30 saniyede bir
        // Alan: 2,-47,9999961 → -29,-61,9999991
        // ════════════════════════════════════════════════════════
        new BukkitRunnable() {
            @Override public void run() {
                org.bukkit.World w = org.bukkit.Bukkit.getWorld("world");
                if (w == null) return;
                // Sadece ilgili chunk'ları tara (tüm dünya değil)
                int minCX = -29 >> 4, maxCX = 2 >> 4;
                int minCZ = 9999961 >> 4, maxCZ = 9999991 >> 4;
                for (int cx = minCX; cx <= maxCX; cx++) {
                    for (int cz = minCZ; cz <= maxCZ; cz++) {
                        if (!w.isChunkLoaded(cx, cz)) continue;
                        for (org.bukkit.entity.Entity e : w.getChunkAt(cx, cz).getEntities()) {
                            if (!(e instanceof org.bukkit.entity.Item)) continue;
                            org.bukkit.Location loc = e.getLocation();
                            double ex = loc.getX(), ey = loc.getY(), ez = loc.getZ();
                            if (ex >= -29 && ex <= 2 && ey >= -61 && ey <= -47 && ez >= 9999961 && ez <= 9999991) {
                                e.remove();
                            }
                        }
                    }
                }
            }
        }.runTaskTimer(plugin, 20*30, 20*30);

        // ════════════════════════════════════════════════════════
        // BED WARS: Demir spawn — her takıma ayrı (every 10 seconds)
        // ════════════════════════════════════════════════════════
        new BukkitRunnable() {
            @Override public void run() {
                if (!data.bwActive) return;
                World w = Bukkit.getWorld("world");
                if (w == null) return;
                // .sk: Kirmizi Y=43, Mavi Y=42, Sari Y=43, Yesil Y=42
                w.dropItemNaturally(new Location(w,  14, 43, 10000065), new ItemStack(Material.IRON_INGOT));
                w.dropItemNaturally(new Location(w, -41, 42, 10000128), new ItemStack(Material.IRON_INGOT));
                w.dropItemNaturally(new Location(w,-124, 43, 10000080), new ItemStack(Material.IRON_INGOT));
                w.dropItemNaturally(new Location(w, -60, 42, 10000018), new ItemStack(Material.IRON_INGOT));
            }
        }.runTaskTimer(plugin, 20*8, 20*8);

        // ════════════════════════════════════════════════════════
        // BED WARS: Altın spawn — her takıma ayrı (every 45 seconds — .sk birebir)
        // ════════════════════════════════════════════════════════
        new BukkitRunnable() {
            @Override public void run() {
                if (!data.bwActive) return;
                World w = Bukkit.getWorld("world");
                if (w == null) return;
                w.dropItemNaturally(new Location(w,  14, 43, 10000084), new ItemStack(Material.GOLD_INGOT));
                w.dropItemNaturally(new Location(w, -60, 42, 10000128), new ItemStack(Material.GOLD_INGOT));
                w.dropItemNaturally(new Location(w,-124, 43, 10000065), new ItemStack(Material.GOLD_INGOT));
                w.dropItemNaturally(new Location(w, -41, 42, 10000018), new ItemStack(Material.GOLD_INGOT));
            }
        }.runTaskTimer(plugin, 20*20, 20*20);

        // ════════════════════════════════════════════════════════
        // BED WARS: Item temizleme (every 60 seconds)
        // ════════════════════════════════════════════════════════
        new BukkitRunnable() {
            @Override public void run() {
                if (!data.bwActive) return;
                bedWars.bwItemTemizle();
            }
        }.runTaskTimer(plugin, 20*60, 20*60);

        // ════════════════════════════════════════════════════════
        // BED WARS: Alan sınırı — BW/spec/lobi oyuncuları (every 4 seconds — .sk birebir)
        // ════════════════════════════════════════════════════════
        new BukkitRunnable() {
            @Override public void run() {
                if (!data.bwActive && data.bwLobbyQueue.isEmpty()) return;
                for (Player p : Bukkit.getOnlinePlayers()) {
                    UUID uuid = p.getUniqueId();
                    boolean bwIcinde = data.bwTeam.containsKey(uuid)
                            || data.bwSpec.containsKey(uuid)
                            || data.bwInLobby.containsKey(uuid);
                    if (!bwIcinde) continue;
                    double px = p.getLocation().getX();
                    double pz = p.getLocation().getZ();
                    if (bedWars.isOutOfBounds(px, pz)) {
                        if (data.bwSpec.containsKey(uuid)) {
                            p.teleport(new Location(Bukkit.getWorld("world"), -55, 80, 10000075));
                            p.sendActionBar(C.c("&c[BW] Alan sınırı! Geri ışınlandın."));
                        } else {
                            p.teleport(new Location(Bukkit.getWorld("world"), 9, 60, 10000025));
                            p.sendActionBar(C.c("&c[BW] Alan dışına çıkamazsın!"));
                        }
                    }
                }
            }
        }.runTaskTimer(plugin, 20*4, 20*4);

        // ════════════════════════════════════════════════════════
        // BED WARS: PVP bayrağı süresi (every 5 seconds — .sk birebir)
        // ════════════════════════════════════════════════════════
        new BukkitRunnable() {
            @Override public void run() {
                if (!data.bwActive) return;
                for (UUID uid : new HashSet<>(data.bwTeam.keySet())) {
                    if (Boolean.TRUE.equals(data.bwPvpActive.get(uid))) {
                        int hits = data.bwPvpHits.getOrDefault(uid, 0);
                        if (hits == 0) data.bwPvpActive.remove(uid);
                        else data.bwPvpHits.put(uid, 0);
                    }
                }
            }
        }.runTaskTimer(plugin, 20*5, 20*5);

        // ════════════════════════════════════════════════════════
        // BED WARS: Konum takibi (every 10 seconds — .sk birebir)
        // ════════════════════════════════════════════════════════
        new BukkitRunnable() {
            @Override public void run() {
                if (!data.bwActive) return;
                for (UUID uid : new HashSet<>(data.bwTeam.keySet())) {
                    Player p = Bukkit.getPlayer(uid);
                    if (p == null) continue;
                    data.bwPrevPosX.put(uid, data.bwPosX.getOrDefault(uid, p.getLocation().getX()));
                    data.bwPrevPosZ.put(uid, data.bwPosZ.getOrDefault(uid, p.getLocation().getZ()));
                    data.bwPosX.put(uid, p.getLocation().getX());
                    data.bwPosZ.put(uid, p.getLocation().getZ());
                }
            }
        }.runTaskTimer(plugin, 20*10, 20*10);

        // ════════════════════════════════════════════════════════
        // BED WARS: Anti-runner + Anti-AFK (every 15 seconds — .sk birebir)
        // ════════════════════════════════════════════════════════
        new BukkitRunnable() {
            @Override public void run() {
                if (!data.bwActive) return;
                for (UUID uid : new HashSet<>(data.bwTeam.keySet())) {
                    Player p = Bukkit.getPlayer(uid);
                    if (p == null) continue;
                    if (Boolean.TRUE.equals(data.bwPvpActive.get(uid))) {
                        data.bwAfkCount.put(uid, 0);
                        data.bwRunnerCount.put(uid, 0);
                        continue;
                    }
                    Double cx = data.bwPosX.get(uid);
                    Double cz = data.bwPosZ.get(uid);
                    Double px = data.bwPrevPosX.get(uid);
                    Double pz = data.bwPrevPosZ.get(uid);
                    if (cx == null || px == null) continue;
                    double dist = Math.abs(cx - px) + Math.abs(cz - pz);
                    if (dist >= 120) {
                        int rc = data.bwRunnerCount.merge(uid, 1, Integer::sum);
                        if (rc >= 3) {
                            data.bwRunnerCount.put(uid, 0);
                            p.addPotionEffect(new org.bukkit.potion.PotionEffect(org.bukkit.potion.PotionEffectType.SLOWNESS, 20*20, 1));
                            p.addPotionEffect(new org.bukkit.potion.PotionEffect(org.bukkit.potion.PotionEffectType.GLOWING, 20*20, 0));
                            p.sendActionBar(C.c("&c&l⚠ ÇOK KAÇIYORSUN! Yavaşlama uygulandı."));
                            Bukkit.broadcastMessage(C.c("&c&l[BW] ⚠ &e" + p.getName() + " &cçok kaçtığı için yavaşladı!"));
                        }
                    } else if (dist <= 2) {
                        int ac = data.bwAfkCount.merge(uid, 1, Integer::sum);
                        if (ac >= 6) {
                            data.bwAfkCount.put(uid, 0);
                            p.addPotionEffect(new org.bukkit.potion.PotionEffect(org.bukkit.potion.PotionEffectType.SLOWNESS, 20*20, 1));
                            p.addPotionEffect(new org.bukkit.potion.PotionEffect(org.bukkit.potion.PotionEffectType.GLOWING, 20*20, 0));
                            p.sendActionBar(C.c("&c&l⚠ SAKLANIYORSUN! İfşa oldun."));
                            Bukkit.broadcastMessage(C.c("&c&l[BW] ⚠ &e" + p.getName() + " &csaklandığı için ifşa oldu!"));
                        }
                    } else {
                        data.bwAfkCount.put(uid, 0);
                        if (data.bwRunnerCount.getOrDefault(uid, 0) > 0)
                            data.bwRunnerCount.merge(uid, -1, Integer::sum);
                    }
                }
            }
        }.runTaskTimer(plugin, 20*15, 20*15);

        // ════════════════════════════════════════════════════════
        // BED WARS: Oyun süresi sayacı (every 60 seconds — .sk birebir)
        // ════════════════════════════════════════════════════════
        new BukkitRunnable() {
            @Override public void run() {
                if (!data.bwActive || data.bwTimeLeft <= 0) return;
                data.bwTimeLeft -= 60;
                int dk = data.bwTimeLeft / 60;
                int sn = data.bwTimeLeft % 60;
                if (data.bwTimeLeft > 0) {
                    for (UUID uid : new HashSet<>(data.bwTeam.keySet())) {
                        Player p = Bukkit.getPlayer(uid);
                        if (p != null) p.sendActionBar(C.c("&e⏱ Kalan: &f" + data.bwTimeLeft + " saniye"));
                    }
                    // .sk: 5 ve 1 dakika uyarısı
                    if (data.bwTimeLeft == 300) {
                        for (UUID uid : new HashSet<>(data.bwTeam.keySet())) {
                            Player p = Bukkit.getPlayer(uid);
                            if (p != null) p.sendMessage(C.c("&a[BW] &e5 dakika &akaldı!"));
                        }
                    }
                    if (data.bwTimeLeft == 60) {
                        for (UUID uid : new HashSet<>(data.bwTeam.keySet())) {
                            Player p = Bukkit.getPlayer(uid);
                            if (p != null) p.sendMessage(C.c("&c&l[BW] 1 DAKİKA KALDI!"));
                        }
                    }
                    if (data.bwTimeLeft == 30) {
                        for (UUID uid : new HashSet<>(data.bwTeam.keySet())) {
                            Player p = Bukkit.getPlayer(uid);
                            if (p != null) p.sendMessage(C.c("&c&l[BW] 30 SANİYE KALDI!"));
                        }
                    }
                } else {
                    // Süre doldu
                    for (UUID uid : new HashSet<>(data.bwTeam.keySet())) {
                        Player p = Bukkit.getPlayer(uid);
                        if (p == null) continue;
                        p.sendMessage(C.c(""));
                        p.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                        p.sendMessage(C.c("       &c&l⏱ SÜRE DOLDU! HERKES KAYBETTİ!"));
                        p.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                        p.sendTitle(C.c("&c&lSÜRE DOLDU"), C.c("&7Herkes kaybetti!"), 10, 70, 20);
                        p.playSound(p.getLocation(), Sound.ENTITY_WITHER_DEATH, 1f, 1f);
                    }
                    Bukkit.getScheduler().runTaskLater(plugin, () -> bedWars.endGame("yok"), 60L);
                }
            }
        }.runTaskTimer(plugin, 20*60, 20*60);

        // ════════════════════════════════════════════════════════
        // REHBER: Külah + Çilek + Craft takibi (every 10 seconds — .sk ile birebir)
        // ════════════════════════════════════════════════════════
        new BukkitRunnable() {
            @Override public void run() {
                for (Player p : Bukkit.getOnlinePlayers()) {
                    UUID uuid = p.getUniqueId();
                    String rehberDurum = data.guideState.get(uuid);
                    if (rehberDurum == null) continue;

                    if ("KULAH".equals(rehberDurum)) {
                        int kulahSayisi = 0;
                        for (ItemStack item : p.getInventory().getContents()) {
                            if (item == null) continue;
                            if (item.getType() == org.bukkit.Material.STICK) {
                                String n = ItemUtil.uncoloredName(item);
                                if (n.contains("DondurmaKulahi")) kulahSayisi += item.getAmount();
                            }
                        }
                        if (kulahSayisi >= 7) {
                            data.guideState.put(uuid, "CILEK");
                            p.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                            p.sendMessage(C.c("&d&lKALYX &8› &a&l✓ Güzel! 7 tane külahı aldın!"));
                            p.sendMessage(C.c("&d&lKALYX &8› &e&l⚑ 2. GÖREV &8— &fMalzemeyi Tamamla"));
                            p.sendMessage(C.c("&d&lKALYX &8› &7o tezgahtan &b&l1 adet Çilek &7al."));
                            p.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                            p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.4f, 1f);
                        }
                    } else if ("CILEK".equals(rehberDurum)) {
                        int cilekSayisi = 0;
                        for (ItemStack item : p.getInventory().getContents()) {
                            if (item == null) continue;
                            if (item.getType() == org.bukkit.Material.REDSTONE) {
                                if (ItemUtil.uncoloredName(item).contains("Cilek")) cilekSayisi += item.getAmount();
                            }
                        }
                        if (cilekSayisi >= 1) {
                            data.guideState.put(uuid, "CRAFT");
                            p.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                            p.sendMessage(C.c("&d&lKALYX &8› &a&l✓ Harika! Şimdi dondurma yapma zamanı!"));
                            p.sendMessage(C.c("&d&lKALYX &8› &e&l⚑ 3. GÖREV &8— &fDondurma Üret"));
                            p.sendMessage(C.c("&d&lKALYX &8› &7Dondurma Makinesine sağ tıkla, külah + çilek seç!"));
                            p.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                            p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.5f, 1f);
                        }
                    } else if ("CRAFT".equals(rehberDurum)) {
                        if (!Boolean.TRUE.equals(data.guideAccepted.get(uuid))) continue;
                        boolean found = false;
                        for (ItemStack item : p.getInventory().getContents()) {
                            if (item == null) continue;
                            if (ItemUtil.uncoloredName(item).contains("Cilekli Dondurma")) { found = true; break; }
                        }
                        if (found) {
                            data.guideState.remove(uuid);
                            data.guideAccepted.remove(uuid);
                            p.sendMessage(C.c(""));
                            p.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                            p.sendMessage(C.c("     &d&l✦ &a&lREHBER TAMAMLANDI! &d&l✦"));
                            p.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                            p.sendMessage(C.c("&d&lKALYX &8› &fVay be &e" + p.getName() + "&f! İlk dondurmanı yaptın!"));
                            p.sendMessage(C.c("&d&lKALYX &8› &7Artık dondurmalarını &a&lsatabilirsin&7!"));
                            p.sendMessage(C.c("&d&lKALYX &8› &e  ➊ &fMalzeni hazırla  &e➋ &fÜrün üret  &e➌ &fSat ve kazan!"));
                            p.sendMessage(C.c("&d&lKALYX &8› &7  &e/warp meslekseç &8— &7Tüm meslekleri görmek için"));
                            p.sendMessage(C.c("&d&lKALYX &8› &7  &e/warp spawn &8— &7Ana alana dönmek için"));
                            p.sendMessage(C.c("&d&lKALYX &8› &c&l⚠ NOT: &7Kuralları okumayı unutma! &e/kurallar"));
                            p.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
                            p.sendTitle(C.c("&a&l✓ REHBER TAMAMLANDI!"), C.c("&7Hazırla, Üret, Sat!"), 10, 70, 20);
                            p.playSound(p.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
                            // 2 saniye sonra belediyeye TP
                            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                                if (p.isOnline()) {
                                    p.sendMessage(C.c("&d&lKALYX &8› &7Şimdi seni &e&lBelediye Binası&7'na ışınlıyorum!"));
                                    p.teleport(new Location(Bukkit.getWorld("world"), -2.64, -60.0, -643.50));
                                }
                            }, 40L);
                        }
                    }
                }
            }
        }.runTaskTimer(plugin, 20*10, 20*10);

        // ════════════════════════════════════════════════════════
        // AFK KICK — 2 dakika hareketsiz, chat yok, blok kırmıyorsa at
        // ════════════════════════════════════════════════════════
        new BukkitRunnable() {
            @Override public void run() {
                long now = System.currentTimeMillis();
                for (org.bukkit.entity.Player p : Bukkit.getOnlinePlayers()) {
                    java.util.UUID uuid = p.getUniqueId();
                    long last = data.afkLastActivity.getOrDefault(uuid, now);
                    if (now - last >= 2 * 60 * 1000L) {
                        data.afkLastActivity.remove(uuid);
                        Bukkit.getScheduler().runTask(plugin, () -> {
                            if (p.isOnline())
                                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "kick " + p.getName() + " AFK");
                        });
                    }
                }
            }
        }.runTaskTimer(plugin, 20*30, 20*30); // 30 saniyede bir kontrol

        // ════════════════════════════════════════════════════════
        // 15 GÜNLÜK VARİABLE TEMİZLİĞİ (.sk ile birebir)
        // Çevrimdışı oyuncuların kayıtlı envanter verilerini temizle
        // ════════════════════════════════════════════════════════
        new BukkitRunnable() {
            @Override public void run() {
                for (org.bukkit.OfflinePlayer op : Bukkit.getOfflinePlayers()) {
                    if (!op.isOnline()) {
                        UUID uuid = op.getUniqueId();
                        if (data.invSaved.containsKey(uuid)) {
                            data.savedInventory.remove(uuid);
                            data.savedArmor.remove(uuid);
                            data.savedGameMode.remove(uuid);
                            data.invSaved.remove(uuid);
                        }
                    }
                }
            }
        }.runTaskTimer(plugin, 20L * 60 * 60 * 24 * 15, 20L * 60 * 60 * 24 * 15);
    }
}
