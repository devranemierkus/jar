package com.yucehanrp.managers;

import com.yucehanrp.SessionData;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

/**
 * Oyuncu envanterini önce RAM'de, sonra diske (dc_saves/) yazar.
 * Crash/DC durumunda disk yedekten iade eder.
 * Normal çıkışta (/oyundancik) sadece RAM kullanılır, disk temizlenir.
 */
public class InventoryManager {

    private final SessionData data;
    private final File saveDir;

    public InventoryManager(SessionData data, Plugin plugin) {
        this.data = data;
        this.saveDir = new File(plugin.getDataFolder(), "dc_saves");
        if (!saveDir.exists()) saveDir.mkdirs();
    }

    /** Oyuncunun envanterini RAM'e ve diske kaydeder */
    public void invKaydet(Player player) {
        UUID uuid = player.getUniqueId();
        // Zaten kayıtlıysa üzerine yazma
        if (data.invSaved.containsKey(uuid)) return;

        ItemStack[] contents = player.getInventory().getContents();
        ItemStack[] saved = new ItemStack[contents.length];
        for (int i = 0; i < contents.length; i++) {
            saved[i] = contents[i] != null ? contents[i].clone() : null;
        }
        data.savedInventory.put(uuid, saved);

        ItemStack[] armor = player.getInventory().getArmorContents();
        ItemStack[] savedArmor = new ItemStack[armor.length];
        for (int i = 0; i < armor.length; i++) {
            savedArmor[i] = armor[i] != null ? armor[i].clone() : null;
        }
        data.savedArmor.put(uuid, savedArmor);
        data.savedGameMode.put(uuid, player.getGameMode());
        data.invSaved.put(uuid, true);

        // Diske yaz (crash koruması)
        saveToDisk(player);
    }

    /** Envanter iadesi — önce RAM, yoksa diskten */
    public void invGeriYukle(Player player) {
        UUID uuid = player.getUniqueId();

        // RAM'de varsa normal iade
        if (data.invSaved.containsKey(uuid)) {
            restoreFromRam(player);
            deleteDiskSave(uuid);
            return;
        }

        // RAM'de yok, diskten dene (crash recovery)
        File f = diskFile(uuid);
        if (f.exists()) {
            restoreFromDisk(player, f);
        }
    }

    /** Disk kaydını temizle (normal çıkışta çağır) */
    public void deleteDiskSave(UUID uuid) {
        File f = diskFile(uuid);
        if (f.exists()) f.delete();
    }

    /** Sunucu başlarken disk kayıtları olan oyuncuları iade et */
    public void checkCrashRecovery(Player player) {
        UUID uuid = player.getUniqueId();
        if (data.invSaved.containsKey(uuid)) return; // Zaten RAM'de var
        File f = diskFile(uuid);
        if (f.exists()) {
            restoreFromDisk(player, f);
            player.sendMessage("§a[YucehanRP] §7Oyun sırasında sunucu kapandı. Envanterin iade edildi.");
        }
    }

    public void gamemodeDondur(Player player) {
        UUID uuid = player.getUniqueId();
        GameMode gm = data.savedGameMode.getOrDefault(uuid, GameMode.ADVENTURE);
        player.setGameMode(gm);
        data.savedGameMode.remove(uuid);
    }

    public boolean isInvSaved(Player player) {
        return data.invSaved.containsKey(player.getUniqueId());
    }

    public ItemStack[] getSavedInventory(Player player) {
        return data.savedInventory.get(player.getUniqueId());
    }

    public ItemStack[] getSavedArmor(Player player) {
        return data.savedArmor.get(player.getUniqueId());
    }

    // ─── Yardımcılar ────────────────────────────────────────────────────────

    private void restoreFromRam(Player player) {
        UUID uuid = player.getUniqueId();
        player.getInventory().clear();
        player.getInventory().setArmorContents(new ItemStack[4]);

        ItemStack[] saved = data.savedInventory.get(uuid);
        if (saved != null) player.getInventory().setContents(saved);

        ItemStack[] savedArmor = data.savedArmor.get(uuid);
        if (savedArmor != null) player.getInventory().setArmorContents(savedArmor);

        data.savedInventory.remove(uuid);
        data.savedArmor.remove(uuid);
        data.invSaved.remove(uuid);
    }

    private void saveToDisk(Player player) {
        try {
            UUID uuid = player.getUniqueId();
            YamlConfiguration cfg = new YamlConfiguration();
            cfg.set("gamemode", player.getGameMode().name());
            ItemStack[] contents = data.savedInventory.get(uuid);
            if (contents != null) cfg.set("contents", contents);
            ItemStack[] armor = data.savedArmor.get(uuid);
            if (armor != null) cfg.set("armor", armor);
            cfg.set("player", player.getName());
            cfg.save(diskFile(uuid));
        } catch (IOException ignored) {}
    }

    private void restoreFromDisk(Player player, File f) {
        try {
            YamlConfiguration cfg = YamlConfiguration.loadConfiguration(f);
            player.getInventory().clear();
            player.getInventory().setArmorContents(new ItemStack[4]);

            ItemStack[] contents = cfg.getList("contents") == null ? null
                    : cfg.getList("contents").toArray(new ItemStack[0]);
            if (contents != null) player.getInventory().setContents(contents);

            ItemStack[] armor = cfg.getList("armor") == null ? null
                    : cfg.getList("armor").toArray(new ItemStack[0]);
            if (armor != null) player.getInventory().setArmorContents(armor);

            String gmStr = cfg.getString("gamemode", "ADVENTURE");
            try { player.setGameMode(GameMode.valueOf(gmStr)); }
            catch (Exception e) { player.setGameMode(GameMode.ADVENTURE); }

            f.delete();
        } catch (Exception ignored) {
            f.delete();
        }
    }

    private File diskFile(UUID uuid) {
        return new File(saveDir, uuid.toString() + ".yml");
    }
}
