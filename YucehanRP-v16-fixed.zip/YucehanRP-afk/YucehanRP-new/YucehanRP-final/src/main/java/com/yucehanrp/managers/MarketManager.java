package com.yucehanrp.managers;

import com.yucehanrp.SessionData;
import com.yucehanrp.util.C;
import com.yucehanrp.util.ItemUtil;
import org.bukkit.inventory.ItemStack;

import java.util.Map;

public class MarketManager {

    private static final int MAX_SLOTS = 7;
    private static final long SLOT_DURATION_MS = 10 * 60 * 1000L; // 10 dakika

    private final SessionData data;

    public MarketManager(SessionData data) {
        this.data = data;
    }

    /** Boş bir market slotu döndürür (1-7), yoksa 0 */
    public int findFreeSlot() {
        for (int i = 1; i <= MAX_SLOTS; i++) {
            if (!data.marketItem.containsKey(i) && !data.marketReserved.containsKey(i)) {
                return i;
            }
        }
        return 0;
    }

    /** Bir oyuncunun dolu slotunu döndürür, yoksa 0 */
    public int findOwnerSlot(String playerName) {
        for (int i = 1; i <= MAX_SLOTS; i++) {
            if (playerName.equals(data.marketOwner.get(i))) {
                return i;
            }
        }
        return 0;
    }

    /** Kalan süre saniye olarak */
    public long getRemainingSeconds(int slot) {
        Long start = data.marketTime.get(slot);
        if (start == null) return 0;
        long elapsed = (System.currentTimeMillis() - start) / 1000L;
        long remaining = 600 - elapsed;
        return Math.max(0, remaining);
    }

    public boolean isExpired(int slot) {
        return getRemainingSeconds(slot) == 0;
    }

    public void clearSlot(int slot) {
        data.marketItem.remove(slot);
        data.marketAmount.remove(slot);
        data.marketPrice.remove(slot);
        data.marketOwner.remove(slot);
        data.marketTime.remove(slot);
        data.marketReserved.remove(slot);
        data.marketCurrency.remove(slot);
    }

    public void reserveSlot(int slot) {
        data.marketReserved.put(slot, true);
    }

    /** GUI'deki slot numarasına karşılık gelen market slot indeksi */
    public int guiSlotToN(int guiSlot) {
        return switch (guiSlot) {
            case 10 -> 1; case 12 -> 2; case 14 -> 3;
            case 20 -> 4; case 22 -> 5; case 24 -> 6;
            case 31 -> 7; default -> 0;
        };
    }

    public int nToGuiSlot(int n) {
        return switch (n) {
            case 1 -> 10; case 2 -> 12; case 3 -> 14;
            case 4 -> 20; case 5 -> 22; case 6 -> 24;
            case 7 -> 31; default -> 0;
        };
    }

    public boolean isSystemItem(ItemStack item) {
        if (item == null) return false;
        String uncolored = ItemUtil.uncoloredName(item);
        if (uncolored.contains("KATIL") || uncolored.contains("SERIF")
                || uncolored.contains("SISTEM") || uncolored.contains("OYUNLAR")) return true;
        return ItemUtil.hasLoreContaining(item, "KOPYALANAMAZ")
                || ItemUtil.hasLoreContaining(item, "YUCECELL A.S.");
    }

    public int getActiveCount() {
        int count = 0;
        for (int i = 1; i <= MAX_SLOTS; i++) {
            if (data.marketItem.containsKey(i)) count++;
        }
        return count;
    }
}
