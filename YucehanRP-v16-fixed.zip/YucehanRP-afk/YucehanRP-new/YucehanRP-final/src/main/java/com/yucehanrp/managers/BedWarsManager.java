package com.yucehanrp.managers;

import com.yucehanrp.SessionData;
import com.yucehanrp.util.C;
import com.yucehanrp.util.ItemUtil;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.awt.Color;
import java.util.*;

/**
 * BED WARS — .sk ile birebir port
 * - 4 takım (kirmizi/mavi/sari/yesil), max 3 kişi/takım
 * - Lobi: min 2 oyuncu, 60sn geri sayım
 * - Yatak kırılınca yeniden doğma yok, elenince spectator
 * - Süre dolunca herkes kaybeder
 * - Kazanan kontrol .sk bwKazananKontrol() ile aynı
 */
public class BedWarsManager {

    private final SessionData data;
    private final InventoryManager invManager;
    private final GameHeadManager headManager;

    public BedWarsManager(SessionData data, InventoryManager invManager, GameHeadManager headManager) {
        this.data = data;
        this.invManager = invManager;
        this.headManager = headManager;
    }

    // ─── Yardımcı ────────────────────────────────────────────────────────────

    public String teamColorCode(String team) {
        return switch (team) {
            case "kirmizi" -> "&c&lKIRMIZI";
            case "mavi"    -> "&9&lMAVİ";
            case "sari"    -> "&e&lSARI";
            case "yesil"   -> "&a&lYEŞİL";
            default        -> "&fBİLİNMEYEN";
        };
    }

    public Location spawnLoc(String team) {
        World w = Bukkit.getWorld("world");
        return switch (team) {
            case "kirmizi" -> new Location(w,  12, 44, 10000074);
            case "mavi"    -> new Location(w, -50, 44, 10000127);
            case "sari"    -> new Location(w,-121, 44, 10000074);
            case "yesil"   -> new Location(w, -49, 44, 10000021);
            default        -> new Location(w,   9, 60, 10000025);
        };
    }

    public Location lobbyLoc() {
        return new Location(Bukkit.getWorld("world"), 9, 60, 10000025);
    }

    /** .sk bwKorunanMi — korunan alan kontrolü */
    public boolean isProtectedArea(double x, double y, double z) {
        // Kirmizi takım alanı
        if (x >= 8  && x <= 18  && y >= 40 && y <= 60 && z >= 10000057 && z <= 10000092) return true;
        // Sarı takım alanı
        if (x >=-128&& x <=-118 && y >= 40 && y <= 60 && z >= 10000057 && z <= 10000092) return true;
        // Yeşil takım alanı
        if (x >= -68 && x <= -33 && y >= 40 && y <= 59 && z >= 10000015 && z <= 10000025) return true;
        // Mavi takım alanı
        if (x >= -68 && x <= -33 && y >= 40 && y <= 60 && z >= 10000122 && z <= 10000132) return true;
        // Bekleme alanı
        if (x >= 3  && x <= 15  && y >= 58 && y <= 65 && z >= 10000018 && z <= 10000031) return true;
        // Harita altı
        if (y < 39 && x >= -148 && x <= 37 && z >= 10000002 && z <= 10000148) return true;
        return false;
    }

    /** .sk bwAlanDisiMi */
    public boolean isOutOfBounds(double x, double z) {
        return !(x >= -148 && x <= 37 && z >= 10000002 && z <= 10000148);
    }

    /** .sk getBedTeam — hangi takımın yatağı */
    public String getBedTeam(double x, double y, double z) {
        if (x >= -6  && x <= -4  && y >= 40 && y <= 42 && z >= 10000074 && z <= 10000076) return "kirmizi";
        if (x >= -52 && x <= -50 && y >= 40 && y <= 42 && z >= 10000107 && z <= 10000108) return "mavi";
        if (x >=-104 && x <=-102 && y >= 40 && y <= 42 && z >= 10000073 && z <= 10000075) return "sari";
        if (x >= -51 && x <= -49 && y >= 40 && y <= 42 && z >= 10000037 && z <= 10000038) return "yesil";
        return null;
    }

    public Location bedLoc(String team) {
        World w = Bukkit.getWorld("world");
        return switch (team) {
            case "kirmizi" -> new Location(w,  -5, 41, 10000075);
            case "mavi"    -> new Location(w, -51, 41, 10000107);
            case "sari"    -> new Location(w,-103, 41, 10000074);
            case "yesil"   -> new Location(w, -50, 41, 10000037);
            default        -> new Location(w,   0, 64, 0);
        };
    }

    // ─── Kit verme — .sk giveTeamKit ile birebir ─────────────────────────────
    public void giveTeamKit(Player p, String team) {
        p.getInventory().clear();
        Color color = switch (team) {
            case "kirmizi" -> new Color(200,   0,   0);
            case "mavi"    -> new Color(  0,   0, 220);
            case "sari"    -> new Color(255, 220,   0);
            case "yesil"   -> new Color(  0, 200,   0);
            default        -> new Color(255, 255, 255);
        };
        String cc = teamColorCode(team);
        p.getInventory().setHelmet    (ItemUtil.makeLeatherArmor(Material.LEATHER_HELMET,      color, cc + " TAKIM"));
        p.getInventory().setChestplate(ItemUtil.makeLeatherArmor(Material.LEATHER_CHESTPLATE,  color, cc + " TAKIM"));
        p.getInventory().setLeggings  (ItemUtil.makeLeatherArmor(Material.LEATHER_LEGGINGS,    color, cc + " TAKIM"));
        p.getInventory().setBoots     (ItemUtil.makeLeatherArmor(Material.LEATHER_BOOTS,       color, cc + " TAKIM"));
        p.getInventory().addItem(new ItemStack(Material.STONE_SWORD));
        p.getInventory().addItem(new ItemStack(Material.WHITE_WOOL, 64));
        p.getInventory().addItem(new ItemStack(Material.BREAD, 5));
    }

    // ─── Lobi giriş — .sk bwLobiGir birebir ─────────────────────────────────
    public void bwLobiGir(Player player) {
        UUID uuid = player.getUniqueId();
        if (data.isInAnyGame(uuid)) {
            player.sendMessage(C.c("&c[BW] Önce mevcut oyundan çık! (/oyundancik)"));
            return;
        }
        invManager.invKaydet(player);
        player.getInventory().clear();
        player.setGameMode(GameMode.ADVENTURE);
        player.setHealth(20); player.setFoodLevel(20);
        player.teleport(lobbyLoc());

        data.bwInLobby.put(uuid, true);
        data.bwLobbyQueue.add(uuid);

        int sz = data.bwLobbyQueue.size();
        player.sendMessage(C.c(""));
        player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
        player.sendMessage(C.c("         &c&l🛏 BED WARS — Lobi"));
        player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
        player.sendMessage(C.c("&7Oyuncu: &e" + sz + "/12 &8| &e2+ &7gerekli"));
        if (sz == 1) {
            player.sendMessage(C.c("&7Oyun başlamak için &e1 &7oyuncu daha gerek!"));
        }
        player.sendMessage(C.c("&c&lÇıkmak: &e/oyundancik"));
        player.sendMessage(C.c("&e&l⚠ &cArsan varsa önce arsandan çık!"));
        player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
        player.sendMessage(C.c(" &6&l⚠ EŞYA GÜVENLİĞİ UYARISI"));
        player.sendMessage(C.c("&a✔ &7Oyundan normal çıkarsanız (/oyundancik) &aeşyalar anında iade edilir."));
        player.sendMessage(C.c("&a✔ &7Sunucu kapanır/restart atılırsa &aeşyalar korunur, tekrar girebilirsiniz."));
        player.sendMessage(C.c("&c✘ &7Oyun içinde bağlantı koparsa &8(internet/DC)&7 eşyalar 3 gün saklanır."));
        player.sendMessage(C.c("&c✘ &c&l3 gün içinde girmezseniz eşyalar silinir, iade yapılmaz!"));
        player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
        player.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.5f, 1f);

        broadcastToLobi(C.c("&c[BW] &e" + player.getName() + " &7katıldı! (&f" + sz + " kişi&7)"), uuid);

        if (!data.bwCountdownActive && sz >= 2) {
            startCountdown();
        }
    }

    // ─── Lobi çıkış — .sk bwLobiCik birebir ─────────────────────────────────
    public void lobiCik(Player player) {
        UUID uuid = player.getUniqueId();
        data.bwInLobby.remove(uuid);
        data.bwLobbyQueue.remove(uuid);
        data.bwTeam.remove(uuid);
        data.bwSpec.remove(uuid);
        data.clearBwPlayer(uuid);
        player.getInventory().clear();
        invManager.invGeriYukle(player);
        player.setGameMode(GameMode.ADVENTURE);
        player.teleport(new Location(Bukkit.getWorld("world"), -15, -60, -8));
        headManager.giveGameHead(player);
        player.sendMessage(C.c("&c&l[BED WARS] &7Oyundan çıktın."));
    }

    // ─── Geri sayım — .sk bwGeriSayim birebir ───────────────────────────────
    private void startCountdown() {
        data.bwCountdownActive = true;
        org.bukkit.plugin.Plugin plugin = Bukkit.getPluginManager().getPlugin("YucehanRP");
        // .sk: 60sn lobi süresi
        new org.bukkit.scheduler.BukkitRunnable() {
            int time = 60;
            @Override public void run() {
                if (!data.bwCountdownActive) { cancel(); return; }
                if (data.bwLobbyQueue.size() < 2) {
                    cancel(); data.bwCountdownActive = false;
                    broadcastToLobi(C.c("&c[BW] Yeterli oyuncu kalmadı. Geri sayım iptal!"), null);
                    return;
                }
                time--;
                // .sk: 30, 10 saniyelerde ve son 5'te bildir
                if (time == 30 || time == 10 || (time > 0 && time <= 5)) {
                    broadcastToLobi(C.c("&a[BW] &e" + time + " &asaniye!"), null);
                    for (UUID uid : data.bwLobbyQueue) {
                        Player p = Bukkit.getPlayer(uid);
                        if (p != null) p.sendTitle(C.c("&c&l" + time), C.c("&7Hazırlan..."), 3, 30, 3);
                    }
                }
                if (time <= 0) {
                    cancel(); data.bwCountdownActive = false;
                    if (data.bwLobbyQueue.size() < 2) {
                        broadcastToLobi(C.c("&c&l[BED WARS] &7Yeterli oyuncu toplanamadı! Oyun iptal edildi."), null);
                        for (UUID uid : new ArrayList<>(data.bwLobbyQueue)) {
                            Player p = Bukkit.getPlayer(uid);
                            if (p != null) lobiCik(p);
                        }
                        return;
                    }
                    startGame();
                }
            }
        }.runTaskTimer(plugin, 20L, 20L);
    }

    // ─── Oyun başlat — .sk bwBaslat birebir ─────────────────────────────────
    private void startGame() {
        data.bwActive = true;
        data.bwTimeLeft = 600;

        // Yatakları sıfırla
        data.bwBedAlive.put("kirmizi", true);
        data.bwBedAlive.put("mavi", true);
        data.bwBedAlive.put("sari", true);
        data.bwBedAlive.put("yesil", true);

        // Önceki turdan kalan blokları temizle (yeni turda temizlenir)
        bwHaritaTemizle();

        List<UUID> players = new ArrayList<>(data.bwLobbyQueue);
        data.bwLobbyQueue.clear();

        // Round-robin takım ataması — .sk _rMod ile aynı mantık
        Map<String, Integer> teamCount = new HashMap<>();
        teamCount.put("kirmizi", 0); teamCount.put("mavi", 0);
        teamCount.put("sari", 0); teamCount.put("yesil", 0);
        String[] order = {"kirmizi","mavi","sari","yesil"};
        int idx = 0;

        for (UUID uid : players) {
            // Mevcut indeksten itibaren dolu olmayan takım bul
            String chosen = null;
            for (int attempt = 0; attempt < 4; attempt++) {
                String t = order[(idx + attempt) % 4];
                if (teamCount.get(t) < 3) {
                    chosen = t;
                    idx = (idx + attempt + 1) % 4;
                    break;
                }
            }
            if (chosen == null) break; // max 12 oyuncu (4x3)

            teamCount.put(chosen, teamCount.get(chosen) + 1);
            data.bwInLobby.remove(uid);
            data.bwTeam.put(uid, chosen);

            Player p = Bukkit.getPlayer(uid);
            if (p == null) continue;

            p.setGameMode(GameMode.SURVIVAL);
            p.setHealth(20); p.setFoodLevel(20);
            giveTeamKit(p, chosen);
            p.teleport(spawnLoc(chosen));

            p.sendMessage(C.c(""));
            p.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
            p.sendMessage(C.c("      &c&l🛏 BED WARS BAŞLADI!"));
            p.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
            p.sendMessage(C.c("&7Takımın: " + teamColorCode(chosen)));
            p.sendMessage(C.c("&7Yatağını koru! Kırılırsa bir daha doğamazsın."));
            p.sendMessage(C.c("&7Mağaza için: &e/bwmagaza"));
            p.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
            p.sendTitle(C.c(teamColorCode(chosen) + " &fTAKIMI"), C.c("&7Yatağını koru!"), 10, 80, 20);
            p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1f);
        }

        // Yataklıları yerleştir (.sk bwYataklariYerlestir)
        bwYataklariYerlestir();
        // Araziyi yenile
        bwAraziYenile();

        // Genel duyuru
        for (Player p : Bukkit.getOnlinePlayers()) {
            p.sendMessage(C.c(""));
            p.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
            p.sendMessage(C.c("       &c&l🛏 BED WARS OYUNU BAŞLADI!"));
            p.sendMessage(C.c("  &7Mağaza için: &e/bwmagaza"));
            p.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
            p.sendMessage(C.c(""));
        }
    }

    // ─── Yataklari Yerleştir — pure Bukkit API (.sk bwYataklariYerlestir) ────
    public void bwYataklariYerlestir() {
        World w = Bukkit.getWorld("world");
        if (w == null) return;

        // Önce eski yatakları AIR yap
        setBlock(w, -6,  41, 10000075, Material.AIR);
        setBlock(w, -5,  41, 10000075, Material.AIR);
        setBlock(w, -51, 41, 10000107, Material.AIR);
        setBlock(w, -51, 41, 10000108, Material.AIR);
        setBlock(w,-104, 41, 10000074, Material.AIR);
        setBlock(w,-103, 41, 10000074, Material.AIR);
        setBlock(w, -50, 41, 10000037, Material.AIR);
        setBlock(w, -50, 41, 10000038, Material.AIR);

        // 2 tick sonra sadece YAŞAYAN takımların yataklarını koy
        Bukkit.getScheduler().runTaskLater(
            Bukkit.getPluginManager().getPlugin("YucehanRP"), () -> {
            // Kırmızı — sadece yaşıyorsa
            if (Boolean.TRUE.equals(data.bwBedAlive.get("kirmizi"))) {
                placeBed(w, -6, 41, 10000075, Material.RED_BED,
                         org.bukkit.block.data.type.Bed.Part.FOOT, org.bukkit.block.BlockFace.EAST);
                placeBed(w, -5, 41, 10000075, Material.RED_BED,
                         org.bukkit.block.data.type.Bed.Part.HEAD, org.bukkit.block.BlockFace.EAST);
            }
            // Mavi
            if (Boolean.TRUE.equals(data.bwBedAlive.get("mavi"))) {
                placeBed(w, -51, 41, 10000107, Material.BLUE_BED,
                         org.bukkit.block.data.type.Bed.Part.FOOT, org.bukkit.block.BlockFace.SOUTH);
                placeBed(w, -51, 41, 10000108, Material.BLUE_BED,
                         org.bukkit.block.data.type.Bed.Part.HEAD, org.bukkit.block.BlockFace.SOUTH);
            }
            // Sarı
            if (Boolean.TRUE.equals(data.bwBedAlive.get("sari"))) {
                placeBed(w, -104, 41, 10000074, Material.YELLOW_BED,
                         org.bukkit.block.data.type.Bed.Part.HEAD, org.bukkit.block.BlockFace.WEST);
                placeBed(w, -103, 41, 10000074, Material.YELLOW_BED,
                         org.bukkit.block.data.type.Bed.Part.FOOT, org.bukkit.block.BlockFace.WEST);
            }
            // Yeşil
            if (Boolean.TRUE.equals(data.bwBedAlive.get("yesil"))) {
                placeBed(w, -50, 41, 10000038, Material.LIME_BED,
                         org.bukkit.block.data.type.Bed.Part.FOOT, org.bukkit.block.BlockFace.NORTH);
                placeBed(w, -50, 41, 10000037, Material.LIME_BED,
                         org.bukkit.block.data.type.Bed.Part.HEAD, org.bukkit.block.BlockFace.NORTH);
            }
        }, 2L);
    }

    /** Tek blok set — pure Bukkit */
    private void setBlock(World w, int x, int y, int z, Material mat) {
        w.getBlockAt(x, y, z).setType(mat, false);
    }

    /** Yatak bloğu koy — blockstate ile yön ve part ayarla */
    private void placeBed(World w, int x, int y, int z, Material mat,
                          org.bukkit.block.data.type.Bed.Part part,
                          org.bukkit.block.BlockFace facing) {
        org.bukkit.block.Block blk = w.getBlockAt(x, y, z);
        blk.setType(mat, false);
        org.bukkit.block.data.BlockData bd = blk.getBlockData();
        if (bd instanceof org.bukkit.block.data.type.Bed bed) {
            bed.setPart(part);
            bed.setFacing(facing);
            blk.setBlockData(bed, false);
        }
    }

    // ─── Arazi Yenile — pure Bukkit fill (.sk bwAraziYenile) ─────────────────
    public void bwAraziYenile() {
        World w = Bukkit.getWorld("world");
        if (w == null) return;
        // Kırmızı toprak
        fillBlocks(w,   7, 40, 10000057, -16, 40, 10000092, Material.GRASS_BLOCK);
        // Sarı toprak
        fillBlocks(w,-117, 40, 10000057, -94, 40, 10000092, Material.GRASS_BLOCK);
        // Mavi toprak
        fillBlocks(w, -68, 40, 10000098, -33, 40, 10000121, Material.GRASS_BLOCK);
        // Yeşil toprak
        fillBlocks(w, -68, 40, 10000026, -33, 40, 10000049, Material.GRASS_BLOCK);
        // Orta ada
        fillBlocks(w, -65, 40, 10000061, -37, 40, 10000088, Material.GRASS_BLOCK);
    }

    /** fill x1 y1 z1 x2 y2 z2 material — pure Bukkit loop */
    private void fillBlocks(World w, int x1, int y1, int z1,
                            int x2, int y2, int z2, Material mat) {
        int minX = Math.min(x1,x2), maxX = Math.max(x1,x2);
        int minY = Math.min(y1,y2), maxY = Math.max(y1,y2);
        int minZ = Math.min(z1,z2), maxZ = Math.max(z1,z2);
        for (int x = minX; x <= maxX; x++)
            for (int y = minY; y <= maxY; y++)
                for (int z = minZ; z <= maxZ; z++)
                    w.getBlockAt(x, y, z).setType(mat, false);
    }

    // ─── Oyuncu yerleştirilen blokları temizle ───────────────────────────────
    public void bwHaritaTemizle() {
        // Oyuncu yerleştirdiği blokları temizle
        for (Location loc : new HashSet<>(data.bwPlacedBlocks)) {
            loc.getBlock().setType(Material.AIR, false);
        }
        data.bwPlacedBlocks.clear();

        // Alan üzerinden geç — ne olursa olsun temizle (-147 93 10000003 -> 36 15 10000147)
        World w = Bukkit.getWorld("world");
        if (w == null) return;
        for (int x = -147; x <= 36; x++) {
            for (int y = 15; y <= 93; y++) {
                for (int z = 10000003; z <= 10000147; z++) {
                    org.bukkit.block.Block b = w.getBlockAt(x, y, z);
                    Material mat = b.getType();
                    // Sadece oyuncu koyabilecekleri temizle — zemin/orijinal bloklara dokunma
                    if (mat == Material.WHITE_WOOL || mat == Material.SANDSTONE
                            || mat == Material.OAK_PLANKS || mat == Material.GLASS
                            || mat == Material.OBSIDIAN || mat == Material.LADDER
                            || mat == Material.COBBLESTONE || mat == Material.DIRT) {
                        b.setType(Material.AIR, false);
                    }
                }
            }
        }
        // Arazileri yenile
        bwAraziYenile();
    }

    // ─── Item temizle — SADECE item entity'leri, placed blocks dokunma ────────
    // Placed blocks sadece yeni tur başında (startGame) temizlenir
    public void bwItemTemizle() {
        World w = Bukkit.getWorld("world");
        if (w != null) {
            Location center = new Location(w, -55, 36, 10000075);
            w.getNearbyEntities(center, 95, 200, 75).forEach(e -> {
                if (e instanceof org.bukkit.entity.Item) e.remove();
            });
        }
        // bwHaritaTemizle() buraya ÇAĞRILMIYOR - sadece yeni turda çağrılır
    }

    // ─── Yatak kırıldı — TNT efekti düzeltildi (alınamaz, sadece efekt) ──────
    public void yatakKirildi(String takim, Player kirici) {
        data.bwBedAlive.put(takim, false);

        Location bedL = bedLoc(takim);
        World w = bedL.getWorld();
        if (w != null) {
            // Saf efekt: partikül + patlama sesi, fiziksel TNT yok (alınamaz)
            w.spawnParticle(org.bukkit.Particle.EXPLOSION, bedL, 5, 0.5, 0.5, 0.5, 0);
            w.spawnParticle(org.bukkit.Particle.FLAME, bedL, 30, 0.8, 0.8, 0.8, 0.05);
            w.spawnParticle(org.bukkit.Particle.SMOKE, bedL, 20, 0.5, 0.5, 0.5, 0.02);
            w.playSound(bedL, Sound.ENTITY_GENERIC_EXPLODE, 3f, 0.8f);
            w.playSound(bedL, Sound.ENTITY_GENERIC_EXPLODE, 3f, 1.2f);
            w.playSound(bedL, Sound.BLOCK_GLASS_BREAK, 2f, 0.5f);
            // Hasar vermeden görsel patlama
            Bukkit.getScheduler().runTaskLater(Bukkit.getPluginManager().getPlugin("YucehanRP"), () -> {
                w.spawnParticle(org.bukkit.Particle.EXPLOSION_EMITTER, bedL, 3, 0.3, 0.3, 0.3, 0);
                w.playSound(bedL, Sound.ENTITY_WITHER_SPAWN, 1f, 2f);
            }, 10L);
        }

        // Duyurular
        for (UUID uid : new HashSet<>(data.bwTeam.keySet())) {
            Player p = Bukkit.getPlayer(uid);
            if (p == null) continue;
            p.sendMessage(C.c(""));
            p.sendMessage(C.c("&4&l💥 " + teamColorCode(takim) + " TAKIMININ YATAĞI KIRILDI/PATLADI!"));
            p.sendMessage(C.c("&7Kıran: &f" + kirici.getName()));
            p.sendMessage(C.c(""));
            p.sendTitle(C.c("&c&l💣 TNT!"), C.c("&7" + teamColorCode(takim) + " yatağı patlıyor..."), 5, 40, 10);
            p.playSound(p.getLocation(), Sound.ENTITY_ENDER_DRAGON_HURT, 1f, 1f);
        }

        // Kırılan takıma özel mesaj
        for (UUID uid : new HashSet<>(data.bwTeam.keySet())) {
            if (takim.equals(data.bwTeam.get(uid))) {
                Player p = Bukkit.getPlayer(uid);
                if (p != null) {
                    p.sendMessage(C.c("&c&l⚠ Yatağın patladı! Bir daha ölürsen elenirsin!"));
                    p.playSound(p.getLocation(), Sound.ENTITY_WITHER_SPAWN, 1f, 1f);
                }
            }
        }

        checkWinner();
    }

    // ─── Kazanan kontrol — .sk bwKazananKontrol birebir ─────────────────────
    public void checkWinner() {
        if (!data.bwActive) return;

        // Hayatta olan takımları bul
        Set<String> aliveTeams = new HashSet<>();
        int aliveOyuncu = 0;
        for (Map.Entry<UUID, String> e : data.bwTeam.entrySet()) {
            Player p = Bukkit.getPlayer(e.getKey());
            if (p != null && p.isOnline()) {
                aliveTeams.add(e.getValue());
                aliveOyuncu++;
            }
        }

        // Oyuncusu kalmayan takımların yatağını sıfırla (.sk bwKazananKontrol içinde)
        for (String team : List.of("kirmizi", "mavi", "sari", "yesil")) {
            if (!aliveTeams.contains(team)) {
                data.bwBedAlive.put(team, false);
            }
        }

        if (aliveOyuncu == 0) {
            endGame("yok");
        } else if (aliveTeams.size() == 1) {
            endGame(aliveTeams.iterator().next());
        }
    }

    // ─── Oyun bitis — .sk bwBitis birebir ────────────────────────────────────
    public void endGame(String kazanan) {
        if (!data.bwActive) return;
        data.bwActive = false;
        data.bwCountdownActive = false;

        // Herkese bildir
        for (UUID uid : new HashSet<>(data.bwTeam.keySet())) {
            Player p = Bukkit.getPlayer(uid);
            if (p == null) continue;
            p.sendMessage(C.c(""));
            p.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
            p.sendMessage(C.c("       &6&l🏆 OYUN BİTTİ!"));
            if (!"yok".equals(kazanan))
                p.sendMessage(C.c("  &7Kazanan: " + teamColorCode(kazanan) + " &7takımı!"));
            p.sendMessage(C.c("&8&m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
            if (!"yok".equals(kazanan))
                p.sendTitle(C.c("&6&l🏆 OYUN BİTTİ"), C.c(teamColorCode(kazanan) + " &fkazandı!"), 10, 70, 20);
            else
                p.sendTitle(C.c("&6&l🏆 OYUN BİTTİ"), C.c("&7Berabere!"), 10, 70, 20);
            p.playSound(p.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
        }
        for (UUID uid : new HashSet<>(data.bwSpec.keySet())) {
            Player p = Bukkit.getPlayer(uid);
            if (p == null) continue;
            if (!"yok".equals(kazanan))
                p.sendMessage(C.c("  &6&l🏆 &7Kazanan: " + teamColorCode(kazanan) + " takımı!"));
        }

        // 5 saniye bekle, sonra herkes çıkışın
        Bukkit.getScheduler().runTaskLater(Bukkit.getPluginManager().getPlugin("YucehanRP"), () -> {
            // Haritayı temizle + yatakları yenile
            bwItemTemizle();
            bwYataklariYerlestir();
            bwAraziYenile();

            List<UUID> cikacaklar = new ArrayList<>();
            cikacaklar.addAll(new ArrayList<>(data.bwTeam.keySet()));
            cikacaklar.addAll(new ArrayList<>(data.bwSpec.keySet()));
            for (UUID uid : cikacaklar) {
                Player p = Bukkit.getPlayer(uid);
                if (p != null) lobiCik(p);
            }

            // Sıfırla
            data.bwBedAlive.clear();
            data.bwBedAlive.put("kirmizi", true);
            data.bwBedAlive.put("mavi", true);
            data.bwBedAlive.put("sari", true);
            data.bwBedAlive.put("yesil", true);
            data.bwTimeLeft = 600;
            data.bwPlacedBlocks.clear();

            // Anti-runner/AFK temizle
            for (Player p : Bukkit.getOnlinePlayers()) {
                p.removePotionEffect(org.bukkit.potion.PotionEffectType.SLOWNESS);
                p.removePotionEffect(org.bukkit.potion.PotionEffectType.GLOWING);
            }
        }, 100L);
    }

    private void broadcastToLobi(String msg, UUID exclude) {
        for (UUID uid : data.bwLobbyQueue) {
            if (uid.equals(exclude)) continue;
            Player p = Bukkit.getPlayer(uid);
            if (p != null) p.sendMessage(msg);
        }
    }
}
