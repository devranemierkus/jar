# YucehanRP Plugin v15

Yucehan RP sunucusu için tam paket Java Bukkit eklentisi.  
Skript v15'ten birebir Java'ya çevrilmiştir.

---

## 🔧 Derleme (GitHub Actions)

Repo'ya push atınca GitHub Actions otomatik derler.

1. Bu klasörü GitHub repo'suna push et
2. **Actions** sekmesine git
3. Build tamamlanınca **Artifacts** kısmından `YucehanRP-v15.jar` indir
4. `plugins/` klasörüne koy, sunucuyu başlat

> Java 17 + Paper 1.20.4 gereklidir.

---

## 📦 Özellikler

### 🌐 Bağlantı
- IP başına max 2 hesap (join/quit otomatik sayar)
- Giriş mesajı ve hoş geldin

### 📱 YuceCell Telefon
- `/telefonsatinal <lite|basic|v1|pro>` - telefon satın al
- `/telefonarama <oyuncu>` - arama başlat
- `/telefonkapat` - çağrıyı kapat
- `/telefonmsj <oyuncu> <mesaj>` - SMS gönder
- `/telefonbataryadoldur` - şarj et
- Batarya sistemi (şarj, çağrı tüketimi)

### 💻 Bilgisayar / Kripto
- `/bilgisayarac` - PC aç
- `/bilgisayarkriptobak` - borsa gör
- `/bilgisayarkriptoal <coin>` - 192 Zümrüte coin al
- `/bilgisayarkriptosat <coin>` - coin sat
- `/kriptocuzdan` - cüzdanı gör
- 5 coin: sunpar, yucecoin, tavukcoin, kredix, emeraldcoin
- Fiyatlar her 1 dakikada değişir

### 🏪 Oyuncu Marketi
- `/market` - marketi aç
- 7 tezgah slotu
- 10 dakika süre
- Zümrüt veya Elmas para birimi
- Satıcıya anında ödeme

### 🎮 Oyunlar (kafaya sağ tıkla)
| Oyun | Tip |
|------|-----|
| PVP | Fiziksel |
| Sumo | Fiziksel |
| Flappy Bird | GUI |
| Yılan | GUI |
| Hedef Vurma | GUI |
| Simon Says | Fiziksel |
| Hızlı Tıklama | GUI |
| Katil Kim | Çok Oyunculu |
| Bed Wars | Çok Oyunculu |

- Envanter kaydedilir ve geri yüklenir
- DC/crash sonrası otomatik kurtarma
- `/oyundancik` ile her oyundan çıkılır

### 📋 Diğer
- `/rehber` - yeni oyuncu rehberi
- `/koordinat` - konum göster
- `/arsanasil` - arsa satın alma bilgisi
- Duyurular (her 3-7 dakika)

### 🛡️ Admin
- `/herkesoyundancik` - tüm oyuncuları sıfırla (OP)
- `/yetkilioyundancikar <oyuncu>` - belirli oyuncuyu çıkar (OP)

---

## ⚙️ Teknik

- **Tüm veriler oturum bazlıdır** - kalıcı değil
- Sunucu kapanınca tüm oyun verileri sıfırlanır
- Kasıtlı: envanter kurtarma hariç hiçbir şey DB'ye yazılmaz
- Spawn: `world -15 -60 -8`

---

## 📁 Proje Yapısı

```
src/main/java/com/yucehanrp/
├── YucehanRP.java              # Ana sınıf
├── SessionData.java            # Tüm oturum verisi
├── util/
│   ├── C.java                  # Renk yardımcısı
│   └── ItemUtil.java           # Item yardımcısı
├── managers/
│   ├── InventoryManager        # invKaydet / invGeriYukle
│   ├── GameHeadManager         # Oyunlar kafası slot 0
│   ├── PhoneManager            # YuceCell telefon
│   ├── CryptoManager           # Kripto borsa
│   ├── MarketManager           # Market mantığı
│   ├── MarketGUIManager        # Market GUI
│   ├── GamesMenuManager        # Oyunlar menüsü
│   ├── PvpSumoManager          # PVP & Sumo
│   ├── MiniGamesManager        # Flappy/Snake/Hedef/Simon/Reflex
│   ├── KatilKimManager         # Katil Kim oyunu
│   ├── BedWarsManager          # Bed Wars oyunu
│   ├── GameQuitManager         # /oyundancik + DC temizliği
│   └── SchedulerManager        # Tüm timer'lar
├── listeners/
│   ├── ConnectionListener      # join/quit/login
│   ├── ChatListener            # chat yönetimi
│   ├── InventoryClickListener  # GUI tıklamaları
│   ├── CombatListener          # hasar/ölüm/drop
│   └── PlayerInteractListener  # etkileşim/hareket
└── commands/
    └── CommandManager          # Tüm komutlar
```
